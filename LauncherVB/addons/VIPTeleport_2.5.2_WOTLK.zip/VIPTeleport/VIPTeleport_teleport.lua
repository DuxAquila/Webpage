function VIPTeleport_teleport_table_init()
	VIPTeleport_teleports = {};
	VIPTeleport_teleports.zoneindex = {};
	VIPTeleport_teleports.zoneindex = {
		["Alteracgebirge"] = {
			["Alteractal"] = {
				["cmd"] = ".tele AlteracgebirgeAlteractal",
				["ypos"] = 0.5801766514778137,
				["xpos"] = 0.6425629854202271,
			},
			["Corrahns Dolch"] = {
				["cmd"] = ".tele AlteracgebirgeCorrahnsDolch",
				["ypos"] = 0.7875382900238037,
				["xpos"] = 0.4745160639286041,
			},
			["Dalarankrater"] = {
				["cmd"] = ".tele AlteracgebirgeDalarankrater",
				["ypos"] = 0.5962831974029541,
				["xpos"] = 0.2039408385753632,
			},
			["Dandreds Senke"] = {
				["cmd"] = ".tele AlteracgebirgeDandredsSenke",
				["ypos"] = 0.1397571414709091,
				["xpos"] = 0.3821565508842468,
			},
			["Das Oberland"] = {
				["cmd"] = ".tele AlteracgebirgeDasOberland",
				["ypos"] = 0.2513670027256012,
				["xpos"] = 0.5446581840515137,
			},
			["Die Landzunge"] = {
				["cmd"] = ".tele AlteracgebirgeDieLandzunge",
				["ypos"] = 0.8796392679214478,
				["xpos"] = 0.3843255341053009,
			},
			["Die Ruinen von Alterac"] = {
				["cmd"] = ".tele AlteracgebirgeDieRuinenvonAlterac",
				["ypos"] = 0.5236029028892517,
				["xpos"] = 0.3781161904335022,
			},
			["Eisfellh\195\182hle"] = {
				["cmd"] = ".tele AlteracgebirgeEisfellhoehle",
				["ypos"] = 0.6897806525230408,
				["xpos"] = 0.3773132860660553,
			},
			["Galgeneck"] = {
				["cmd"] = ".tele AlteracgebirgeGalgeneck",
				["ypos"] = 0.5577590465545654,
				["xpos"] = 0.5024829506874085,
			},
			["Gavins Landspitze"] = {
				["cmd"] = ".tele AlteracgebirgeGavinsLandspitze",
				["ypos"] = 0.8362899422645569,
				["xpos"] = 0.3152219355106354,
			},
			["Lordamere-Internierungslager"] = {
				["cmd"] = ".tele AlteracgebirgeLordamere-Internierungslager",
				["ypos"] = 0.8435558676719666,
				["xpos"] = 0.2079004645347595,
			},
			["Nebelufer"] = {
				["cmd"] = ".tele AlteracgebirgeNebelufer",
				["ypos"] = 0.3426980972290039,
				["xpos"] = 0.3120128810405731,
			},
			["Rabenholdtanwesen"] = {
				["cmd"] = ".tele AlteracgebirgeRabenholdtanwesen",
				["ypos"] = 0.7948971390724182,
				["xpos"] = 0.8422802686691284,
			},
			["Schl\195\164chtergrotte"] = {
				["cmd"] = ".tele AlteracgebirgeSchlaechtergrotte",
				["ypos"] = 0.3507074117660523,
				["xpos"] = 0.4792931079864502,
			},
			["Soferas Landspitze"] = {
				["cmd"] = ".tele AlteracgebirgeSoferasLandspitze",
				["ypos"] = 0.655372679233551,
				["xpos"] = 0.575944185256958,
			},
			["Strahnbrad"] = {
				["cmd"] = ".tele AlteracgebirgeStrahnbrad",
				["ypos"] = 0.4393858909606934,
				["xpos"] = 0.6244665384292603,
			},
			["Tr\195\188mmergrath\195\182hle"] = {
				["cmd"] = ".tele AlteracgebirgeTruemmergrathoehle",
				["ypos"] = 0.4359484314918518,
				["xpos"] = 0.4907870292663574,
			},
			["Zugwindspitze"] = {
				["cmd"] = ".tele AlteracgebirgeZugwindspitze",
				["ypos"] = 0.6308715343475342,
				["xpos"] = 0.8111382722854614,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 1,
			},
		},
		["Arathihochland"] = {
			["Bauernhof der Dabyries"] = {
				["cmd"] = ".tele ArathihochlandBauernhofderDabyries",
				["ypos"] = 0.3885653018951416,
				["xpos"] = 0.566359281539917,
			},
			["Burg Stromgarde"] = {
				["cmd"] = ".tele ArathihochlandBurgStromgarde",
				["ypos"] = 0.6012188792228699,
				["xpos"] = 0.2608316242694855,
			},
			["Das versunkene Riff"] = {
				["cmd"] = ".tele ArathihochlandDasversunkeneRiff",
				["ypos"] = 0.8485268950462341,
				["xpos"] = 0.230385348200798,
			},
			["Der Turm von Arathor"] = {
				["cmd"] = ".tele ArathihochlandDerTurmvonArathor",
				["ypos"] = 0.6843953728675842,
				["xpos"] = 0.1804221719503403,
			},
			["Die Faldirbucht"] = {
				["cmd"] = ".tele ArathihochlandDieFaldirbucht",
				["ypos"] = 0.8139777779579163,
				["xpos"] = 0.3355287313461304,
			},
			["Die Zuflucht"] = {
				["cmd"] = ".tele ArathihochlandDieZuflucht",
				["ypos"] = 0.4706069827079773,
				["xpos"] = 0.4597454071044922,
			},
			["Fels'gor"] = {
				["cmd"] = ".tele ArathihochlandFelsgor",
				["ypos"] = 0.4401829242706299,
				["xpos"] = 0.3541247248649597,
			},
			["Go'Sheks Hof"] = {
				["cmd"] = ".tele ArathihochlandGoSheksHof",
				["ypos"] = 0.5717403292655945,
				["xpos"] = 0.6010704040527344,
			},
			["Halle der Felsf\195\164uste"] = {
				["cmd"] = ".tele ArathihochlandHallederFelsfaeuste",
				["ypos"] = 0.764894425868988,
				["xpos"] = 0.5339926481246948,
			},
			["Hammerfall"] = {
				["cmd"] = ".tele ArathihochlandHammerfall",
				["ypos"] = 0.3289265632629395,
				["xpos"] = 0.7314850687980652
,
			},
			["Kreis der inneren Bindung"] = {
				["cmd"] = ".tele ArathihochlandKreisderinnerenBindung",
				["ypos"] = 0.58237224817276,
				["xpos"] = 0.3622021377086639,
			},
			["Kreis der westlichen Bindung"] = {
				["cmd"] = ".tele ArathihochlandKreisderwestlichenBindung",
				["ypos"] = 0.3040769398212433,
				["xpos"] = 0.2550148367881775,
			},
			["Kreis der \195\164u\195\159eren Bindung"] = {
				["cmd"] = ".tele ArathihochlandKreisderaeusserenBindung",
				["ypos"] = 0.5087777972221375,
				["xpos"] = 0.5198342800140381,
			},
			["Kreis der \195\182stlichen Bindung"] = {
				["cmd"] = ".tele ArathihochlandKreisderoestlichenBindung",
				["ypos"] = 0.2955294549465179,
				["xpos"] = 0.6676037311553955,
			},
			["Lager der Bleichborken"] = {
				["cmd"] = ".tele ArathihochlandLagerderBleichborken",
				["ypos"] = 0.6793869733810425,
				["xpos"] = 0.7026869058609009,
			},
			["Nordhof"] = {
				["cmd"] = ".tele ArathihochlandNordhof",
				["ypos"] = 0.2766256928443909,
				["xpos"] = 0.3339675962924957,
			},
			["Schlucht der Trockenstoppel"] = {
				["cmd"] = ".tele ArathihochlandSchluchtderTrockenstoppel",
				["ypos"] = 0.3658267557621002,
				["xpos"] = 0.8246858716011047,
			},
			["Thandol\195\188bergang"] = {
				["cmd"] = ".tele ArathihochlandThandoluebergang",
				["ypos"] = 0.9179736375808716,
				["xpos"] = 0.4564315378665924,
			},
			["Thoradinswall"] = {
				["cmd"] = ".tele ArathihochlandThoradinswall",
				["ypos"] = 0.2942773699760437,
				["xpos"] = 0.2010148167610169,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 2,
			},
		},
		["Azshara"] = {
			["Bittere Landzunge"] = {
				["cmd"] = ".tele AzsharaBittereLandzunge",
				["ypos"] = 0.2124730050563812,
				["xpos"] = 0.7814689874649048,
			},
			["B\195\164renkopf"] = {
				["cmd"] = ".tele AzsharaBaerenkopf",
				["ypos"] = 0.4325749576091766,
				["xpos"] = 0.2912025451660156,
			},
			["Der einsame Grat"] = {
				["cmd"] = ".tele AzsharaDereinsameGrat",
				["ypos"] = 0.7667543888092041,
				["xpos"] = 0.2586326897144318,
			},
			["Der Tempel von Arkkoran"] = {
				["cmd"] = ".tele AzsharaDerTempelvonArkkoran",
				["ypos"] = 0.3790306746959686,
				["xpos"] = 0.7852096557617188,
			},
			["Die Bucht der St\195\188rme"] = {
				["cmd"] = ".tele AzsharaDieBuchtderStuerme",
				["ypos"] = 0.7331995368003845,
				["xpos"] = 0.7918562889099121,
			},
			["Die verfallenen Gegenden"] = {
				["cmd"] = ".tele AzsharaDieverfallenenGegenden",
				["ypos"] = 0.8768932819366455,
				["xpos"] = 0.5184566974639893,
			},
			["Gezacktes Riff"] = {
				["cmd"] = ".tele AzsharaGezacktesRiff",
				["ypos"] = 0.1556398868560791,
				["xpos"] = 0.8558187484741211,
			},
			["Hetaeras Gelege"] = {
				["cmd"] = ".tele AzsharaHetaerasGelege",
				["ypos"] = 0.5286640524864197,
				["xpos"] = 0.5828829407691956,
			},
			["Lager der Haldarr"] = {
				["cmd"] = ".tele AzsharaLagerderHaldarr",
				["ypos"] = 0.602045476436615,
				["xpos"] = 0.2056653797626495,
			},
			["Lager der Legashi"] = {
				["cmd"] = ".tele AzsharaLagerderLegashi",
				["ypos"] = 0.237144336104393,
				["xpos"] = 0.5942671895027161,
			},
			["Mennarsee"] = {
				["cmd"] = ".tele AzsharaMennarsee",
				["ypos"] = 0.7969241142272949,
				["xpos"] = 0.4134743809700012,
			},
			["Rabenkrones Monument"] = {
				["cmd"] = ".tele AzsharaRabenkronesMonument",
				["ypos"] = 0.8688836097717285,
				["xpos"] = 0.6921701431274414,
			},
			["Rethress Sanktum"] = {
				["cmd"] = ".tele AzsharaRethressSanktum",
				["ypos"] = 0.9264361262321472,
				["xpos"] = 0.6235733032226563,
			},
			["Schattensangschrein"] = {
				["cmd"] = ".tele AzsharaSchattensangschrein",
				["ypos"] = 0.7204569578170776,
				["xpos"] = 0.1494821161031723,
			},
			["Schuppenbarts H\195\182hle"] = {
				["cmd"] = ".tele AzsharaSchuppenbartsHoehle",
				["ypos"] = 0.4840122759342194,
				["xpos"] = 0.5455449223518372,
			},
			["Strand der Tr\195\188mmer"] = {
				["cmd"] = ".tele AzsharaStrandderTruemmer",
				["ypos"] = 0.4976235628128052,
				["xpos"] = 0.4505478143692017,
			},
			["S\195\188dklippenufer"] = {
				["cmd"] = ".tele AzsharaSuedklippenufer",
				["ypos"] = 0.7083394527435303,
				["xpos"] = 0.5442132949829102,
			},
			["Talrendisspitze"] = {
				["cmd"] = ".tele AzsharaTalrendisspitze",
				["ypos"] = 0.7792986631393433,
				["xpos"] = 0.1184953078627586,
			},
			["Tempel von Zin-Malor"] = {
				["cmd"] = ".tele AzsharaTempelvonZin-Malor",
				["ypos"] = 0.5308293104171753,
				["xpos"] = 0.396557480096817,
			},
			["Thalassischer St\195\188tzpunkt"] = {
				["cmd"] = ".tele AzsharaThalassischerStuetzpunkt",
				["ypos"] = 0.2871578931808472,
				["xpos"] = 0.5856591463088989,
			},
			["Turm von Eldara"] = {
				["cmd"] = ".tele AzsharaTurmvonEldara",
				["ypos"] = 0.3339412212371826,
				["xpos"] = 0.8967560529708862,
			},
			["Ursolan"] = {
				["cmd"] = ".tele AzsharaUrsolan",
				["ypos"] = 0.3319180309772492,
				["xpos"] = 0.4600555002689362,
			},
			["Valormok"] = {
				["cmd"] = ".tele AzsharaValormok",
				["ypos"] = 0.5163365006446838,
				["xpos"] = 0.2239820659160614,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 1,
			},
		},
		["Azurmythosinsel"] = {
			["Absturzstelle"] = {
				["cmd"] = ".tele AzurmythosinselAbsturzstelle",
				["ypos"] = 0.4867377579212189,
				["xpos"] = 0.7995414733886719,
			},
			["Am'menfelder"] = {
				["cmd"] = ".tele AzurmythosinselAmmenfelder",
				["ypos"] = 0.5020919442176819,
				["xpos"] = 0.7335107922554016,
			},
			["Am'menfluss"] = {
				["cmd"] = ".tele AzurmythosinselAmmenfluss",
				["ypos"] = 0.5328848361968994,
				["xpos"] = 0.6229928135871887,
			},
			["Am'mental"] = {
				["cmd"] = ".tele AzurmythosinselAmmental",
				["ypos"] = 0.4323684275150299,
				["xpos"] = 0.7756642699241638,
			},
			["Azurwacht"] = {
				["cmd"] = ".tele AzurmythosinselAzurwacht",
				["ypos"] = 0.5118833184242249,
				["xpos"] = 0.4949846863746643,
			},
			["Der heilige Hain"] = {
				["cmd"] = ".tele AzurmythosinselDerheiligeHain",
				["ypos"] = 0.3660340905189514,
				["xpos"] = 0.703295886516571,
			},
			["Dorf der Sichelklauen"] = {
				["cmd"] = ".tele AzurmythosinselDorfderSichelklauen",
				["ypos"] = 0.6710901856422424,
				["xpos"] = 0.2700676620006561,
			},
			["Geezles Lager"] = {
				["cmd"] = ".tele AzurmythosinselGeezlesLager",
				["ypos"] = 0.6623706221580505,
				["xpos"] = 0.5800532102584839,
			},
			["Gezeitenh\195\182hle"] = {
				["cmd"] = ".tele AzurmythosinselGezeitenhoehle",
				["ypos"] = 0.7676132917404175,
				["xpos"] = 0.2712467312812805,
			},
			["Glutgrund"] = {
				["cmd"] = ".tele AzurmythosinselGlutgrund",
				["ypos"] = 0.1742182672023773,
				["xpos"] = 0.5922865271568298,
			},
			["Hassprankenterritorium"] = {
				["cmd"] = ".tele AzurmythosinselHassprankenterritorium",
				["ypos"] = 0.7710539102554321,
				["xpos"] = 0.3306940495967865,
			},
			["Kapselteil"] = {
				["cmd"] = ".tele AzurmythosinselKapselteil",
				["ypos"] = 0.5884365439414978,
				["xpos"] = 0.360466867685318,
			},
			["Kapselwrack"] = {
				["cmd"] = ".tele AzurmythosinselKapselwrack",
				["ypos"] = 0.6069698333740234,
				["xpos"] = 0.5255189538002014,
			},
			["Menagerietr\195\188mmer"] = {
				["cmd"] = ".tele AzurmythosinselMenagerietruemmer",
				["ypos"] = 0.2126219570636749,
				["xpos"] = 0.5507472157478333,
			},
			["Mondschwingenbau"] = {
				["cmd"] = ".tele AzurmythosinselMondschwingenbau",
				["ypos"] = 0.8298770189285278,
				["xpos"] = 0.131103441119194,
			},
			["Mondweidenwald"] = {
				["cmd"] = ".tele AzurmythosinselMondweidenwald",
				["ypos"] = 0.4209264814853668,
				["xpos"] = 0.5192548632621765,
			},
			["Morgentaustrand"] = {
				["cmd"] = ".tele AzurmythosinselMorgentaustrand",
				["ypos"] = 0.04697591438889504,
				["xpos"] = 0.4744484424591065,
			},
			["Nisteldickicht"] = {
				["cmd"] = ".tele AzurmythosinselNisteldickicht",
				["ypos"] = 0.5939070582389832,
				["xpos"] = 0.7987064123153687,
			},
			["Nistelh\195\188gel"] = {
				["cmd"] = ".tele AzurmythosinselNistelhuegel",
				["ypos"] = 0.6512528657913208,
				["xpos"] = 0.8440040946006775,
			},
			["Odesyus' Ankerplatz"] = {
				["cmd"] = ".tele AzurmythosinselOdesyusAnkerplatz",
				["ypos"] = 0.7097922563552856,
				["xpos"] = 0.4701248705387116,
			},
			["Schattenkamm"] = {
				["cmd"] = ".tele AzurmythosinselSchattenkamm",
				["ypos"] = 0.636005699634552,
				["xpos"] = 0.6878198981285095,
			},
			["Schlickerk\195\188ste"] = {
				["cmd"] = ".tele AzurmythosinselSchlickerkueste",
				["ypos"] = 0.1039165481925011,
				["xpos"] = 0.3701700270175934,
			},
			["Silbermythosinsel"] = {
				["cmd"] = ".tele AzurmythosinselSilbermythosinsel",
				["ypos"] = 0.7851261496543884,
				["xpos"] = 0.1935966461896896,
			},
			["Silberwellensee"] = {
				["cmd"] = ".tele AzurmythosinselSilberwellensee",
				["ypos"] = 0.602409303188324,
				["xpos"] = 0.7565282583236694,
			},
			["Tannenruhfeste"] = {
				["cmd"] = ".tele AzurmythosinselTannenruhfeste",
				["ypos"] = 0.2358225584030151,
				["xpos"] = 0.4577195346355438,
			},
			["Valaars Steg"] = {
				["cmd"] = ".tele AzurmythosinselValaarsSteg",
				["ypos"] = 0.5380421280860901,
				["xpos"] = 0.2307636737823486,
			},
			["Verr\195\164terbucht"] = {
				["cmd"] = ".tele AzurmythosinselVerraeterbucht",
				["ypos"] = 0.839686930179596,
				["xpos"] = 0.1845814883708954,
			},
			["Wildwindgipfel"] = {
				["cmd"] = ".tele AzurmythosinselWildwindgipfel",
				["ypos"] = 0.3602708280086517,
				["xpos"] = 0.2304868400096893,
			},
			["Wildwindpfad"] = {
				["cmd"] = ".tele AzurmythosinselWildwindpfad",
				["ypos"] = 0.2789673507213593,
				["xpos"] = 0.2633367776870728,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 2,
			},
		},
		["Blutmythosinsel"] = {
			["Axxarien"] = {
				["cmd"] = ".tele BlutmythosinselAxxarien",
				["ypos"] = 0.34284907579422,
				["xpos"] = 0.4080613553524017,
			},
			["Beryllk\195\188ste"] = {
				["cmd"] = ".tele BlutmythosinselBeryllkueste",
				["ypos"] = 0.8824766278266907,
				["xpos"] = 0.701364278793335,
			},
			["Blutbrandung"] = {
				["cmd"] = ".tele BlutmythosinselBlutbrandung",
				["ypos"] = 0.241515725851059,
				["xpos"] = 0.3931340873241425,
			},
			["Blutwacht"] = {
				["cmd"] = ".tele BlutmythosinselBlutwacht",
				["ypos"] = 0.5650099515914917,
				["xpos"] = 0.5406898260116577,
			},
			["Das Riff des Blutfluchs"] = {
				["cmd"] = ".tele BlutmythosinselDasRiffdesBlutfluchs",
				["ypos"] = 0.2289364188909531,
				["xpos"] = 0.8327053189277649,
			},
			["Das versteckte Riff"] = {
				["cmd"] = ".tele BlutmythosinselDasversteckteRiff",
				["ypos"] = 0.1866375654935837,
				["xpos"] = 0.3112950026988983,
			},
			["Der besudelte Teich"] = {
				["cmd"] = ".tele BlutmythosinselDerbesudelteTeich",
				["ypos"] = 0.364665150642395,
				["xpos"] = 0.2780382633209229,
			},
			["Der Kryokern"] = {
				["cmd"] = ".tele BlutmythosinselDerKryokern",
				["ypos"] = 0.6167110800743103,
				["xpos"] = 0.4000614881515503,
			},
			["Die Purpurbrandung"] = {
				["cmd"] = ".tele BlutmythosinselDiePurpurbrandung",
				["ypos"] = 0.5663846731185913,
				["xpos"] = 0.6944368481636047,
			},
			["Die Vektorspule"] = {
				["cmd"] = ".tele BlutmythosinselDieVektorspule",
				["ypos"] = 0.5357732176780701,
				["xpos"] = 0.1490269303321838,
			},
			["Die verlorene Furt"] = {
				["cmd"] = ".tele BlutmythosinselDieverloreneFurt",
				["ypos"] = 0.8251709342002869,
				["xpos"] = 0.5837244391441345,
			},
			["Die Warpgondel"] = {
				["cmd"] = ".tele BlutmythosinselDieWarpgondel",
				["ypos"] = 0.2126973122358322,
				["xpos"] = 0.5269272327423096,
			},
			["Enklave der Sichelklauen"] = {
				["cmd"] = ".tele BlutmythosinselEnklavederSichelklauen",
				["ypos"] = 0.8022651672363281,
				["xpos"] = 0.6582072377204895,
			},
			["Goldweberpass"] = {
				["cmd"] = ".tele BlutmythosinselGoldweberpass",
				["ypos"] = 0.4013915956020355,
				["xpos"] = 0.1828353106975555,
			},
			["Hassprankenzuflucht"] = {
				["cmd"] = ".tele BlutmythosinselHassprankenzuflucht",
				["ypos"] = 0.6812306642532349,
				["xpos"] = 0.6713259220123291,
			},
			["Insel des Blutfluchs"] = {
				["cmd"] = ".tele BlutmythosinselInseldesBlutfluchs",
				["ypos"] = 0.4873318374156952,
				["xpos"] = 0.8287206292152405,
			},
			["Insel Drachenfels"] = {
				["cmd"] = ".tele BlutmythosinselInselDrachenfels",
				["ypos"] = 0.2500582337379456,
				["xpos"] = 0.6757090091705322,
			},
			["Kessels Wegelager"] = {
				["cmd"] = ".tele BlutmythosinselKesselsWegelager",
				["ypos"] = 0.876697301864624,
				["xpos"] = 0.6341150999069214,
			},
			["Krallenhoch"] = {
				["cmd"] = ".tele BlutmythosinselKrallenhoch",
				["ypos"] = 0.2075709253549576,
				["xpos"] = 0.7266516089439392,
			},
			["Messerwinkel"] = {
				["cmd"] = ".tele BlutmythosinselMesserwinkel",
				["ypos"] = 0.4721594154834747,
				["xpos"] = 0.470804750919342,
			},
			["Mythoswald"] = {
				["cmd"] = ".tele BlutmythosinselMythoswald",
				["ypos"] = 0.8419111371040344,
				["xpos"] = 0.4501150846481323,
			},
			["Nazzivian"] = {
				["cmd"] = ".tele BlutmythosinselNazzivian",
				["ypos"] = 0.744357168674469,
				["xpos"] = 0.3782990276813507,
			},
			["Rachfederkamm"] = {
				["cmd"] = ".tele BlutmythosinselRachfederkamm",
				["ypos"] = 0.3332031071186066,
				["xpos"] = 0.5537779927253723,
			},
			["Ruinen von Loreth'Aran"] = {
				["cmd"] = ".tele BlutmythosinselRuinenvonLorethAran",
				["ypos"] = 0.4391525089740753,
				["xpos"] = 0.6320613622665405,
			},
			["Schwarzschlammk\195\188ste"] = {
				["cmd"] = ".tele BlutmythosinselSchwarzschlammkueste",
				["ypos"] = 0.9533042311668396,
				["xpos"] = 0.3738237321376801,
			},
			["Tel'athions Lager"] = {
				["cmd"] = ".tele BlutmythosinselTelathionsLager",
				["ypos"] = 0.4073180258274078,
				["xpos"] = 0.258390873670578,
			},
			["Tr\195\188mmerfall"] = {
				["cmd"] = ".tele BlutmythosinselTruemmerfall",
				["ypos"] = 0.7573686838150024,
				["xpos"] = 0.5186821818351746,
			},
			["Verteidigers Ruh'"] = {
				["cmd"] = ".tele BlutmythosinselVerteidigersRuh",
				["ypos"] = 0.463846743106842,
				["xpos"] = 0.3027739822864533,
			},
			["Viridiangrund"] = {
				["cmd"] = ".tele BlutmythosinselViridiangrund",
				["ypos"] = 0.1120674535632134,
				["xpos"] = 0.7474026679992676,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 3,
			},
		},
		["Boreanische Tundra"] = {
			["Au\195\159enposten Bor'gorok"] = {
				["cmd"] = ".tele BoreanischeTundraAussenpostenBorgorok",
				["ypos"] = 0.1105942651629448,
				["xpos"] = 0.4948706924915314,
			},
			["Bernsteinfl\195\182z"] = {
				["cmd"] = ".tele BoreanischeTundraBernsteinfloez",
				["ypos"] = 0.3569864332675934,
				["xpos"] = 0.4632135331630707,
			},
			["Boreanische Tundra"] = {
				["cmd"] = ".tele BoreanischeTundra",
				["ypos"] = 0.4251724481582642,
				["xpos"] = 0.5707616806030273,
			},
			["Der Nexus"] = {
				["cmd"] = ".tele BoreanischeTundraDerNexus",
				["ypos"] = 0.2708231806755066,
				["xpos"] = 0.2748807966709137,
			},
			["Die Geysirfelder"] = {
				["cmd"] = ".tele BoreanischeTundraDieGeysirfelder",
				["ypos"] = 0.3256211876869202,
				["xpos"] = 0.6843050122261047,
			},
			["Echok\195\188ste"] = {
				["cmd"] = ".tele BoreanischeTundraEchokueste",
				["ypos"] = 0.5435776114463806,
				["xpos"] = 0.3216612935066223,
			},
			["Kaskala"] = {
				["cmd"] = ".tele BoreanischeTundraKaskala",
				["ypos"] = 0.4736849665641785,
				["xpos"] = 0.6524779200553894,
			},
			["Kriegshymnenfeste"] = {
				["cmd"] = ".tele BoreanischeTundraKriegshymnenfeste",
				["ypos"] = 0.5369799733161926,
				["xpos"] = 0.413591593503952,
			},
			["Landebahn Kurbelzisch"] = {
				["cmd"] = ".tele BoreanischeTundraLandebahnKurbelzisch",
				["ypos"] = 0.1925844848155975,
				["xpos"] = 0.5579142570495606,
			},
			["Ruinen der Peitschennarbe"] = {
				["cmd"] = ".tele BoreanischeTundraRuinenderPeitschennarbe",
				["ypos"] = 0.9206339120864868,
				["xpos"] = 0.5310640335083008,
			},
			["Strand der Peitschennarbe"] = {
				["cmd"] = ".tele BoreanischeTundraStrandderPeitschennarbe",
				["ypos"] = 0.7715789675712585,
				["xpos"] = 0.4624519646167755,
			},
			["Taunka'le"] = {
				["cmd"] = ".tele BoreanischeTundraTaunkale",
				["ypos"] = 0.377874881029129,
				["xpos"] = 0.7748492956161499,
			},
			["Tempelstadt En'kilah"] = {
				["cmd"] = ".tele BoreanischeTundraTempelstadtEnkilah",
				["ypos"] = 0.304834246635437,
				["xpos"] = 0.8435845375061035,
			},
			["Todeswehr"] = {
				["cmd"] = ".tele BoreanischeTundraTodeswehr",
				["ypos"] = 0.4658644795417786,
				["xpos"] = 0.8202524185180664,
			},
			["Transitusschild"] = {
				["cmd"] = ".tele BoreanischeTundraTransitusschild",
				["ypos"] = 0.3424979746341705,
				["xpos"] = 0.3323211669921875,
			},
			["Unu'pe"] = {
				["cmd"] = ".tele BoreanischeTundraUnupe",
				["ypos"] = 0.51825356,
				["xpos"] = 0.78381088,
			},
			["Valianzfeste"] = {
				["cmd"] = ".tele BoreanischeTundraValianzfeste",
				["ypos"] = 0.6984420418739319,
				["xpos"] = 0.5717418193817139,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 1,
			},
		},
		["Brachland"] = {
			["Agama'gor"] = {
				["cmd"] = ".tele BrachlandAgamagor",
				["ypos"] = 0.5364413857460022,
				["xpos"] = 0.4664971232414246,
			},
			["Bael Modan"] = {
				["cmd"] = ".tele BrachlandBaelModan",
				["ypos"] = 0.8448769450187683,
				["xpos"] = 0.4863805770874023,
			},
			["Camp Taurajo"] = {
				["cmd"] = ".tele BrachlandCampTaurajo",
				["ypos"] = 0.5922589898109436,
				["xpos"] = 0.4481976926326752,
			},
			["Das Schlickmoor"] = {
				["cmd"] = ".tele BrachlandDasSchlickmoor",
				["ypos"] = 0.08184419572353363,
				["xpos"] = 0.5552414655685425,
			},
			["Das Wegekreuz"] = {
				["cmd"] = ".tele BrachlandDasWegekreuz",
				["ypos"] = 0.3061998784542084,
				["xpos"] = 0.5206200480461121,
			},
			["Die bl\195\188hende Oase"] = {
				["cmd"] = ".tele BrachlandDiebluehendeOase",
				["ypos"] = 0.3624829053878784,
				["xpos"] = 0.4665760099887848,
			},
			["Die brackige Oase"] = {
				["cmd"] = ".tele BrachlandDiebrackigeOase",
				["ypos"] = 0.4209735989570618,
				["xpos"] = 0.5576950907707214,
			},
			["Die Feste Nordwacht"] = {
				["cmd"] = ".tele BrachlandDieFesteNordwacht",
				["ypos"] = 0.5327044129371643,
				["xpos"] = 0.6228125095367432,
			},
			["Die H\195\164ndlerk\195\188ste"] = {
				["cmd"] = ".tele BrachlandDieHaendlerkueste",
				["ypos"] = 0.4931108057498932,
				["xpos"] = 0.6363065838813782,
			},
			["Die trockenen Huegel"] = {
				["cmd"] = ".tele BrachlandDietrockenenHuegel",
				["ypos"] = 0.1263294816017151,
				["xpos"] = 0.3925690650939941,
			},
			["Die vergessenen Teiche"] = {
				["cmd"] = ".tele BrachlandDievergessenenTeiche",
				["ypos"] = 0.2290489822626114,
				["xpos"] = 0.451859325170517,
			},
			["Dornenh\195\188gel"] = {
				["cmd"] = ".tele BrachlandDornenhuegel",
				["ypos"] = 0.3051287829875946,
				["xpos"] = 0.6021981239318848,
			},
			["Dornennarbe"] = {
				["cmd"] = ".tele BrachlandDornennarbe",
				["ypos"] = 0.5459402799606323,
				["xpos"] = 0.5244812965393066,
			},
			["Ehrenmal"] = {
				["cmd"] = ".tele BrachlandEhrenmal",
				["ypos"] = 0.275684118270874,
				["xpos"] = 0.3645868301391602,
			},
			["Feld der Riesen"] = {
				["cmd"] = ".tele BrachlandFeldderRiesen",
				["ypos"] = 0.7005898356437683,
				["xpos"] = 0.4885664284229279,
			},
			["Felsadermine"] = {
				["cmd"] = ".tele BrachlandFelsadermine",
				["ypos"] = 0.04241858795285225,
				["xpos"] = 0.6133429408073425,
			},
			["Fernwacht"] = {
				["cmd"] = ".tele BrachlandFernwacht",
				["ypos"] = 0.1967709511518478,
				["xpos"] = 0.6226053833961487,
			},
			["Glutnebelgipfel"] = {
				["cmd"] = ".tele BrachlandGlutnebelgipfel",
				["ypos"] = 0.1900778114795685,
				["xpos"] = 0.4812673032283783,
			},
			["Goldstra\195\159e"] = {
				["cmd"] = ".tele BrachlandGoldstrasse",
				["ypos"] = 0.1473249346017838,
				["xpos"] = 0.5040715932846069,
			},
			["Grol'doms Hof"] = {
				["cmd"] = ".tele BrachlandGroldomsHof",
				["ypos"] = 0.199945405125618,
				["xpos"] = 0.5591896176338196,
			},
			["H\195\188gel der Klingenhauer"] = {
				["cmd"] = ".tele BrachlandHuegelderKlingenhauer",
				["ypos"] = 0.8786023259162903,
				["xpos"] = 0.4670641422271729,
			},
			["Kral der Klingenhauer"] = {
				["cmd"] = ".tele BrachlandKralderKlingenhauer",
				["ypos"] = 0.9008173942565918,
				["xpos"] = 0.424976646900177,
			},
			["Pr\195\188geleiland"] = {
				["cmd"] = ".tele BrachlandPruegeleiland",
				["ypos"] = 0.4866334497928619,
				["xpos"] = 0.6856496930122376,
			},
			["Raptorgr\195\188nde"] = {
				["cmd"] = ".tele BrachlandRaptorgruende",
				["ypos"] = 0.5378214120864868,
				["xpos"] = 0.5764696598052979,
			},
			["Ratschet"] = {
				["cmd"] = ".tele BrachlandRatschet",
				["ypos"] = 0.3776970505714417,
				["xpos"] = 0.6259857416152954,
			},
			["Schutzwall von Mor'shan"] = {
				["cmd"] = ".tele BrachlandSchutzwallvonMorshan",
				["ypos"] = 0.05030740424990654,
				["xpos"] = 0.4778387546539307,
			},
			["Schwarzdorngrat"] = {
				["cmd"] = ".tele BrachlandSchwarzdorngrat",
				["ypos"] = 0.8222057223320007,
				["xpos"] = 0.4346457123756409,
			},
			["St\195\188tzpunkt Mor'shan"] = {
				["cmd"] = ".tele BrachlandStuetzpunktMorshan",
				["ypos"] = 0.08547215163707733,
				["xpos"] = 0.4674974083900452,
			},
			["S\195\188dliche Goldstra\195\159e"] = {
				["cmd"] = ".tele BrachlandSuedlicheGoldstrasse",
				["ypos"] = 0.4913743734359741,
				["xpos"] = 0.5108866095542908,
			},
			["S\195\188dliches Brachland"] = {
				["cmd"] = ".tele BrachlandSuedlichesBrachland",
				["ypos"] = 0.585882306098938,
				["xpos"] = 0.4860857725143433,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 4,
			},
		},
		["Brennende Steppe"] = {
			["Altar der St\195\188rme"] = {
				["cmd"] = ".tele BrennendeSteppeAltarderStuerme",
				["ypos"] = 0.2980816960334778,
				["xpos"] = 0.1689304262399674,
			},
			["Brennende Steppe"] = {
				["cmd"] = ".tele BrennendeSteppeBrennendeSteppe",
				["ypos"] = 0.6100295186042786,
				["xpos"] = 0.3098098933696747,
			},
			["Der geschmolzene \195\156bergang"] = {
				["cmd"] = ".tele BrennendeSteppeDergeschmolzeneUebergang",
				["ypos"] = 0.30,
				["xpos"] = 0.30,
			},
			["Die Ruinen von Thaurissan"] = {
				["cmd"] = ".tele BrennendeSteppeDieRuinenvonThaurissan",
				["ypos"] = 0.3929472863674164,
				["xpos"] = 0.6502670049667358,
			},
			["Flammenkamm"] = {
				["cmd"] = ".tele BrennendeSteppeFlammenkamm",
				["ypos"] = 0.2370599061250687,
				["xpos"] = 0.6536836624145508,
			},
			["Morgans Wacht"] = {
				["cmd"] = ".tele BrennendeSteppeMorgansWacht",
				["ypos"] = 0.6915940642356873,
				["xpos"] = 0.8503430485725403,
			},
			["Schlitterfels"] = {
				["cmd"] = ".tele BrennendeSteppeSchlitterfels",
				["ypos"] = 0.3207400441169739,
				["xpos"] = 0.9336236119270325,
			},
			["Schreckensfels"] = {
				["cmd"] = ".tele BrennendeSteppeSchreckensfels",
				["ypos"] = 0.4576805531978607,
				["xpos"] = 0.8049297332763672,
			},
			["Schreckenspfad"] = {
				["cmd"] = ".tele BrennendeSteppeSchreckenspfad",
				["ypos"] = 0.3475328087806702,
				["xpos"] = 0.9027987718582153,
			},
			["Schwarzfelsfestung"] = {
				["cmd"] = ".tele BrennendeSteppeSchwarzfelsfestung",
				["ypos"] = 0.3569855988025665,
				["xpos"] = 0.4224922060966492,
			},
			["Schwarzfelspass"] = {
				["cmd"] = ".tele BrennendeSteppeSchwarzfelspass",
				["ypos"] = 0.7767494320869446,
				["xpos"] = 0.7831897735595703,
			},
			["Schwarzfelsspitze"] = {
				["cmd"] = ".tele BrennendeSteppeSchwarzfelsspitze",
				["ypos"] = 0.30,
				["xpos"] = 0.32,
			},
			["Schwarzfelstiefen"] = {
				["cmd"] = ".tele BrennendeSteppeSchwarzfelstiefen",
				["ypos"] = 0.30,
				["xpos"] = 0.28,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 3,
			},
		},
		["Dalaran"] = {
			["Das Rattenloch"] = {
				["cmd"] = ".tele DalaranDasRattenloch",
				["ypos"] = 0.3159162998199463,
				["xpos"] = 0.6961627006530762,
			},
			["Die Silberne Enklave"] = {
				["cmd"] = ".tele DalaranDieSilberneEnklave",
				["ypos"] = 0.6110029816627502,
				["xpos"] = 0.3506796061992645,
			},
			["Die Violette Festung"] = {
				["cmd"] = ".tele DalaranDieVioletteFestung",
				["ypos"] = 0.6251950263977051,
				["xpos"] = 0.6199018955230713,
			},
			["Die Violette Zitadelle"] = {
				["cmd"] = ".tele DalaranDieVioletteZitadelle",
				["ypos"] = 0.4733366370201111,
				["xpos"] = 0.254366546869278,
			},
			["Krasus' Landeplatz"] = {
				["cmd"] = ".tele DalaranKrasusLandeplatz",
				["ypos"] = 0.4577653408050537,
				["xpos"] = 0.7218025922775269,
			},
			["Runenweberplatz"] = {
				["cmd"] = ".tele Dalaran",
				["ypos"] = 0.4722547829151154,
				["xpos"] = 0.5156568288803101,
			},
			["Sonnenh\195\164schers Zuflucht"] = {
				["cmd"] = ".tele DalaranSonnenhaeschersZuflucht",
				["ypos"] = 0.2615738809108734,
				["xpos"] = 0.6294768452644348,
			},
			["Zum Gefeierten Helden"] = {
				["cmd"] = ".tele DalaranZumGefeiertenHelden",
				["ypos"] = 0.6348355412483215,
				["xpos"] = 0.4395923912525177,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 2,
			},
		},
		["Darnassus"] = {
			["Darnassus"] = {
				["cmd"] = ".tele Darnassus",
				["ypos"] = 0.4063420593738556,
				["xpos"] = 0.6224513649940491,
			},
			["Die Enklave des Cenarius"] = {
				["cmd"] = ".tele DarnassusDieEnklavedesCenarius",
				["ypos"] = 0.1698707640171051,
				["xpos"] = 0.3778268396854401,
			},
			["Die Terrasse der Handwerker"] = {
				["cmd"] = ".tele DarnassusDieTerrassederHandwerker",
				["ypos"] = 0.2040649354457855,
				["xpos"] = 0.5848051309585571,
			},
			["Die Terrasse der H\195\164ndler"] = {
				["cmd"] = ".tele DarnassusDieTerrassederHaendler",
				["ypos"] = 0.6713175177574158,
				["xpos"] = 0.5903090238571167,
			},
			["Tempel des Mondes"] = {
				["cmd"] = ".tele DarnassusTempeldesMondes",
				["ypos"] = 0.7988340258598328,
				["xpos"] = 0.3907483816146851,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 5,
			},
		},
		["Der heulende Fjord"] = {
			["Apothekerlager"] = {
				["cmd"] = ".tele DerheulendeFjordApothekerlager",
				["ypos"] = 0.2445709258317947,
				["xpos"] = 0.2623399198055267,
			},
			["Au\195\159enposten der Forscherliga"] = {
				["cmd"] = ".tele DerheulendeFjordAussenpostenderForscherliga",
				["ypos"] = 0.6539586186408997,
				["xpos"] = 0.74664705991745,
			},
			["Burg Utgarde"] = {
				["cmd"] = ".tele DerheulendeFjordBurgUtgarde",
				["ypos"] = 0.4971576035022736,
				["xpos"] = 0.5791779756546021,
			},
			["Der heulende Fjord"] = {
				["cmd"] = ".tele DerheulendeFjordDerheulendeFjord",
				["ypos"] = 0.4275414645671845,
				["xpos"] = 0.690987229347229,
			},
			["Der Uralte Aufzug"] = {
				["cmd"] = ".tele DerheulendeFjordDerUralteAufzug",
				["ypos"] = 0.6058663129806519,
				["xpos"] = 0.4004201591014862,
			},
			["Fort Wildervar"] = {
				["cmd"] = ".tele DerheulendeFjordFortWildervar",
				["ypos"] = 0.161787673830986,
				["xpos"] = 0.6026387810707092,
			},
			["Gjalerbron"] = {
				["cmd"] = ".tele DerheulendeFjordGjalerbron",
				["ypos"] = 0.1407718658447266,
				["xpos"] = 0.3359856903553009,
			},
			["Glutst\195\164tte"] = {
				["cmd"] = ".tele DerheulendeFjordGlutstaette",
				["ypos"] = 0.5285967588424683,
				["xpos"] = 0.3790699243545532,
			},
			["Hafen der Vergeltung"] = {
				["cmd"] = ".tele DerheulendeFjordHafenderVergeltung",
				["ypos"] = 0.2942875325679779,
				["xpos"] = 0.7699127197265625,
			},
			["Halunkeneck"] = {
				["cmd"] = ".tele DerheulendeFjordHalunkeneck",
				["ypos"] = 0.8006423711776733,
				["xpos"] = 0.361758828163147,
			},
			["Kamagua"] = {
				["cmd"] = ".tele DerheulendeFjordKamagua",
				["ypos"] = 0.5792458057403565,
				["xpos"] = 0.2530591785907745,
			},
			["Lager der Winterhufe"] = {
				["cmd"] = ".tele DerheulendeFjordLagerderWinterhufe",
				["ypos"] = 0.1152487322688103,
				["xpos"] = 0.4914878606796265,
			},
			["Neu-Agamand"] = {
				["cmd"] = ".tele DerheulendeFjordNeu-Agamand",
				["ypos"] = 0.6836833953857422,
				["xpos"] = 0.5341701507568359,
			},
			["Niffelvar"] = {
				["cmd"] = ".tele DerheulendeFjordNiffelvar",
				["ypos"] = 0.5275923609733582,
				["xpos"] = 0.680059015750885,
			},
			["Plateau der Riesen"] = {
				["cmd"] = ".tele DerheulendeFjordPlateauderRiesen",
				["ypos"] = 0.2695731222629547,
				["xpos"] = 0.6870688199996948,
			},
			["Valgarde"] = {
				["cmd"] = ".tele DerheulendeFjordValgarde",
				["ypos"] = 0.6174845695495606,
				["xpos"] = 0.5941800475120544,
			},
			["Westwacht"] = {
				["cmd"] = ".tele DerheulendeFjordWestwacht",
				["ypos"] = 0.4377095401287079,
				["xpos"] = 0.3117590844631195,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 3,
			},
		},
		["Desolace"] = {
			["Das Tal der Speere"] = {
				["cmd"] = ".tele DesolaceDasTalderSpeere",
				["ypos"] = 0.6199997663497925,
				["xpos"] = 0.3161212801933289,
			},
			["Der Kodofriedhof"] = {
				["cmd"] = ".tele DesolaceDerKodofriedhof",
				["ypos"] = 0.5861648321151733,
				["xpos"] = 0.5328874588012695,
			},
			["Die Insel Ranazjar"] = {
				["cmd"] = ".tele DesolaceDieInselRanazjar",
				["ypos"] = 0.09505275636911392,
				["xpos"] = 0.2941579818725586,
			},
			["Die Nijelspitze"] = {
				["cmd"] = ".tele DesolaceDieNijelspitze",
				["ypos"] = 0.1017613634467125,
				["xpos"] = 0.667674720287323,
			},
			["Ethel Rethor"] = {
				["cmd"] = ".tele DesolaceEthelRethor",
				["ypos"] = 0.2985393106937408,
				["xpos"] = 0.3934962749481201,
			},
			["Festung Donneraxt"] = {
				["cmd"] = ".tele DesolaceFestungDonneraxt",
				["ypos"] = 0.2968337535858154,
				["xpos"] = 0.5614055395126343,
			},
			["Geistwandlerposten"] = {
				["cmd"] = ".tele DesolaceGeistwandlerposten",
				["ypos"] = 0.5365136861801148,
				["xpos"] = 0.5202246308326721,
			},
			["Gelkis"] = {
				["cmd"] = ".tele DesolaceGelkis",
				["ypos"] = 0.8919105529785156,
				["xpos"] = 0.3811625242233276,
			},
			["Kolkar"] = {
				["cmd"] = ".tele DesolaceKolkar",
				["ypos"] = 0.4642792046070099,
				["xpos"] = 0.6988544464111328,
			},
			["Kormeks H\195\188tte"] = {
				["cmd"] = ".tele DesolaceKormeksHuette",
				["ypos"] = 0.3898417055606842,
				["xpos"] = 0.6186206340789795,
			},
			["Magram"] = {
				["cmd"] = ".tele DesolaceMagram",
				["ypos"] = 0.7359822392463684,
				["xpos"] = 0.726326584815979,
			},
			["Maraudon LILA"] = {
				["cmd"] = ".tele DesolaceMaraudonLILA",
				["ypos"] = 0.54756805,
				["xpos"] = 0.30130413,
			},
			["Maraudon ORANGE"] = {
				["cmd"] = ".tele DesolaceMaraudonORANGE",
				["ypos"] = 0.63833107,
				["xpos"] = 0.35974712,
			},
			["Sar'therisstrand"] = {
				["cmd"] = ".tele DesolaceSartherisstrand",
				["ypos"] = 0.781395435333252,
				["xpos"] = 0.2731383442878723,
			},
			["Sargeron"] = {
				["cmd"] = ".tele DesolaceSargeron",
				["ypos"] = 0.231637641787529,
				["xpos"] = 0.7714888453483582,
			},
			["Schattenflucht"] = {
				["cmd"] = ".tele DesolaceSchattenflucht",
				["ypos"] = 0.7041834592819214,
				["xpos"] = 0.2538646459579468,
			},
			["Schattenklamm"] = {
				["cmd"] = ".tele DesolaceSchattenklamm",
				["ypos"] = 0.7721694111824036,
				["xpos"] = 0.795560896396637,
			},
			["Schraubenbuddels Lager"] = {
				["cmd"] = ".tele DesolaceSchraubenbuddelsLager",
				["ypos"] = 0.6246187686920166,
				["xpos"] = 0.6120777726173401,
			},
			["Tethris Aran"] = {
				["cmd"] = ".tele DesolaceTethrisAran",
				["ypos"] = 0.1356431096792221,
				["xpos"] = 0.5437347292900085,
			},
			["Zirkel der Mannoroc"] = {
				["cmd"] = ".tele DesolaceZirkelderMannoroc",
				["ypos"] = 0.7776612043380737,
				["xpos"] = 0.5533664226531982,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 6,
			},
		},
		["Die Exodar"] = {
			["Die Halle des Lichts"] = {
				["cmd"] = ".tele DieExodarDieHalledesLichts",
				["ypos"] = 0.6414707899093628,
				["xpos"] = 0.358671247959137,
			},
			["Die Kristallhalle"] = {
				["cmd"] = ".tele DieExodarDieKristallhalle",
				["ypos"] = 0.2941396534442902,
				["xpos"] = 0.3896138370037079,
			},
			["H\195\164ndlertreppe"] = {
				["cmd"] = ".tele DieExodarHaendlertreppe",
				["ypos"] = 0.7176040410995483,
				["xpos"] = 0.5885219573974609,
			},
			["Sitz der Naaru"] = {
				["cmd"] = ".tele DieExodar",
				["ypos"] = 0.30793297290802,
				["xpos"] = 0.5871977210044861,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 7,
			},
		},
		["Die Sturmgipfel"] = {
			["Absturzstelle Grom'ash"] = {
				["cmd"] = ".tele DieSturmgipfelAbsturzstelleGromash",
				["ypos"] = 0.4910333156585693,
				["xpos"] = 0.3628763258457184,
			},
			["Brunnhildar"] = {
				["cmd"] = ".tele DieSturmgipfelBrunnhildar",
				["ypos"] = 0.669158399105072,
				["xpos"] = 0.5034399628639221,
			},
			["Camp Tunka'lo"] = {
				["cmd"] = ".tele DieSturmgipfelCampTunkalo",
				["ypos"] = 0.5074220299720764,
				["xpos"] = 0.6548846364021301,
			},
			["Die Fu\195\159marschen"] = {
				["cmd"] = ".tele DieSturmgipfelDieFussmarschen",
				["ypos"] = 0.6581665873527527,
				["xpos"] = 0.4315932393074036,
			},
			["Die verschneiten Ebenen"] = {
				["cmd"] = ".tele DieSturmgipfelDieverschneitenEbenen",
				["ypos"] = 0.3971106112003326,
				["xpos"] = 0.2597532272338867,
			},
			["Donnerfall"] = {
				["cmd"] = ".tele DieSturmgipfelDonnerfall",
				["ypos"] = 0.4900104403495789,
				["xpos"] = 0.716128945350647,
			},
			["Dun Niffelem"] = {
				["cmd"] = ".tele DieSturmgipfelDunNiffelem",
				["ypos"] = 0.6075134873390198,
				["xpos"] = 0.6365197896957398,
			},
			["Eisfestung"] = {
				["cmd"] = ".tele DieSturmgipfelEisfestung",
				["ypos"] = 0.7431219816207886,
				["xpos"] = 0.291675329208374,
			},
			["Hallen der Blitze"] = {
				["cmd"] = ".tele DieSturmgipfelHallenderBlitze",
				["ypos"] = 0.2141495794057846,
				["xpos"] = 0.453778088092804,
			},
			["Hallen des Steins"] = {
				["cmd"] = ".tele DieSturmgipfelHallendesSteins",
				["ypos"] = 0.2687548398971558,
				["xpos"] = 0.4010020196437836,
			},
			["K3"] = {
				["cmd"] = ".tele DieSturmgipfelK3",
				["ypos"] = 0.8477792739868164,
				["xpos"] = 0.4046153724193573,
			},
			["Tempel der St\195\188rme"] = {
				["cmd"] = ".tele DieSturmgipfelTempelderStuerme",
				["ypos"] = 0.58400665,
				["xpos"] = 0.33376698,
			},
			["Ulduar"] = {
				["cmd"] = ".tele DieSturmgipfelUlduar",
				["ypos"] = 0.2735401690006256,
				["xpos"] = 0.4356396198272705,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 4,
			},
		},
		["Donnerfels"] = {
			["Die Anh\195\182he der Ältesten"] = {
				["cmd"] = ".tele DonnerfelsDieAnhoehederAeltesten",
				["ypos"] = 0.2972112894058228,
				["xpos"] = 0.7248944640159607,
			},
			["Die Anh\195\182he der Geister"] = {
				["cmd"] = ".tele DonnerfelsDieAnhoehederGeister",
				["ypos"] = 0.2289236783981323,
				["xpos"] = 0.2734218835830689,
			},
			["Die Anh\195\182he der J\195\164ger"] = {
				["cmd"] = ".tele DonnerfelsDieAnhoehederJaeger",
				["ypos"] = 0.7948906421661377,
				["xpos"] = 0.5702462196350098,
			},
			["Die Teiche der Visionen"] = {
				["cmd"] = ".tele DonnerfelsDieTeichederVisionen",
				["ypos"] = 0.2204824984073639,
				["xpos"] = 0.2443952113389969,
			},
			["Donnerfels"] = {
				["cmd"] = ".tele Donnerfels",
				["ypos"] = 0.6140962839126587,
				["xpos"] = 0.3811788856983185,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 8,
			},
		},
		["Drachen�de"] = {
			["Agmars Hammer"] = {
				["cmd"] = ".tele DrachenoedeAgmarsHammer",
				["ypos"] = 0.4658968150615692,
				["xpos"] = 0.3677212297916412,
			},
			["Der Vergessene Strand"] = {
				["cmd"] = ".tele DrachenoedeDerVergesseneStrand",
				["ypos"] = 0.7080708146095276,
				["xpos"] = 0.8493634462356567,
			},
			["Die Grube von Narjun"] = {
				["cmd"] = ".tele DrachenoedeDieGrubevonNarjun",
				["ypos"] = 0.4943678975105286,
				["xpos"] = 0.2624386250972748,
			},
			["Die Kristallschlucht"] = {
				["cmd"] = ".tele DrachenoedeDieKristallschlucht",
				["ypos"] = 0.1837343275547028,
				["xpos"] = 0.5967167615890503,
			},
			["Die Lichtwarte"] = {
				["cmd"] = ".tele DrachenoedeDieLichtwarte",
				["ypos"] = 0.2607429027557373,
				["xpos"] = 0.8416445851325989,
			},
			["Drachen\195\182de"] = {
				["cmd"] = ".tele Drachenoede",
				["ypos"] = 0.3725708425045013,
				["xpos"] = 0.4114561676979065,
			},
			["Eisnebel"] = {
				["cmd"] = ".tele DrachenoedeEisnebel",
				["ypos"] = 0.4234268367290497,
				["xpos"] = 0.2601331472396851,
			},
			["Feste Wintergarde"] = {
				["cmd"] = ".tele DrachenoedeFesteWintergarde",
				["ypos"] = 0.4610995054244995,
				["xpos"] = 0.7811644077301025,
			},
			["Galakronds Ruhest\195\164tte"] = {
				["cmd"] = ".tele DrachenoedeGalakrondsRuhestaette",
				["ypos"] = 0.3735523521900177,
				["xpos"] = 0.5601407885551453,
			},
			["Gallgrimm"] = {
				["cmd"] = ".tele DrachenoedeGallgrimm",
				["ypos"] = 0.6257702708244324,
				["xpos"] = 0.7644043564796448,
			},
			["Hafen Moa'ki"] = {
				["cmd"] = ".tele DrachenoedeHafenMoaki",
				["ypos"] = 0.74713134765625,
				["xpos"] = 0.4904133081436157,
			},
			["Naxxramas"] = {
				["cmd"] = ".tele DrachenoedeNaxxramas",
				["ypos"] = 0.5095888376235962,
				["xpos"] = 0.8719084858894348,
			},
			["Neuherdweiler"] = {
				["cmd"] = ".tele DrachenoedeNeuherdweiler",
				["ypos"] = 0.6934649348258972,
				["xpos"] = 0.7208818197250366,
			},
			["Pfad der Titanen"] = {
				["cmd"] = ".tele DrachenoedePfadderTitanen",
				["ypos"] = 0.5077934861183167,
				["xpos"] = 0.5955246686935425,
			},
			["Sternenruh"] = {
				["cmd"] = ".tele DrachenoedeSternenruh",
				["ypos"] = 0.5517807006835938,
				["xpos"] = 0.2891988158226013,
			},
			["Wyrmruhtempel"] = {
				["cmd"] = ".tele DrachenoedeWyrmruhtempel",
				["ypos"] = 0.5445419549942017,
				["xpos"] = 0.5971635580062866,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 5,
			},
		},
		["Dun Morogh"] = {
			["Ambossar"] = {
				["cmd"] = ".tele DunMoroghAmbossar",
				["ypos"] = 0.6803197860717773,
				["xpos"] = 0.2870185375213623,
			},
			["Br\195\164uhall"] = {
				["cmd"] = ".tele DunMoroghBraeuhall",
				["ypos"] = 0.4543330371379852,
				["xpos"] = 0.3010325431823731,
			},
			["Der Graufelsbau"] = {
				["cmd"] = ".tele DunMoroghDerGraufelsbau",
				["ypos"] = 0.5500807166099548,
				["xpos"] = 0.4264076352119446,
			},
			["Die Tundridh\195\188gel"] = {
				["cmd"] = ".tele DunMoroghDieTundridhuegel",
				["ypos"] = 0.5895010828971863,
				["xpos"] = 0.6039599180221558,
			},
			["Eisenbands Truppenlager"] = {
				["cmd"] = ".tele DunMoroghEisenbandsTruppenlager",
				["ypos"] = 0.6009662747383118,
				["xpos"] = 0.7728250026702881,
			},
			["Eisklammtal"] = {
				["cmd"] = ".tele DunMoroghEisklammtal",
				["ypos"] = 0.7176810503005981,
				["xpos"] = 0.2977368533611298,
			},
			["Eiswellensee"] = {
				["cmd"] = ".tele DunMoroghEiswellensee",
				["ypos"] = 0.4211138188838959,
				["xpos"] = 0.3440589606761932,
			},
			["Frosthauchtal"] = {
				["cmd"] = ".tele DunMoroghFrosthauchtal",
				["ypos"] = 0.5142555832862854,
				["xpos"] = 0.3465253412723541,
			},
			["Geh\195\182ft Bernruh"] = {
				["cmd"] = ".tele DunMoroghGehoeftBernruh",
				["ypos"] = 0.5069100856781006,
				["xpos"] = 0.6354807019233704,
			},
			["Gnomeregan"] = {
				["cmd"] = ".tele DunMoroghGnomeregan",
				["ypos"] = 0.4023135602474213,
				["xpos"] = 0.2447690963745117,
			},
			["Gnomeregan Eingang"] = {
				["cmd"] = ".tele DunMoroghGnomereganEingang",
				["ypos"] = 0.39169544,
				["xpos"] = 0.17820656,
			},
			["Gnomeregan Zugdepot"] = {
				["cmd"] = ".tele DunMoroghGnomereganZugdepot",
				["ypos"] = 0.29905485,
				["xpos"] = 0.21136229,
			},
			["Helmsbettsee"] = {
				["cmd"] = ".tele DunMoroghHelmsbettsee",
				["ypos"] = 0.5256130695343018,
				["xpos"] = 0.7684627175331116,
			},
			["H\195\182hle der Frostm\195\164hnen"] = {
				["cmd"] = ".tele DunMoroghHoehlederFrostmaehnen",
				["ypos"] = 0.5100728273391724,
				["xpos"] = 0.2490487098693848,
			},
			["Kharanos"] = {
				["cmd"] = ".tele DunMoroghKharanos",
				["ypos"] = 0.5193613767623901,
				["xpos"] = 0.4601148068904877,
			},
			["Nebelfichtenzuflucht"] = {
				["cmd"] = ".tele DunMoroghNebelfichtenzuflucht",
				["ypos"] = 0.4495726823806763,
				["xpos"] = 0.5776859521865845,
			},
			["Nordtorau\195\159enposten"] = {
				["cmd"] = ".tele DunMoroghNordtoraussenposten",
				["ypos"] = 0.84651031,
				["xpos"] = 0.41264984,
			},
			["Schimmergrat"] = {
				["cmd"] = ".tele DunMoroghSchimmergrat",
				["ypos"] = 0.4381430447101593,
				["xpos"] = 0.4096756875514984,
			},
			["Stahlrosts Depot"] = {
				["cmd"] = ".tele DunMoroghStahlrostsDepot",
				["ypos"] = 0.4852650463581085,
				["xpos"] = 0.5003848671913147,
			},
			["Steinbruch von Gol'Bolar"] = {
				["cmd"] = ".tele DunMoroghSteinbruchvonGolBolar",
				["ypos"] = 0.5936853289604187,
				["xpos"] = 0.6880514621734619,
			},
			["S\195\188dtorau\195\159enposten"] = {
				["cmd"] = ".tele DunMoroghSuedtoraussenposten",
				["ypos"] = 0.4797060787677765,
				["xpos"] = 0.8626399636268616,
			},
			["Tore von Eisenschmiede"] = {
				["cmd"] = ".tele DunMoroghTorevonEisenschmiede",
				["ypos"] = 0.3536319434642792,
				["xpos"] = 0.5314626097679138,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 5,
			},
		},
		["Dunkelk�ste"] = {
			["Ameth'Aran"] = {
				["cmd"] = ".tele DunkelkuesteAmethAran",
				["ypos"] = 0.595603346824646,
				["xpos"] = 0.4313446283340454,
			},
			["Auberdine"] = {
				["cmd"] = ".tele DunkelkuesteAuberdine",
				["ypos"] = 0.4331917762756348,
				["xpos"] = 0.3749318718910217,
			},
			["Bashal'Aran"] = {
				["cmd"] = ".tele DunkelkuesteBashalAran",
				["ypos"] = 0.3659319579601288,
				["xpos"] = 0.4480843245983124,
			},
			["Bau der Schwarzfelle"] = {
				["cmd"] = ".tele DunkelkuesteBauderSchwarzfelle",
				["ypos"] = 0.8455289602279663,
				["xpos"] = 0.4406544268131256,
			},
			["Der Hain der Uralten"] = {
				["cmd"] = ".tele DunkelkuesteDerHainderUralten",
				["ypos"] = 0.7642885446548462,
				["xpos"] = 0.4364499151706696,
			},
			["Der lange Strand"] = {
				["cmd"] = ".tele DunkelkuesteDerlangeStrand",
				["ypos"] = 0.5504465699195862,
				["xpos"] = 0.3691017925739288,
			},
			["Die Meistergleve"] = {
				["cmd"] = ".tele DunkelkuesteDieMeistergleve",
				["ypos"] = 0.8600893020629883,
				["xpos"] = 0.3850930631160736,
			},
			["Die Ruinen von Mathystra"] = {
				["cmd"] = ".tele DunkelkuesteDieRuinenvonMathystra",
				["ypos"] = 0.2198366075754166,
				["xpos"] = 0.5923660397529602,
			},
			["Dunkelk\195\188ste"] = {
				["cmd"] = ".tele DunkelkuesteDunkelkueste",
				["ypos"] = 0.2059607356786728,
				["xpos"] = 0.6870200634002686,
			},
			["Klippenquell"] = {
				["cmd"] = ".tele DunkelkuesteKlippenquell",
				["ypos"] = 0.3197653293609619,
				["xpos"] = 0.5360746383666992,
			},
			["Nebelrand"] = {
				["cmd"] = ".tele DunkelkuesteNebelrand",
				["ypos"] = 0.1352091133594513,
				["xpos"] = 0.5666463375091553,
			},
			["Turm von Althalaxx"] = {
				["cmd"] = ".tele DunkelkuesteTurmvonAlthalaxx",
				["ypos"] = 0.2647037506103516,
				["xpos"] = 0.5653852820396423,
			},
			["Wirrbarts Ausgrabung"] = {
				["cmd"] = ".tele DunkelkuesteWirrbartsAusgrabung",
				["ypos"] = 0.8342439532279968,
				["xpos"] = 0.3636230826377869,
			},
			["Zwielichtufer"] = {
				["cmd"] = ".tele DunkelkuesteZwielichtufer",
				["ypos"] = 0.7569144368171692,
				["xpos"] = 0.3674689531326294,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 9,
			},
		},
		["Durotar"] = {
			["Burg Tiragarde"] = {
				["cmd"] = ".tele DurotarBurgTiragarde",
				["ypos"] = 0.5709771513938904,
				["xpos"] = 0.5818773508071899,
			},
			["Das Tal der Pr\195\188fungen"] = {
				["cmd"] = ".tele DurotarDasTalderPruefungen",
				["ypos"] = 0.6851152181625366,
				["xpos"] = 0.4336947500705719,
			},
			["Die Echoinseln"] = {
				["cmd"] = ".tele DurotarDieEchoinseln",
				["ypos"] = 0.8319215178489685,
				["xpos"] = 0.6756539940834045,
			},
			["Die Knochenh\195\182hle"] = {
				["cmd"] = ".tele DurotarDieKnochenhoehle",
				["ypos"] = 0.1008519679307938,
				["xpos"] = 0.5512329936027527,
			},
			["Donnergrat"] = {
				["cmd"] = ".tele DurotarDonnergrat",
				["ypos"] = 0.3240097463130951,
				["xpos"] = 0.3916183710098267,
			},
			["Killrogs K\195\188ste"] = {
				["cmd"] = ".tele DurotarKillrogsKueste",
				["ypos"] = 0.2765654623508453,
				["xpos"] = 0.587918221950531,
			},
			["Klingenh\195\188gel"] = {
				["cmd"] = ".tele DurotarKlingenhuegel",
				["ypos"] = 0.4265450537204742,
				["xpos"] = 0.5243443250656128,
			},
			["Klingenschlucht"] = {
				["cmd"] = ".tele DurotarKlingenschlucht",
				["ypos"] = 0.2574911713600159,
				["xpos"] = 0.5054041743278503,
			},
			["Kolkarklippe"] = {
				["cmd"] = ".tele DurotarKolkarklippe",
				["ypos"] = 0.8048123121261597,
				["xpos"] = 0.4987801611423492,
			},
			["Koven der Brennenden Klinge"] = {
				["cmd"] = ".tele DurotarKovenderBrennendenKlinge",
				["ypos"] = 0.5642975568771362,
				["xpos"] = 0.4533283114433289,
			},
			["Messerbucht"] = {
				["cmd"] = ".tele DurotarMesserbucht",
				["ypos"] = 0.1299930810928345,
				["xpos"] = 0.5723616480827332,
			},
			["Revier der Klingenm\195\164hnen"] = {
				["cmd"] = ".tele DurotarRevierderKlingenmaehnen",
				["ypos"] = 0.3980239927768707,
				["xpos"] = 0.4283628463745117,
			},
			["Schipperk\195\188ste"] = {
				["cmd"] = ".tele DurotarSchipperkueste",
				["ypos"] = 0.4441944062709808,
				["xpos"] = 0.603113055229187,
			},
			["Schrein der schlafenden Flamme"] = {
				["cmd"] = ".tele DurotarSchreinderschlafendenFlamme",
				["ypos"] = 0.5820520520210266,
				["xpos"] = 0.3884690403938294,
			},
			["Sen'jin"] = {
				["cmd"] = ".tele DurotarSenjin",
				["ypos"] = 0.7526012063026428,
				["xpos"] = 0.5601494908332825,
			},
			["Staubwindh\195\182hle"] = {
				["cmd"] = ".tele DurotarStaubwindhoehle",
				["ypos"] = 0.2817024290561676,
				["xpos"] = 0.5273904204368591,
			},
			["Staubwindklamm"] = {
				["cmd"] = ".tele DurotarStaubwindklamm",
				["ypos"] = 0.2585271000862122,
				["xpos"] = 0.5383492708206177,
			},
			["Strand der Dunkelspeere"] = {
				["cmd"] = ".tele DurotarStrandderDunkelspeere",
				["ypos"] = 0.8288289904594421,
				["xpos"] = 0.5318700075149536,
			},
			["Tor'krens Hof"] = {
				["cmd"] = ".tele DurotarTorkrensHof",
				["ypos"] = 0.3061468005180359,
				["xpos"] = 0.4331130385398865,
			},
			["Verborgener Pfad"] = {
				["cmd"] = ".tele DurotarVerborgenerPfad",
				["ypos"] = 0.7525293827056885,
				["xpos"] = 0.4263944923877716,
			},
			["Zeppelin Ost"] = {
				["cmd"] = ".tele DurotarZeppelinOst",
				["ypos"] = 0.13489455,
				["xpos"] = 0.50870739,
			},
			["Zeppelin West"] = {
				["cmd"] = ".tele DurotarZeppelinWest",
				["ypos"] = 0.18403214,
				["xpos"] = 0.41563316,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 10,
			},
		},
		["D�stermarschen"] = {
			["Aschenschwinges Bau"] = {
				["cmd"] = ".tele DuestermarschenAschenschwingesBau",
				["ypos"] = 0.8466858267784119,
				["xpos"] = 0.5453569889068604,
			},
			["Beezils Wrack"] = {
				["cmd"] = ".tele DuestermarschenBeezilsWrack",
				["ypos"] = 0.5636733770370483,
				["xpos"] = 0.5338724255561829,
			},
			["Blaumoor"] = {
				["cmd"] = ".tele DuestermarschenBlaumoor",
				["ypos"] = 0.2283269613981247,
				["xpos"] = 0.4091801643371582,
			},
			["Blutsumpfbau"] = {
				["cmd"] = ".tele DuestermarschenBlutsumpfbau",
				["ypos"] = 0.6552035212516785,
				["xpos"] = 0.3243365585803986,
			},
			["Brackenwall"] = {
				["cmd"] = ".tele DuestermarschenBrackenwall",
				["ypos"] = 0.3131561875343323,
				["xpos"] = 0.3599066734313965,
			},
			["Bucht der D\195\188stermarschen"] = {
				["cmd"] = ".tele DuestermarschenBuchtderDuestermarschen",
				["ypos"] = 0.4610609412193298,
				["xpos"] = 0.5465106964111328,
			},
			["Das Drachend\195\188ster"] = {
				["cmd"] = ".tele DuestermarschenDasDrachenduester",
				["ypos"] = 0.6183505654335022,
				["xpos"] = 0.361668586730957,
			},
			["Der Drachensumpf"] = {
				["cmd"] = ".tele DuestermarschenDerDrachensumpf",
				["ypos"] = 0.7569522857666016,
				["xpos"] = 0.5214466452598572,
			},
			["Der Flammenbau"] = {
				["cmd"] = ".tele DuestermarschenDerFlammenbau",
				["ypos"] = 0.6581390500068665,
				["xpos"] = 0.3892704546451569,
			},
			["Die Insel Theramore"] = {
				["cmd"] = ".tele DuestermarschenDieInselTheramore",
				["ypos"] = 0.4845791459083557,
				["xpos"] = 0.6564590930938721,
			},
			["Die verlassene Wacht"] = {
				["cmd"] = ".tele DuestermarschenDieverlasseneWacht",
				["ypos"] = 0.5396876931190491,
				["xpos"] = 0.3550876080989838,
			},
			["Dorf der Schwarzhufe"] = {
				["cmd"] = ".tele DuestermarschenDorfderSchwarzhufe",
				["ypos"] = 0.1238908395171166,
				["xpos"] = 0.4149001240730286,
			},
			["Gasthaus Zur s\195\188\195\159en Ruh"] = {
				["cmd"] = ".tele DuestermarschenGasthausZursuessenRuh",
				["ypos"] = 0.4816933870315552,
				["xpos"] = 0.2963104546070099,
			},
			["Graunebelh\195\182hlen"] = {
				["cmd"] = ".tele DuestermarschenGraunebelhoehlen",
				["ypos"] = 0.2265858203172684,
				["xpos"] = 0.3418114483356476,
			},
			["Grollhornposten"] = {
				["cmd"] = ".tele DuestermarschenGrollhornposten",
				["ypos"] = 0.4722564518451691,
				["xpos"] = 0.4646000266075134,
			},
			["Hexenh\195\188gel"] = {
				["cmd"] = ".tele DuestermarschenHexenhuegel",
				["ypos"] = 0.2402650862932205,
				["xpos"] = 0.587566614151001,
			},
			["Insel Alcaz"] = {
				["cmd"] = ".tele DuestermarschenInselAlcaz",
				["ypos"] = 0.1916948407888413,
				["xpos"] = 0.7059259414672852,
			},
			["Irrlichtanwesen"] = {
				["cmd"] = ".tele DuestermarschenIrrlichtanwesen",
				["ypos"] = 0.2641011476516724,
				["xpos"] = 0.554017186164856,
			},
			["Morastwinkel"] = {
				["cmd"] = ".tele DuestermarschenMorastwinkel",
				["ypos"] = 0.7264257669448853,
				["xpos"] = 0.4185390770435333,
			},
			["Nats Angelplatz"] = {
				["cmd"] = ".tele DuestermarschenNatsAngelplatz",
				["ypos"] = 0.6026541590690613,
				["xpos"] = 0.5861745476722717,
			},
			["Nordwacht"] = {
				["cmd"] = ".tele DuestermarschenNordwacht",
				["ypos"] = 0.2350362241268158,
				["xpos"] = 0.4662209451198578,
			},
			["Ruinen der Steinbrecher"] = {
				["cmd"] = ".tele DuestermarschenRuinenderSteinbrecher",
				["ypos"] = 0.6631790995597839,
				["xpos"] = 0.4381600320339203,
			},
			["Schreckensmoork\195\188ste"] = {
				["cmd"] = ".tele DuestermarschenSchreckensmoorkueste",
				["ypos"] = 0.2798247933387756,
				["xpos"] = 0.6420018672943115,
			},
			["Sp\195\164herwacht"] = {
				["cmd"] = ".tele DuestermarschenSpaeherwacht",
				["ypos"] = 0.4074447751045227,
				["xpos"] = 0.6010094881057739,
			},
			["Tidenbucht"] = {
				["cmd"] = ".tele DuestermarschenTidenbucht",
				["ypos"] = 0.6862650513648987,
				["xpos"] = 0.6018671989440918,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 11,
			},
		},
		["D�mmerwald"] = {
			["Addles Siedlung"] = {
				["cmd"] = ".tele DaemmerwaldAddlesSiedlung",
				["ypos"] = 0.7088519930839539,
				["xpos"] = 0.2090886384248734,
			},
			["Anwesen der Dunstmantels"] = {
				["cmd"] = ".tele DaemmerwaldAnwesenderDunstmantels",
				["ypos"] = 0.350097119808197,
				["xpos"] = 0.7715574502944946,
			},
			["Bettlerschlupfwinkel"] = {
				["cmd"] = ".tele DaemmerwaldBettlerschlupfwinkel",
				["ypos"] = 0.3573524355888367,
				["xpos"] = 0.8759567737579346,
			},
			["Das dunkle Ufer"] = {
				["cmd"] = ".tele DaemmerwaldDasdunkleUfer",
				["ypos"] = 0.1662418693304062,
				["xpos"] = 0.5217740535736084,
			},
			["Das stille Ufer"] = {
				["cmd"] = ".tele DaemmerwaldDasstilleUfer",
				["ypos"] = 0.3361013531684876,
				["xpos"] = 0.0759604275226593,
			},
			["Das verlassene Gut"] = {
				["cmd"] = ".tele DaemmerwaldDasverlasseneGut",
				["ypos"] = 0.3333523273468018,
				["xpos"] = 0.1818660348653793,
			},
			["Der Friedhof Stille G\195\164rten"] = {
				["cmd"] = ".tele DaemmerwaldDerFriedhofStilleGaerten",
				["ypos"] = 0.7085156440734863,
				["xpos"] = 0.8000918030738831,
			},
			["Der verlassene Obstgarten"] = {
				["cmd"] = ".tele DaemmerwaldDerverlasseneObstgarten",
				["ypos"] = 0.7514632344245911,
				["xpos"] = 0.6520919799804688,
			},
			["Dunkelhain"] = {
				["cmd"] = ".tele DaemmerwaldDunkelhain",
				["ypos"] = 0.4663785696029663,
				["xpos"] = 0.7412623763084412,
			},
			["Friedhof von Rabenflucht"] = {
				["cmd"] = ".tele DaemmerwaldFriedhofvonRabenflucht",
				["ypos"] = 0.4462722539901733,
				["xpos"] = 0.1967123001813889,
			},
			["Ogerhort Vul'Gol"] = {
				["cmd"] = ".tele DaemmerwaldOgerhortVulGol",
				["ypos"] = 0.7549810409545898,
				["xpos"] = 0.3391082882881165,
			},
			["Rabenflucht"] = {
				["cmd"] = ".tele DaemmerwaldRabenflucht",
				["ypos"] = 0.5741297602653503,
				["xpos"] = 0.1887738257646561,
			},
			["Schattenhain"] = {
				["cmd"] = ".tele DaemmerwaldSchattenhain",
				["ypos"] = 0.4057470560073853,
				["xpos"] = 0.6137152910232544,
			},
			["Yorgens Bauernhof"] = {
				["cmd"] = ".tele DaemmerwaldYorgensBauernhof",
				["ypos"] = 0.7715191245079041,
				["xpos"] = 0.4941201210021973,
			},
			["Zwielichtshain"] = {
				["cmd"] = ".tele DaemmerwaldZwielichtshain",
				["ypos"] = 0.3712966442108154,
				["xpos"] = 0.4659368097782135,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 4,
			},
		},
		["Eisenschmiede"] = {
			["Das d\195\188stere Viertel"] = {
				["cmd"] = ".tele EisenschmiedeDasduestereViertel",
				["ypos"] = 0.1284994333982468,
				["xpos"] = 0.4906761348247528,
			},
			["Das Milit\195\164rviertel"] = {
				["cmd"] = ".tele EisenschmiedeDasMilitaerviertel",
				["ypos"] = 0.7854745984077454,
				["xpos"] = 0.6446268558502197,
			},
			["Das Mystikerviertel"] = {
				["cmd"] = ".tele EisenschmiedeDasMystikerviertel",
				["ypos"] = 0.2064941972494125,
				["xpos"] = 0.3226931393146515,
			},
			["Die gro\195\159e Schmiede"] = {
				["cmd"] = ".tele EisenschmiedeDiegrosseSchmiede",
				["ypos"] = 0.4295662939548492,
				["xpos"] = 0.5055155754089356,
			},
			["Die Halle der Forscher"] = {
				["cmd"] = ".tele EisenschmiedeDieHallederForscher",
				["ypos"] = 0.2432612031698227,
				["xpos"] = 0.6522518992424011,
			},
			["Eisenschmiede"] = {
				["cmd"] = ".tele Eisenschmiede",
				["ypos"] = 0.6655357480049133,
				["xpos"] = 0.3065593838691711,
			},
			["T\195\188ftlerstadt"] = {
				["cmd"] = ".tele EisenschmiedeTueftlerstadt",
				["ypos"] = 0.4956836104393005,
				["xpos"] = 0.7061669826507568,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 6,
			},
		},
		["Eiskrone"] = {
			["Aldur'thar: Das Tor der Verw\195\188stung"] = {
				["cmd"] = ".tele EiskroneAldurtharDasTorderVerwuestung",
				["ypos"] = 0.3478440344333649,
				["xpos"] = 0.5400015711784363,
			},
			["Argentumturnierplatz"] = {
				["cmd"] = ".tele EiskroneArgentumturnierplatz",
				["ypos"] = 0.2176534533500671,
				["xpos"] = 0.7672799825668335,
			},
			["Das Schattengew\195\182lbe"] = {
				["cmd"] = ".tele EiskroneDasSchattengewoelbe",
				["ypos"] = 0.2453365623950958,
				["xpos"] = 0.4349581599235535,
			},
			["Das Tal der Gefallenen Helden"] = {
				["cmd"] = ".tele EiskroneDasTalderGefallenenHelden",
				["ypos"] = 0.431024968624115,
				["xpos"] = 0.4143308997154236,
			},
			["Die Argentumvorhut"] = {
				["cmd"] = ".tele EiskroneDieArgentumvorhut",
				["ypos"] = 0.7599313259124756,
				["xpos"] = 0.8691603541374207,
			},
			["Die Fleischwerke"] = {
				["cmd"] = ".tele EiskroneDieFleischwerke",
				["ypos"] = 0.6692264676094055,
				["xpos"] = 0.338144838809967,
			},
			["Die gefrorenen Hallen"] = {
				["cmd"] = ".tele EiskroneDiegefrorenenHallen",
				["ypos"] = 0.9064569473266602,
				["xpos"] = 0.5427205562591553,
			},
			["Eiskronenzitadelle"] = {
				["cmd"] = ".tele EiskroneEiskronenzitadelle",
				["ypos"] = 0.8513370156288147,
				["xpos"] = 0.5318591594696045,
			},
			["Hafen des Ansturms"] = {
				["cmd"] = ".tele EiskroneHafendesAnsturms",
				["ypos"] = 0.4387259483337402,
				["xpos"] = 0.09484229981899262,
			},
			["Hrothgars Landestelle"] = {
				["cmd"] = ".tele HrothgarsLandestelleHrothgarsLandestelle",
				["ypos"] = 0.2913234531879425,
				["xpos"] = 0.4508564174175263,
			},
			["Mord'rethar: Das Tor des Todes"] = {
				["cmd"] = ".tele EiskroneMordretharDasTordesTodes",
				["ypos"] = 0.595451831817627,
				["xpos"] = 0.6516869068145752,
			},
			["Njorndar"] = {
				["cmd"] = ".tele EiskroneNjorndar",
				["ypos"] = 0.4679588377475739,
				["xpos"] = 0.294605165719986,
			},
			["Sindragosas Sturz"] = {
				["cmd"] = ".tele EiskroneSindragosasSturz",
				["ypos"] = 0.3714781999588013,
				["xpos"] = 0.7180085778236389,
			},
			["Ymirheim"] = {
				["cmd"] = ".tele EiskroneYmirheim",
				["ypos"] = 0.5275869965553284,
				["xpos"] = 0.5483928322792053,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 6,
			},
		},
		["Eschental"] = {
			["Astranaar"] = {
				["cmd"] = ".tele EschentalAstranaar",
				["ypos"] = 0.5013506412506104,
				["xpos"] = 0.3604040443897247,
			},
			["Au\195\159enposten der Silberschwingen"] = {
				["cmd"] = ".tele EschentalAussenpostenderSilberschwingen",
				["ypos"] = 0.7448593378067017,
				["xpos"] = 0.642339289188385,
			},
			["Au\195\159enposten von Zoram'gar"] = {
				["cmd"] = ".tele EschentalAussenpostenvonZoramgar",
				["ypos"] = 0.3413116335868835,
				["xpos"] = 0.1201733946800232,
			},
			["Bathrans Schlupfwinkel"] = {
				["cmd"] = ".tele EschentalBathransSchlupfwinkel",
				["ypos"] = 0.2179163545370102,
				["xpos"] = 0.3157986998558044,
			},
			["Blutrei\195\159ers Lager"] = {
				["cmd"] = ".tele EschentalBlutreissersLager",
				["ypos"] = 0.7897977828979492,
				["xpos"] = 0.5456483364105225,
			},
			["Das heulende Tal"] = {
				["cmd"] = ".tele EschentalDasheulendeTal",
				["ypos"] = 0.3954800665378571,
				["xpos"] = 0.4988543093204498,
			},
			["Der Falfarren"] = {
				["cmd"] = ".tele EschentalDerFalfarren",
				["ypos"] = 0.7771075367927551,
				["xpos"] = 0.5947332382202148,
			},
			["Der Schattenwinkel"] = {
				["cmd"] = ".tele EschentalDerSchattenwinkel",
				["ypos"] = 0.6142981648445129,
				["xpos"] = 0.6234079599380493,
			},
			["Der Schrein von Aessina"] = {
				["cmd"] = ".tele EschentalDerSchreinvonAessina",
				["ypos"] = 0.5182104706764221,
				["xpos"] = 0.2293018698692322,
			},
			["Der Steinkrallenpfad"] = {
				["cmd"] = ".tele EschentalDerSteinkrallenpfad",
				["ypos"] = 0.7101870179176331,
				["xpos"] = 0.4234276413917542,
			},
			["Der Zoramstrand"] = {
				["cmd"] = ".tele EschentalDerZoramstrand",
				["ypos"] = 0.2655418515205383,
				["xpos"] = 0.1338194161653519,
			},
			["Die Ruinen von Ordil'Aran"] = {
				["cmd"] = ".tele EschentalDieRuinenvonOrdilAran",
				["ypos"] = 0.2978220283985138,
				["xpos"] = 0.3188962638378143,
			},
			["Die Sternenstaubruinen"] = {
				["cmd"] = ".tele EschentalDieSternenstaubruinen",
				["ypos"] = 0.6490820646286011,
				["xpos"] = 0.3448178768157959,
			},
			["D\195\164monenh\195\188gel"] = {
				["cmd"] = ".tele EschentalDaemonenhuegel",
				["ypos"] = 0.6972528696060181,
				["xpos"] = 0.8132352232933044,
			},
			["D\195\164monensturz"] = {
				["cmd"] = ".tele EschentalDaemonensturz",
				["ypos"] = 0.7924569845199585,
				["xpos"] = 0.8249757885932922,
			},
			["Falathimsee"] = {
				["cmd"] = ".tele EschentalFalathimsee",
				["ypos"] = 0.4263916611671448,
				["xpos"] = 0.2024653404951096,
			},
			["Grabh\195\188gel von Dor'Danil"] = {
				["cmd"] = ".tele EschentalGrabhuegelvonDorDanil",
				["ypos"] = 0.7539035081863403,
				["xpos"] = 0.7593970894813538,
			},
			["Hain der Silberschwingen"] = {
				["cmd"] = ".tele EschentalHainderSilberschwingen",
				["ypos"] = 0.8326814770698547,
				["xpos"] = 0.6188567280769348,
			},
			["Holzf\195\164llerlager des Kriegshymnenklans"] = {
				["cmd"] = ".tele EschentalHolzfaellerlagerdesKriegshymnenklans",
				["ypos"] = 0.5803770422935486,
				["xpos"] = 0.896550714969635,
			},
			["Irissee"] = {
				["cmd"] = ".tele EschentalIrissee",
				["ypos"] = 0.4982193410396576,
				["xpos"] = 0.4559305906295776,
			},
			["Lager des Kriegshymnenklans"] = {
				["cmd"] = ".tele EschentalLagerdesKriegshymnenklans",
				["ypos"] = 0.8047010898590088,
				["xpos"] = 0.7207595705986023,
			},
			["Laubtatzenlichtung"] = {
				["cmd"] = ".tele EschentalLaubtatzenlichtung",
				["ypos"] = 0.6262974739074707,
				["xpos"] = 0.5506349802017212,
			},
			["Maestras Posten"] = {
				["cmd"] = ".tele EschentalMaestrasPosten",
				["ypos"] = 0.3753955960273743,
				["xpos"] = 0.2604186534881592,
			},
			["Mystralsee"] = {
				["cmd"] = ".tele EschentalMystralsee",
				["ypos"] = 0.7200527787208557,
				["xpos"] = 0.5308724045753479,
			},
			["Nachtflucht"] = {
				["cmd"] = ".tele EschentalNachtflucht",
				["ypos"] = 0.5588748455047607,
				["xpos"] = 0.6652814149856567,
			},
			["Nachtweisenwald"] = {
				["cmd"] = ".tele EschentalNachtweisenwald",
				["ypos"] = 0.6832118630409241,
				["xpos"] = 0.6198129653930664,
			},
			["Rajenbaum"] = {
				["cmd"] = ".tele EschentalRajenbaum",
				["ypos"] = 0.5201708078384399,
				["xpos"] = 0.6172924637794495,
			},
			["Satyrnaar"] = {
				["cmd"] = ".tele EschentalSatyrnaar",
				["ypos"] = 0.498296320438385,
				["xpos"] = 0.8094069957733154,
			},
			["Schattengr\195\188n"] = {
				["cmd"] = ".tele EschentalSchattengruen",
				["ypos"] = 0.3983331024646759,
				["xpos"] = 0.9376896023750305,
			},
			["Silberwindzuflucht"] = {
				["cmd"] = ".tele EschentalSilberwindzuflucht",
				["ypos"] = 0.6602007150650024,
				["xpos"] = 0.5011392831802368,
			},
			["Splitterholzposten"] = {
				["cmd"] = ".tele EschentalSplitterholzposten",
				["ypos"] = 0.6253456473350525,
				["xpos"] = 0.7352076768875122,
			},
			["Tiefschwarze Grotte"] = {
				["cmd"] = ".tele EschentalTiefschwarzeGrotte",
				["ypos"] = 0.14000000,
				["xpos"] = 0.14000000,
			},
			["Waldeslied"] = {
				["cmd"] = ".tele EschentalWaldeslied",
				["ypos"] = 0.4462966322898865,
				["xpos"] = 0.8606028556823731,
			},
			["Xavian"] = {
				["cmd"] = ".tele EschentalXavian",
				["ypos"] = 0.4534926414489746,
				["xpos"] = 0.7845574617385864,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 12,
			},
		},
		["Feralas"] = {
			["Au\195\159enposten der Gordunni"] = {
				["cmd"] = ".tele FeralasAussenpostenderGordunni",
				["ypos"] = 0.3211227655410767,
				["xpos"] = 0.7634127736091614,
			},
			["Camp Mojache"] = {
				["cmd"] = ".tele FeralasCampMojache",
				["ypos"] = 0.4323051273822784,
				["xpos"] = 0.7481111884117127,
			},
			["Die Insel des Schreckens"] = {
				["cmd"] = ".tele FeralasDieInseldesSchreckens",
				["ypos"] = 0.891755223274231,
				["xpos"] = 0.3496815860271454,
			},
			["Die obere Wildnis"] = {
				["cmd"] = ".tele FeralasDieobereWildnis",
				["ypos"] = 0.4831621050834656,
				["xpos"] = 0.5381464958190918,
			},
			["Die vergessene K\195\188ste"] = {
				["cmd"] = ".tele FeralasDievergesseneKueste",
				["ypos"] = 0.4286616742610931,
				["xpos"] = 0.4506199657917023,
			},
			["Die verwundene Tiefe"] = {
				["cmd"] = ".tele FeralasDieverwundeneTiefe",
				["ypos"] = 0.7481294274330139,
				["xpos"] = 0.6249263286590576,
			},
			["Die Zwillingskolosse"] = {
				["cmd"] = ".tele FeralasDieZwillingskolosse",
				["ypos"] = 0.1991230696439743,
				["xpos"] = 0.4932872951030731,
			},
			["Die Zwillingskolosse WEST"] = {
				["cmd"] = ".tele FeralasDieZwillingskolosseWEST",
				["ypos"] = 0.17364033,
				["xpos"] = 0.43628441,
			},
			["D\195\188sterbruch"] = {
				["cmd"] = ".tele FeralasDuesterbruch",
				["ypos"] = 0.39000000,
				["xpos"] = 0.59136219,
			},
			["D\195\188sterbruch Nordeingang"] = {
				["cmd"] = ".tele FeralasDuesterbruchNordeingang",
				["ypos"] = 0.24922522,
				["xpos"] = 0.62404842,
			},
			["D\195\188sterbruch Osteingang"] = {
				["cmd"] = ".tele FeralasDuesterbruchOsteingang",
				["ypos"] = 0.29755116,
				["xpos"] = 0.64852211,
			},
			["D\195\188sterbruch Portstein"] = {
				["cmd"] = ".tele FeralasDuesterbruchPortstein",
				["ypos"] = 0.44672024,
				["xpos"] = 0.58063835,
			},
			["D\195\188sterbruch Westeingang"] = {
				["cmd"] = ".tele FeralasDuesterbruchWesteingang",
				["ypos"] = 0.30240942,
				["xpos"] = 0.60318512,
			},
			["Fransenfederhochland"] = {
				["cmd"] = ".tele FeralasFransenfederhochland",
				["ypos"] = 0.7115356922149658,
				["xpos"] = 0.542407751083374,
			},
			["Larisspavillon"] = {
				["cmd"] = ".tele FeralasLarisspavillon",
				["ypos"] = 0.3897339403629303,
				["xpos"] = 0.7639647126197815,
			},
			["Mondfederfeste"] = {
				["cmd"] = ".tele FeralasMondfederfeste",
				["ypos"] = 0.4412427842617035,
				["xpos"] = 0.3185100853443146,
			},
			["Oneiros"] = {
				["cmd"] = ".tele FeralasOneiros",
				["ypos"] = 0.1676252484321594,
				["xpos"] = 0.5350397825241089,
			},
			["Ruinen von Isildien"] = {
				["cmd"] = ".tele FeralasRuinenvonIsildien",
				["ypos"] = 0.6905122995376587,
				["xpos"] = 0.5743664503097534,
			},
			["Ruinen von Rabenwind"] = {
				["cmd"] = ".tele FeralasRuinenvonRabenwind",
				["ypos"] = 0.106118768453598,
				["xpos"] = 0.4072211086750031,
			},
			["Ruinen von Solarsal"] = {
				["cmd"] = ".tele FeralasRuinenvonSolarsal",
				["ypos"] = 0.5383873581886292,
				["xpos"] = 0.2769743204116821,
			},
			["Shalzarus Unterschlupf"] = {
				["cmd"] = ".tele FeralasShalzarusUnterschlupf",
				["ypos"] = 0.672493577003479,
				["xpos"] = 0.2605626583099365,
			},
			["Thalanaar"] = {
				["cmd"] = ".tele FeralasThalanaar",
				["ypos"] = 0.4664821624755859,
				["xpos"] = 0.895289957523346,
			},
			["Traumge\195\164st"] = {
				["cmd"] = ".tele FeralasTraumgeaest",
				["ypos"] = 0.1179717257618904,
				["xpos"] = 0.5093174576759338,
			},
			["Truppenlager der Grimmtotem"] = {
				["cmd"] = ".tele FeralasTruppenlagerderGrimmtotem",
				["ypos"] = 0.3929416239261627,
				["xpos"] = 0.6921108365058899,
			},
			["Verdantis"] = {
				["cmd"] = ".tele FeralasVerdantis",
				["ypos"] = 0.5122256278991699,
				["xpos"] = 0.6280643343925476,
			},
			["Waldpfotenh\195\188gel"] = {
				["cmd"] = ".tele FeralasWaldpfotenhuegel",
				["ypos"] = 0.5600647330284119,
				["xpos"] = 0.7149752974510193,
			},
			["Wildschrammtal"] = {
				["cmd"] = ".tele FeralasWildschrammtal",
				["ypos"] = 0.5646038055419922,
				["xpos"] = 0.5545989871025085,
			},
			["Wutschrammfeste"] = {
				["cmd"] = ".tele FeralasWutschrammfeste",
				["ypos"] = 0.3176760971546173,
				["xpos"] = 0.5288598537445068,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 13,
			},
		},
		["Gebirgspass der Totenwinde"] = {
			["Aridens Lager"] = {
				["cmd"] = ".tele GebirgspassderTotenwindeAridensLager",
				["ypos"] = 0.3461717963218689,
				["xpos"] = 0.5229827761650085,
			},
			["Brunnen der Vergessenen"] = {
				["cmd"] = ".tele GebirgspassderTotenwindeBrunnenderVergessenen",
				["ypos"] = 0.7319599986076355,
				["xpos"] = 0.3838226795196533,
			},
			["Das Joch"] = {
				["cmd"] = ".tele GebirgspassderTotenwindeDasJoch",
				["ypos"] = 0.6138578653335571,
				["xpos"] = 0.5831477642059326,
			},
			["Die schlummernde Schlucht"] = {
				["cmd"] = ".tele GebirgspassderTotenwindeDieschlummerndeSchlucht",
				["ypos"] = 0.4355161190032959,
				["xpos"] = 0.5191519260406494,
			},
			["Karazhan"] = {
				["cmd"] = ".tele GebirgspassderTotenwindeKarazhan",
				["ypos"] = 0.7565746307373047,
				["xpos"] = 0.4838598072528839,
			},
			["Morgans Grund"] = {
				["cmd"] = ".tele GebirgspassderTotenwindeMorgansGrund",
				["ypos"] = 0.7461801171302795,
				["xpos"] = 0.3995146751403809,
			},
			["Totmannsfurt"] = {
				["cmd"] = ".tele GebirgspassderTotenwindeTotmannsfurt",
				["ypos"] = 0.3563542366027832,
				["xpos"] = 0.3536674082279205,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 7,
			},
		},
		["Geisterlande"] = {
			["Amanikatakomben"] = {
				["cmd"] = ".tele GeisterlandeAmanikatakomben",
				["ypos"] = 0.2866073846817017,
				["xpos"] = 0.629014253616333,
			},
			["Amanipass"] = {
				["cmd"] = ".tele GeisterlandeAmanipass",
				["ypos"] = 0.6450119018554688,
				["xpos"] = 0.7477385401725769,
			},
			["An'daroth"] = {
				["cmd"] = ".tele GeisterlandeAndaroth",
				["ypos"] = 0.1615627557039261,
				["xpos"] = 0.371034562587738,
			},
			["An'owyn"] = {
				["cmd"] = ".tele GeisterlandeAnowyn",
				["ypos"] = 0.651914656162262,
				["xpos"] = 0.5778080821037293,
			},
			["An'telas"] = {
				["cmd"] = ".tele GeisterlandeAntelas",
				["ypos"] = 0.3713903427124023,
				["xpos"] = 0.6098231673240662,
			},
			["Andiliens Grund"] = {
				["cmd"] = ".tele GeisterlandeAndiliensGrund",
				["ypos"] = 0.5674437284469605,
				["xpos"] = 0.4648779332637787,
			},
			["Die Axth\195\188gel"] = {
				["cmd"] = ".tele GeisterlandeDieAxthuegel",
				["ypos"] = 0.5475060939788818,
				["xpos"] = 0.7278518676757813,
			},
			["Die blutende Ziggurat"] = {
				["cmd"] = ".tele GeisterlandeDieblutendeZiggurat",
				["ypos"] = 0.491544634103775,
				["xpos"] = 0.3435656428337097,
			},
			["Die heulende Ziggurat"] = {
				["cmd"] = ".tele GeisterlandeDieheulendeZiggurat",
				["ypos"] = 0.4808210730552673,
				["xpos"] = 0.4065172374248505,
			},
			["Die Insel Shalandis"] = {
				["cmd"] = ".tele GeisterlandeDieInselShalandis",
				["ypos"] = 0.2566573321819305,
				["xpos"] = 0.1358749121427536,
			},
			["Die Todesfestung"] = {
				["cmd"] = ".tele GeisterlandeDieTodesfestung",
				["ypos"] = 0.7525301575660706,
				["xpos"] = 0.3496050834655762,
			},
			["Elrendarkreuzung"] = {
				["cmd"] = ".tele GeisterlandeElrendarkreuzung",
				["ypos"] = 0.1147254779934883,
				["xpos"] = 0.4840142726898193,
			},
			["Enklave der Weltenwanderer"] = {
				["cmd"] = ".tele GeisterlandeEnklavederWeltenwanderer",
				["ypos"] = 0.302476316690445,
				["xpos"] = 0.7234784960746765,
			},
			["Goldnebel"] = {
				["cmd"] = ".tele GeisterlandeGoldnebel",
				["ypos"] = 0.1764617711305618,
				["xpos"] = 0.2770960628986359,
			},
			["Grubenlichtminen"] = {
				["cmd"] = ".tele GeisterlandeGrubenlichtminen",
				["ypos"] = 0.4878756403923035,
				["xpos"] = 0.2777263820171356,
			},
			["Insel des Martyriums"] = {
				["cmd"] = ".tele GeisterlandeInseldesMartyriums",
				["ypos"] = 0.1015982553362846,
				["xpos"] = 0.6871142387390137,
			},
			["Morgensternturm"] = {
				["cmd"] = ".tele GeisterlandeMorgensternturm",
				["ypos"] = 0.1982437819242477,
				["xpos"] = 0.7718717455863953,
			},
			["Sanktum der Sonne"] = {
				["cmd"] = ".tele GeisterlandeSanktumderSonne",
				["ypos"] = 0.5038573145866394,
				["xpos"] = 0.5434929728507996,
			},
			["Sanktum des Mondes"] = {
				["cmd"] = ".tele GeisterlandeSanktumdesMondes",
				["ypos"] = 0.3286255598068237,
				["xpos"] = 0.3429718613624573,
			},
			["Sonnenh\195\188gel"] = {
				["cmd"] = ".tele Sonnenhuegel",
				["ypos"] = 0.3098438084125519,
				["xpos"] = 0.5367779135704041,
			},
			["Sonnenkuppe"] = {
				["cmd"] = ".tele GeisterlandeSonnenkuppe",
				["ypos"] = 0.133398249745369,
				["xpos"] = 0.5968930721282959,
			},
			["Thalassischer Pass"] = {
				["cmd"] = ".tele GeisterlandeThalassischerPass",
				["ypos"] = 0.8709210753440857,
				["xpos"] = 0.4743717312812805,
			},
			["Tristessa"] = {
				["cmd"] = ".tele GeisterlandeTristessa",
				["ypos"] = 0.3124483525753021,
				["xpos"] = 0.466471791267395,
			},
			["Turm der Verdammten"] = {
				["cmd"] = ".tele GeisterlandeTurmderVerdammten",
				["ypos"] = 0.827716588973999,
				["xpos"] = 0.3348203599452972,
			},
			["Windl\195\164uferdorf"] = {
				["cmd"] = ".tele GeisterlandeWindlaeuferdorf",
				["ypos"] = 0.4602710902690888,
				["xpos"] = 0.1873718649148941,
			},
			["Windl\195\164uferturm"] = {
				["cmd"] = ".tele GeisterlandeWindlaeuferturm",
				["ypos"] = 0.5667983293533325,
				["xpos"] = 0.1358506381511688,
			},
			["Zeb'Nowa"] = {
				["cmd"] = ".tele GeisterlandeZebNowa",
				["ypos"] = 0.6957618594169617,
				["xpos"] = 0.6333293318748474,
			},
			["Zeb'Sora"] = {
				["cmd"] = ".tele GeisterlandeZebSora",
				["ypos"] = 0.1125073507428169,
				["xpos"] = 0.770462691783905,
			},
			["Zeb'Tela"] = {
				["cmd"] = ".tele GeisterlandeZebTela",
				["ypos"] = 0.3957937657833099,
				["xpos"] = 0.7675142288208008,
			},
			["Zul'Aman"] = {
				["cmd"] = ".tele GeisterlandeZulAman",
				["ypos"] = 0.64283020,
				["xpos"] = 0.80919907,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 8,
			},
		},
		["Grizzlyh�gel"] = {
			["Ammertannh\195\188tte"] = {
				["cmd"] = ".tele GrizzlyhuegelAmmertannhuette",
				["ypos"] = 0.5909990668296814,
				["xpos"] = 0.3146520853042603,
			},
			["Blutmondinsel"] = {
				["cmd"] = ".tele GrizzlyhuegelBlutmondinsel",
				["ypos"] = 0.2429875880479813,
				["xpos"] = 0.8377968668937683,
			},
			["Burg Siegeswall"] = {
				["cmd"] = ".tele GrizzlyhuegelBurgSiegeswall",
				["ypos"] = 0.6587561368942261,
				["xpos"] = 0.2164711058139801,
			},
			["Camp Oneqwah"] = {
				["cmd"] = ".tele GrizzlyhuegelCampOneqwah",
				["ypos"] = 0.4762676060199738,
				["xpos"] = 0.6507073044776917,
			},
			["Dun Argol"] = {
				["cmd"] = ".tele GrizzlyhuegelDunArgol",
				["ypos"] = 0.5455047488212585,
				["xpos"] = 0.7477816343307495,
			},
			["Granitquell"] = {
				["cmd"] = ".tele GrizzlyhuegelGranitquell",
				["ypos"] = 0.479919046163559,
				["xpos"] = 0.1639758944511414,
			},
			["Grauschlund"] = {
				["cmd"] = ".tele GrizzlyhuegelGrauschlund",
				["ypos"] = 0.4267075955867767,
				["xpos"] = 0.5060749650001526,
			},
			["Grizzlyh\195\188gel"] = {
				["cmd"] = ".tele Grizzlyhuegel",
				["ypos"] = 0.4619304835796356,
				["xpos"] = 0.3915377855300903,
			},
			["Holzf\195\164llerposten Blauhimmel"] = {
				["cmd"] = ".tele GrizzlyhuegelHolzfaellerpostenBlauhimmel",
				["ypos"] = 0.3529562056064606,
				["xpos"] = 0.3318158686161041,
			},
			["Lager der Westfallbrigade"] = {
				["cmd"] = ".tele GrizzlyhuegelLagerderWestfallbrigade",
				["ypos"] = 0.2812247574329376,
				["xpos"] = 0.5821511149406433,
			},
			["Ruinen von Drakil'jin"] = {
				["cmd"] = ".tele GrizzlyhuegelRuinenvonDrakiljin",
				["ypos"] = 0.2505132555961609,
				["xpos"] = 0.7084673643112183,
			},
			["Silberwasser"] = {
				["cmd"] = ".tele GrizzlyhuegelSilberwasser",
				["ypos"] = 0.333867609500885,
				["xpos"] = 0.2536882758140564,
			},
			["Thor Modan"] = {
				["cmd"] = ".tele GrizzlyhuegelThorModan",
				["ypos"] = 0.2122590690851212,
				["xpos"] = 0.644210159778595,
			},
			["Ursocs H\195\182hle"] = {
				["cmd"] = ".tele GrizzlyhuegelUrsocsHoehle",
				["ypos"] = 0.2384704351425171,
				["xpos"] = 0.5220539569854736,
			},
			["Venturebucht"] = {
				["cmd"] = ".tele GrizzlyhuegelVenturebucht",
				["ypos"] = 0.7930418848991394,
				["xpos"] = 0.1552063673734665,
			},
			["Voldrune"] = {
				["cmd"] = ".tele GrizzlyhuegelVoldrune",
				["ypos"] = 0.741581916809082,
				["xpos"] = 0.2650292217731476,
			},
			["Zeb'Halak"] = {
				["cmd"] = ".tele GrizzlyhuegelZebHalak",
				["ypos"] = 0.3614276051521301,
				["xpos"] = 0.1648235023021698,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 7,
			},
		},
		["Hinterland"] = {
			["Agol'watha"] = {
				["cmd"] = ".tele HinterlandAgolwatha",
				["ypos"] = 0.3993223309516907,
				["xpos"] = 0.4568570554256439,
			},
			["Bogens Kante"] = {
				["cmd"] = ".tele HinterlandBogensKante",
				["ypos"] = 0.6641678214073181,
				["xpos"] = 0.2590495049953461,
			},
			["Der Altar von Zul"] = {
				["cmd"] = ".tele HinterlandDerAltarvonZul",
				["ypos"] = 0.6860572099685669,
				["xpos"] = 0.4908128380775452,
			},
			["Die Aussichtsklippen"] = {
				["cmd"] = ".tele HinterlandDieAussichtsklippen",
				["ypos"] = 0.6629902720451355,
				["xpos"] = 0.7255702018737793,
			},
			["Die Gruselruinen"] = {
				["cmd"] = ".tele HinterlandDieGruselruinen",
				["ypos"] = 0.5264684557914734,
				["xpos"] = 0.4867868423461914,
			},
			["Dorf der Bruchhauer"] = {
				["cmd"] = ".tele HinterlandDorfderBruchhauer",
				["ypos"] = 0.778181791305542,
				["xpos"] = 0.7997402548789978,
			},
			["Ehrenwindsee"] = {
				["cmd"] = ".tele HinterlandEhrenwindsee",
				["ypos"] = 0.6170662641525269,
				["xpos"] = 0.4026902318000794,
			},
			["Federbarts H\195\188tte"] = {
				["cmd"] = ".tele HinterlandFederbartsHuette",
				["ypos"] = 0.5393909215927124,
				["xpos"] = 0.1326467394828796,
			},
			["Hinterland"] = {
				["cmd"] = ".tele HinterlandHinterland",
				["ypos"] = 0.5214276909828186,
				["xpos"] = 0.4219301044940949,
			},
			["Hiri'watha"] = {
				["cmd"] = ".tele HinterlandHiriwatha",
				["ypos"] = 0.57797771692276,
				["xpos"] = 0.319502204656601,
			},
			["Jagdh\195\188tte von Quel'Danil"] = {
				["cmd"] = ".tele HinterlandJagdhuettevonQuelDanil",
				["ypos"] = 0.4674255847930908,
				["xpos"] = 0.3055610060691834,
			},
			["Jintha'Alor"] = {
				["cmd"] = ".tele HinterlandJinthaAlor",
				["ypos"] = 0.7529802918434143,
				["xpos"] = 0.592531681060791,
			},
			["Kniegr\195\164bers Lager"] = {
				["cmd"] = ".tele HinterlandKniegraebersLager",
				["ypos"] = 0.4841766953468323,
				["xpos"] = 0.2680322229862213,
			},
			["Lauerfels"] = {
				["cmd"] = ".tele HinterlandLauerfels",
				["ypos"] = 0.4276460409164429,
				["xpos"] = 0.5755172967910767,
			},
			["Nistgipfel"] = {
				["cmd"] = ".tele HinterlandNistgipfel",
				["ypos"] = 0.4721642732620239,
				["xpos"] = 0.1215906217694283,
			},
			["Seradane"] = {
				["cmd"] = ".tele HinterlandSeradane",
				["ypos"] = 0.2918753027915955,
				["xpos"] = 0.6354987025260925,
			},
			["Shadra'Alor"] = {
				["cmd"] = ".tele HinterlandShadraAlor",
				["ypos"] = 0.752288818359375,
				["xpos"] = 0.3278519511222839,
			},
			["Shaol'watha"] = {
				["cmd"] = ".tele HinterlandShaolwatha",
				["ypos"] = 0.5328291654586792,
				["xpos"] = 0.7282874584197998,
			},
			["Zun'watha"] = {
				["cmd"] = ".tele HinterlandZunwatha",
				["ypos"] = 0.5853471755981445,
				["xpos"] = 0.2349376678466797,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 9,
			},
		},
		["H�llenfeuerhalbinsel"] = {
			["Au\195\159enposten von Gor'gaz"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselAussenpostenvonGorgaz",
				["ypos"] = 0.7506991028785706,
				["xpos"] = 0.4492450058460236,
			},
			["Das Stadion"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDasStadion",
				["ypos"] = 0.5152470469474793,
				["xpos"] = 0.3555259108543396,
			},
			["Der Blutkessel"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDerBlutkessel",
				["ypos"] = 0.51729816,
				["xpos"] = 0.46058510,
			},
			["Der Pfad der Pein"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDerPfadderPein",
				["ypos"] = 0.5759140849113464,
				["xpos"] = 0.6751238107681274,
			},
			["Der Rundblick"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDerRundblick",
				["ypos"] = 0.477098822593689,
				["xpos"] = 0.3972949981689453,
			},
			["Die abyssische Untiefe"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDieabyssischeUntiefe",
				["ypos"] = 0.1773076057434082,
				["xpos"] = 0.725455105304718,
			},
			["Die Front der Legion"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDieFrontderLegion",
				["ypos"] = 0.5713707804679871,
				["xpos"] = 0.7299878597259522,
			},
			["Die gro\195\159e Kluft"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDiegrosseKluft",
				["ypos"] = 0.6084486246109009,
				["xpos"] = 0.3466364741325378,
			},
			["Die Sph\195\164renfelder"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDieSphaerenfelder",
				["ypos"] = 0.837668240070343,
				["xpos"] = 0.4766101837158203,
			},
			["Die Stufen des Schicksals"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDieStufendesSchicksals",
				["ypos"] = 0.5027934908866882,
				["xpos"] = 0.8699836730957031,
			},
			["Die Tr\195\188mmerbastion"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDieTruemmerbastion",
				["ypos"] = 0.5875807404518127,
				["xpos"] = 0.3986832797527313,
			},
			["Dornnebelh\195\188gel"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselDornnebelhuegel",
				["ypos"] = 0.5043929219245911,
				["xpos"] = 0.08069052547216415,
			},
			["Ehrenfeste"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselEhrenfeste",
				["ypos"] = 0.6274006962776184,
				["xpos"] = 0.5559447407722473,
			},
			["Expeditionsposten"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselExpeditionsposten",
				["ypos"] = 0.6209248900413513,
				["xpos"] = 0.7112680673599243,
			},
			["Expeditionsr\195\188stlager"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselExpeditionsruestlager",
				["ypos"] = 0.7872755527496338,
				["xpos"] = 0.5546784996986389,
			},
			["Falkenwacht"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselFalkenwacht",
				["ypos"] = 0.606408417224884,
				["xpos"] = 0.2785787582397461,
			},
			["Grund der Mag'har"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselGrundderMaghar",
				["ypos"] = 0.3202096521854401,
				["xpos"] = 0.3597566187381744,
			},
			["Haal'eshbau"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselHaaleshbau",
				["ypos"] = 0.7499179840087891,
				["xpos"] = 0.2579614222049713,
			},
			["Himmelssturzgrat"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselHimmelssturzgrat",
				["ypos"] = 0.4187929630279541,
				["xpos"] = 0.1688564717769623,
			},
			["H\195\164schersturz"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselHaeschersturz",
				["ypos"] = 0.4410111308097839,
				["xpos"] = 0.6578852534294128,
			},
			["H\195\182llenfeuerbollwerk"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselHoellenfeuerbollwerk",
				["ypos"] = 0.53552933,
				["xpos"] = 0.47671726,
			},
			["H\195\182llenfeuerzitadelle"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselHoellenfeuerzitadelle",
				["ypos"] = 0.5165572762489319,
				["xpos"] = 0.4849922955036163,
			},
			["Invasionspunkt: Vernichter"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselInvasionspunktVernichter",
				["ypos"] = 0.2737936973571777,
				["xpos"] = 0.5368512868881226,
			},
			["Kil'jaedens Thron"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselKiljaedensThron",
				["ypos"] = 0.2026537954807282,
				["xpos"] = 0.6283126473426819,
			},
			["Konstruktionslager: Mageddon"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselKonstruktionslagerMageddon",
				["ypos"] = 0.3190301358699799,
				["xpos"] = 0.6491701602935791,
			},
			["Konstruktionslager: Zorn"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselKonstruktionslagerZorn",
				["ypos"] = 0.3143042027950287,
				["xpos"] = 0.5882300734519959,
			},
			["Leerengrat"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselLeerengrat",
				["ypos"] = 0.6795670390129089,
				["xpos"] = 0.777875542640686,
			},
			["Magtheridons Kammer"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselMagtheridonsKammer",
				["ypos"] = 0.52783192,
				["xpos"] = 0.46617802,
			},
			["Messerdornpfad"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselMesserdornpfad",
				["ypos"] = 0.8835194706916809,
				["xpos"] = 0.3823218643665314,
			},
			["N\195\182rdliches Bollwerk"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselNoerdlichesBollwerk",
				["ypos"] = 0.4321597814559937,
				["xpos"] = 0.4564169347286224,
			},
			["Posten der Mag'har"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselPostenderMaghar",
				["ypos"] = 0.2789528965950012,
				["xpos"] = 0.3204911351203919,
			},
			["Posten des Cenarius"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselPostendesCenarius",
				["ypos"] = 0.5242279767990112,
				["xpos"] = 0.1582340449094772,
			},
			["Ruinen von Sha'naar"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselRuinenvonShanaar",
				["ypos"] = 0.6145614981651306,
				["xpos"] = 0.1429782062768936,
			},
			["R\195\188ckenbrecherberge"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselRueckenbrecherberge",
				["ypos"] = 0.8425902128219605,
				["xpos"] = 0.6260879039764404,
			},
			["R\195\188ckenbrecherpass"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselRueckenbrecherpass",
				["ypos"] = 0.6716216206550598,
				["xpos"] = 0.7308185696601868,
			},
			["R\195\188ckenbrecherposten"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselRueckenbrecherposten",
				["ypos"] = 0.8079738616943359,
				["xpos"] = 0.6105939149856567,
			},
			["Schlucht der Haal'eshi"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselSchluchtderHaaleshi",
				["ypos"] = 0.7883818745613098,
				["xpos"] = 0.2842248976230621,
			},
			["Staubstachelschlucht"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselStaubstachelschlucht",
				["ypos"] = 0.6671422123908997,
				["xpos"] = 0.2235016822814941,
			},
			["S\195\188dliches Bollwerk"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselSuedlichesBollwerk",
				["ypos"] = 0.756727397441864,
				["xpos"] = 0.4377958476543427,
			},
			["Tal der Knochen"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselTalderKnochen",
				["ypos"] = 0.6877447962760925,
				["xpos"] = 0.6228795647621155,
			},
			["Teiche von Aggonar"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselTeichevonAggonar",
				["ypos"] = 0.329272449016571,
				["xpos"] = 0.4144793450832367,
			},
			["Tempel von Telhamat"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselTempelvonTelhamat",
				["ypos"] = 0.3886562883853912,
				["xpos"] = 0.2337097078561783,
			},
			["Teufelsfunkenklamm"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselTeufelsfunkenklamm",
				["ypos"] = 0.3679184019565582,
				["xpos"] = 0.6270114779472351,
			},
			["Thrallmar"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselThrallmar",
				["ypos"] = 0.3885587155818939,
				["xpos"] = 0.5550096035003662,
			},
			["Tr\195\188mmerposten"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselTruemmerposten",
				["ypos"] = 0.3520746529102325,
				["xpos"] = 0.7880777716636658,
			},
			["Versorgungskarawane"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselVersorgungskarawane",
				["ypos"] = 0.413403332233429,
				["xpos"] = 0.5808761119842529,
			},
			["Weiten von Sha'naari"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselWeitenvonShanaari",
				["ypos"] = 0.5649376511573792,
				["xpos"] = 0.1430866569280624,
			},
			["Zeppelinabsturzstelle"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselZeppelinabsturzstelle",
				["ypos"] = 0.7415869235992432,
				["xpos"] = 0.492932915687561,
			},
			["Zeth'Gor"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselZethGor",
				["ypos"] = 0.7306018471717835,
				["xpos"] = 0.6794649362564087,
			},
			["\195\150stliche Versorgungskarawane"] = {
				["cmd"] = ".tele HoellenfeuerhalbinselOestlicheVersorgungskarawane",
				["ypos"] = 0.6053157448768616,
				["xpos"] = 0.6139107346534729,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 1,
			},
		},
		["Immersangwald"] = {
			["Akademie von Faltherien"] = {
				["cmd"] = ".tele ImmersangwaldAkademievonFaltherien",
				["ypos"] = 0.2711775600910187,
				["xpos"] = 0.3081400692462921,
			},
			["Ankerplatz der Sonnensegel"] = {
				["cmd"] = ".tele ImmersangwaldAnkerplatzderSonnensegel",
				["ypos"] = 0.6815286874771118,
				["xpos"] = 0.3276953995227814,
			},
			["Azurblaue K\195\188ste"] = {
				["cmd"] = ".tele ImmersangwaldAzurblaueKueste",
				["ypos"] = 0.4332109987735748,
				["xpos"] = 0.7233177423477173,
			},
			["Der goldene Strand"] = {
				["cmd"] = ".tele ImmersangwaldDergoldeneStrand",
				["ypos"] = 0.729245662689209,
				["xpos"] = 0.249502494931221,
			},
			["Der lebende Wald"] = {
				["cmd"] = ".tele ImmersangwaldDerlebendeWald",
				["ypos"] = 0.718366265296936,
				["xpos"] = 0.5910558700561523,
			},
			["Der Sonnenturm"] = {
				["cmd"] = ".tele ImmersangwaldDerSonnenturm",
				["ypos"] = 0.2106293886899948,
				["xpos"] = 0.3842112123966217,
			},
			["Der versengte Hain"] = {
				["cmd"] = ".tele ImmersangwaldDerversengteHain",
				["ypos"] = 0.8611878156661987,
				["xpos"] = 0.3687736093997955,
			},
			["Die stille K\195\188ste"] = {
				["cmd"] = ".tele ImmersangwaldDiestilleKueste",
				["ypos"] = 0.6036049127578735,
				["xpos"] = 0.2919695973396301,
			},
			["Die Todesschneise"] = {
				["cmd"] = ".tele ImmersangwaldDieTodesschneise",
				["ypos"] = 0.6200251579284668,
				["xpos"] = 0.4933780133724213,
			},
			["D\195\164mmerweg"] = {
				["cmd"] = ".tele ImmersangwaldDaemmerweg",
				["ypos"] = 0.4057358801364899,
				["xpos"] = 0.4388954341411591,
			},
			["Elrendarf\195\164lle"] = {
				["cmd"] = ".tele ImmersangwaldElrendarfaelle",
				["ypos"] = 0.7385073900222778,
				["xpos"] = 0.6488588452339172,
			},
			["Elrendarsee"] = {
				["cmd"] = ".tele ImmersangwaldElrendarsee",
				["ypos"] = 0.7894922494888306,
				["xpos"] = 0.6627066135406494,
			},
			["Falkenplatz"] = {
				["cmd"] = ".tele ImmersangwaldFalkenplatz",
				["ypos"] = 0.4641247093677521,
				["xpos"] = 0.4755938649177551,
			},
			["Goldblattpass"] = {
				["cmd"] = ".tele ImmersangwaldGoldblattpass",
				["ypos"] = 0.8003683686256409,
				["xpos"] = 0.3382213711738586,
			},
			["Hirtentor"] = {
				["cmd"] = ".tele ImmersangwaldHirtentor",
				["ypos"] = 0.4958789646625519,
				["xpos"] = 0.5665624141693115,
			},
			["Insel der Sonnenwanderer"] = {
				["cmd"] = ".tele ImmersangwaldInselderSonnenwanderer",
				["ypos"] = 0.2234560549259186,
				["xpos"] = 0.3545183539390564,
			},
			["Morgenluft"] = {
				["cmd"] = ".tele ImmersangwaldMorgenluft",
				["ypos"] = 0.7010912299156189,
				["xpos"] = 0.445427417755127,
			},
			["Nachtschimmergrund"] = {
				["cmd"] = ".tele ImmersangwaldNachtschimmergrund",
				["ypos"] = 0.4695611298084259,
				["xpos"] = 0.686556339263916,
			},
			["Nachtschimmerturm"] = {
				["cmd"] = ".tele ImmersangwaldNachtschimmerturm",
				["ypos"] = 0.518204391002655,
				["xpos"] = 0.690187394618988,
			},
			["Runenstein Falithas"] = {
				["cmd"] = ".tele ImmersangwaldRunensteinFalithas",
				["ypos"] = 0.8596649765968323,
				["xpos"] = 0.4472933709621429,
			},
			["Runenstein Shan'dor"] = {
				["cmd"] = ".tele ImmersangwaldRunensteinShandor",
				["ypos"] = 0.8519502282142639,
				["xpos"] = 0.5497502684593201,
			},
			["Saltherils Hafen"] = {
				["cmd"] = ".tele ImmersangwaldSaltherilsHafen",
				["ypos"] = 0.7249177694320679,
				["xpos"] = 0.3845096230506897,
			},
			["Sanktum des Nordens"] = {
				["cmd"] = ".tele ImmersangwaldSanktumdesNordens",
				["ypos"] = 0.5321226119995117,
				["xpos"] = 0.4461014866828919,
			},
			["Sanktum des Ostens"] = {
				["cmd"] = ".tele ImmersangwaldSanktumdesOstens",
				["ypos"] = 0.6985267996788025,
				["xpos"] = 0.5260528326034546,
			},
			["Sanktum des Westens"] = {
				["cmd"] = ".tele ImmersangwaldSanktumdesWestens",
				["ypos"] = 0.5837743282318115,
				["xpos"] = 0.355949193239212,
			},
			["Schrein von Dath'Remar"] = {
				["cmd"] = ".tele ImmersangwaldSchreinvonDathRemar",
				["ypos"] = 0.1949440985918045,
				["xpos"] = 0.2970700263977051,
			},
			["Stillwispert\195\188mpel"] = {
				["cmd"] = ".tele ImmersangwaldStillwispertuempel",
				["ypos"] = 0.54615718126297,
				["xpos"] = 0.5567208528518677,
			},
			["Thurons Aufzucht"] = {
				["cmd"] = ".tele ImmersangwaldThuronsAufzucht",
				["ypos"] = 0.5422191619873047,
				["xpos"] = 0.6096020340919495,
			},
			["Tor'Watha"] = {
				["cmd"] = ".tele ImmersangwaldTorWatha",
				["ypos"] = 0.761806845664978,
				["xpos"] = 0.7104690670967102,
			},
			["Zeb'Watha"] = {
				["cmd"] = ".tele ImmersangwaldZebWatha",
				["ypos"] = 0.7823744416236877,
				["xpos"] = 0.6377441883087158,
			},
			["Zuflucht der Weltenwanderer"] = {
				["cmd"] = ".tele ImmersangwaldZufluchtderWeltenwanderer",
				["ypos"] = 0.6253786087036133,
				["xpos"] = 0.6127938628196716,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 10,
			},
		},
		["Insel von Quel'Danas"] = {
			["Die Sin'loren"] = {
				["cmd"] = ".tele InselvonQuelDanasDieSinloren",
				["ypos"] = 0.1643939912319183,
				["xpos"] = 0.5247679948806763,
			},
			["Die Todesschneise"] = {
				["cmd"] = ".tele InselvonQuelDanasDieTodesschneise",
				["ypos"] = 0.8797160387039185,
				["xpos"] = 0.5360302329063416,
			},
			["Hafen der Sonnenweiten"] = {
				["cmd"] = ".tele InselvonQuelDanasHafenderSonnenweiten",
				["ypos"] = 0.2555758059024811,
				["xpos"] = 0.4827733635902405,
			},
			["Insel von Quel'Danas"] = {
				["cmd"] = ".tele InselvonQuelDanasInselvonQuelDanas",
				["ypos"] = 0.4040472805500031,
				["xpos"] = 0.3259904086589813,
			},
			["K\195\188ste der Gr\195\188nkiemen"] = {
				["cmd"] = ".tele InselvonQuelDanasKuestederGruenkiemen",
				["ypos"] = 0.4496177136898041,
				["xpos"] = 0.5948173999786377,
			},
			["Morgenstern"] = {
				["cmd"] = ".tele Morgenstern",
				["ypos"] = 0.3917968273162842,
				["xpos"] = 0.4294052720069885,
			},
			["Platz der Morgenr\195\182te"] = {
				["cmd"] = ".tele InselvonQuelDanasPlatzderMorgenroete",
				["ypos"] = 0.4368404150009155,
				["xpos"] = 0.4844444990158081,
			},
			["Sammelpunkt der Zerschmetterten Sonne"] = {
				["cmd"] = ".tele InselvonQuelDanasSammelpunktderZerschmettertenSonn",
				["ypos"] = 0.2942646443843842,
				["xpos"] = 0.4688662886619568,
			},
			["Silbermonds Stolz"] = {
				["cmd"] = ".tele InselvonQuelDanasSilbermondsStolz",
				["ypos"] = 0.3386634290218353,
				["xpos"] = 0.5403103232383728,
			},
			["Sonnenbrunnenplateau"] = {
				["cmd"] = ".tele InselvonQuelDanasSonnenbrunnenplateau",
				["ypos"] = 0.4393686056137085,
				["xpos"] = 0.4432461559772492,
			},
			["Terrasse der Magister"] = {
				["cmd"] = ".tele InselvonQuelDanasTerrassederMagister",
				["ypos"] = 0.3079477548599243,
				["xpos"] = 0.604083776473999,
			},
			["Waffenkammer der Sonnenweiten"] = {
				["cmd"] = ".tele InselvonQuelDanasWaffenkammerderSonnenweiten",
				["ypos"] = 0.3962770104408264,
				["xpos"] = 0.4962866902351379,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 11,
			},
		},
		["Krater von Un'Goro"] = {
			["Die hei\195\159en Quellen von Golakka"] = {
				["cmd"] = ".tele KratervonUnGoroDieheissenQuellenvonGolakka",
				["ypos"] = 0.49852654337883,
				["xpos"] = 0.3146022260189056,
			},
			["Die Marschen"] = {
				["cmd"] = ".tele KratervonUnGoroDieMarschen",
				["ypos"] = 0.5348688960075378,
				["xpos"] = 0.7184847593307495,
			},
			["Die wuchernde Narbe"] = {
				["cmd"] = ".tele KratervonUnGoroDiewucherndeNarbe",
				["ypos"] = 0.772642970085144,
				["xpos"] = 0.5075989961624146,
			},
			["Feuers\195\164ulengrat"] = {
				["cmd"] = ".tele KratervonUnGoroFeuersaeulengrat",
				["ypos"] = 0.4885179102420807,
				["xpos"] = 0.4900496304035187,
			},
			["Fungusfels"] = {
				["cmd"] = ".tele KratervonUnGoroFungusfels",
				["ypos"] = 0.1762896031141281,
				["xpos"] = 0.6187014579772949,
			},
			["Krater von Un'Goro"] = {
				["cmd"] = ".tele KratervonUnGoroKratervonUnGoro",
				["ypos"] = 0.7969548106193543,
				["xpos"] = 0.7224159240722656,
			},
			["Marschalls Zuflucht"] = {
				["cmd"] = ".tele KratervonUnGoroMarschallsZuflucht",
				["ypos"] = 0.08915158361196518,
				["xpos"] = 0.4432874917984009,
			},
			["Teergruben von Lakkari"] = {
				["cmd"] = ".tele KratervonUnGoroTeergrubenvonLakkari",
				["ypos"] = 0.2073807120323181,
				["xpos"] = 0.4493687450885773,
			},
			["Terrorflucht"] = {
				["cmd"] = ".tele KratervonUnGoroTerrorflucht",
				["ypos"] = 0.7703041434288025,
				["xpos"] = 0.3144225478172302,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 14,
			},
		},
		["Kristallsangwald"] = {
			["Der versiegende Strom"] = {
				["cmd"] = ".tele KristallsangwaldDerversiegendeStrom",
				["ypos"] = 0.1803296655416489,
				["xpos"] = 0.200445368885994,
			},
			["Die trostlosen W\195\164lder"] = {
				["cmd"] = ".tele KristallsangwaldDietrostlosenWaelder",
				["ypos"] = 0.3982034623622894,
				["xpos"] = 0.4777777493000031,
			},
			["Die Violette Wacht"] = {
				["cmd"] = ".tele KristallsangwaldDieVioletteWacht",
				["ypos"] = 0.4222033619880676,
				["xpos"] = 0.1522375047206879,
			},
			["Kristallsangwald"] = {
				["cmd"] = ".tele Kristallsangwald",
				["ypos"] = 0.5929478406906128,
				["xpos"] = 0.4309823513031006,
			},
			["Sonnenh\195\164schers Schar"] = {
				["cmd"] = ".tele KristallsangwaldSonnenhaeschersSchar",
				["ypos"] = 0.4947544038295746,
				["xpos"] = 0.7492682337760925,
			},
			["Unb\195\164ndiges Dickicht"] = {
				["cmd"] = ".tele KristallsangwaldUnbaendigesDickicht",
				["ypos"] = 0.5725023746490479,
				["xpos"] = 0.6908676624298096,
			},
			["Windl\195\164ufers Warte"] = {
				["cmd"] = ".tele KristallsangwaldWindlaeufersWarte",
				["ypos"] = 0.7918692827224731,
				["xpos"] = 0.7506120204925537,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 9,
			},
		},
		["Loch Modan"] = {
			["Der Loch"] = {
				["cmd"] = ".tele LochModanDerLoch",
				["ypos"] = 0.3883270621299744,
				["xpos"] = 0.4143227636814117,
			},
			["Der Steinwerkdamm"] = {
				["cmd"] = ".tele LochModanDerSteinwerkdamm",
				["ypos"] = 0.1466062366962433,
				["xpos"] = 0.4847450256347656,
			},
			["Eisenbands Ausgrabungsst\195\164tte"] = {
				["cmd"] = ".tele LochModanEisenbandsAusgrabungsstaette",
				["ypos"] = 0.6893028616905212,
				["xpos"] = 0.7267686724662781,
			},
			["Festung Mo'grosh"] = {
				["cmd"] = ".tele LochModanFestungMogrosh",
				["ypos"] = 0.2088950574398041,
				["xpos"] = 0.7366840839385986,
			},
			["Jagdh\195\188tte der Weltenwanderer"] = {
				["cmd"] = ".tele LochModanJagdhuettederWeltenwanderer",
				["ypos"] = 0.6457549929618835,
				["xpos"] = 0.8161161541938782,
			},
			["Loch Modan"] = {
				["cmd"] = ".tele LochModan",
				["ypos"] = 0.2454904764890671,
				["xpos"] = 0.518425464630127,
			},
			["Splittersteintal"] = {
				["cmd"] = ".tele LochModanSplittersteintal",
				["ypos"] = 0.7844803333282471,
				["xpos"] = 0.3427005708217621,
			},
			["Station Algaz"] = {
				["cmd"] = ".tele LochModanStationAlgaz",
				["ypos"] = 0.2294085770845413,
				["xpos"] = 0.2657451927661896,
			},
			["Tal der K\195\182nige"] = {
				["cmd"] = ".tele LochModanTalderKoenige",
				["ypos"] = 0.7357268929481506,
				["xpos"] = 0.2117481380701065,
			},
			["Thelsamar"] = {
				["cmd"] = ".tele LochModanThelsamar",
				["ypos"] = 0.4669337570667267,
				["xpos"] = 0.3550282716751099,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 12,
			},
		},
		["Mondlichtung"] = {
			["Der Schrein von Remulos"] = {
				["cmd"] = ".tele MondlichtungDerSchreinvonRemulos",
				["ypos"] = 0.41692054271698,
				["xpos"] = 0.3533867597579956,
			},
			["Mondlichtung"] = {
				["cmd"] = ".tele MondlichtungMondlichtung",
				["ypos"] = 0.5458588600158691,
				["xpos"] = 0.3676270246505737,
			},
			["Nachthafen"] = {
				["cmd"] = ".tele MondlichtungNachthafen",
				["ypos"] = 0.3330241143703461,
				["xpos"] = 0.4851482212543488,
			},
			["Sturmgrimms Grabh\195\188gel"] = {
				["cmd"] = ".tele MondlichtungSturmgrimmsGrabhuegel",
				["ypos"] = 0.6012966632843018,
				["xpos"] = 0.6572030782699585,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 15,
			},
		},
		["Mulgore"] = {
			["Überfallene Karawane"] = {
				["cmd"] = ".tele MulgoreUeberfalleneKarawane",
				["ypos"] = 0.4852225184440613,
				["xpos"] = 0.5408717393875122,
			},
			["Bleichm\195\164hnenfels"] = {
				["cmd"] = ".tele MulgoreBleichmaehnenfels",
				["ypos"] = 0.6193333268165588,
				["xpos"] = 0.341281533241272,
			},
			["Camp Narache"] = {
				["cmd"] = ".tele MulgoreCampNarache",
				["ypos"] = 0.7711918950080872,
				["xpos"] = 0.4478001594543457,
			},
			["Die goldenen Ebenen"] = {
				["cmd"] = ".tele MulgoreDiegoldenenEbenen",
				["ypos"] = 0.2270579040050507,
				["xpos"] = 0.529994547367096,
			},
			["Die Mine der Venture Co."] = {
				["cmd"] = ".tele MulgoreDieMinederVentureCo.",
				["ypos"] = 0.4796331226825714,
				["xpos"] = 0.6141813397407532,
			},
			["Die wogenden Ebenen"] = {
				["cmd"] = ".tele MulgoreDiewogendenEbenen",
				["ypos"] = 0.6777583956718445,
				["xpos"] = 0.6048952341079712,
			},
			["Dorf der Bluthufe"] = {
				["cmd"] = ".tele MulgoreDorfderBluthufe",
				["ypos"] = 0.5981966257095337,
				["xpos"] = 0.472381055355072,
			},
			["Dornrankenklamm"] = {
				["cmd"] = ".tele MulgoreDornrankenklamm",
				["ypos"] = 0.7767747640609741,
				["xpos"] = 0.5862597823143005,
			},
			["Grabungsst\195\164tte von Bael'dun"] = {
				["cmd"] = ".tele MulgoreGrabungsstaettevonBaeldun",
				["ypos"] = 0.4744710624217987,
				["xpos"] = 0.3206309974193573,
			},
			["Hochwolkenebene"] = {
				["cmd"] = ".tele MulgoreHochwolkenebene",
				["ypos"] = 0.8426046967506409,
				["xpos"] = 0.493173360824585,
			},
			["Kodofels"] = {
				["cmd"] = ".tele MulgoreKodofels",
				["ypos"] = 0.8042516112327576,
				["xpos"] = 0.535937488079071,
			},
			["Steinbullensee"] = {
				["cmd"] = ".tele MulgoreSteinbullensee",
				["ypos"] = 0.5619246363639832,
				["xpos"] = 0.5420897603034973,
			},
			["Teufelsfelsen"] = {
				["cmd"] = ".tele MulgoreTeufelsfelsen",
				["ypos"] = 0.2152425050735474,
				["xpos"] = 0.614527702331543,
			},
			["Wasserbrunnen der Donnerh\195\182rner"] = {
				["cmd"] = ".tele MulgoreWasserbrunnenderDonnerhoerner",
				["ypos"] = 0.454392820596695,
				["xpos"] = 0.4437759518623352,
			},
			["Wasserbrunnen der Wildm\195\164hnen"] = {
				["cmd"] = ".tele MulgoreWasserbrunnenderWildmaehnen",
				["ypos"] = 0.1429764479398727,
				["xpos"] = 0.4264114797115326,
			},
			["Wasserbrunnen der Winterhufe"] = {
				["cmd"] = ".tele MulgoreWasserbrunnenderWinterhufe",
				["ypos"] = 0.6611583828926086,
				["xpos"] = 0.5360240936279297,
			},
			["Windfurienkamm"] = {
				["cmd"] = ".tele MulgoreWindfurienkamm",
				["ypos"] = 0.08116830885410309,
				["xpos"] = 0.50581955909729,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 16,
			},
		},
		["Nagrand"] = {
			["Aerissteg"] = {
				["cmd"] = ".tele NagrandAerissteg",
				["ypos"] = 0.57159823179245,
				["xpos"] = 0.3116422295570374,
			},
			["Ahnengrund"] = {
				["cmd"] = ".tele NagrandAhnengrund",
				["ypos"] = 0.6107855439186096,
				["xpos"] = 0.2617019712924957,
			},
			["Der Hochpfad"] = {
				["cmd"] = ".tele NagrandDerHochpfad",
				["ypos"] = 0.54942786693573,
				["xpos"] = 0.7819832563400269,
			},
			["Der Niederpfad"] = {
				["cmd"] = ".tele NagrandDerNiederpfad",
				["ypos"] = 0.7551846504211426,
				["xpos"] = 0.7701055407524109,
			},
			["Der Ring der Pr\195\188fung"] = {
				["cmd"] = ".tele NagrandDerRingderPruefung",
				["ypos"] = 0.5490480065345764,
				["xpos"] = 0.675962507724762,
			},
			["Der Ring des Blutes"] = {
				["cmd"] = ".tele NagrandDerRingdesBlutes",
				["ypos"] = 0.2079615443944931,
				["xpos"] = 0.432315468788147,
			},
			["Die H\195\188gelwand"] = {
				["cmd"] = ".tele NagrandDieHuegelwand",
				["ypos"] = 0.4759864509105682,
				["xpos"] = 0.7566376328468323,
			},
			["Elementarplateau"] = {
				["cmd"] = ".tele NagrandElementarplateau",
				["ypos"] = 0.2084407359361649,
				["xpos"] = 0.6618539690971375,
			},
			["Festung Kil'sorge"] = {
				["cmd"] = ".tele NagrandFestungKilsorge",
				["ypos"] = 0.8016778230667114,
				["xpos"] = 0.7116965055465698,
			},
			["Garadar"] = {
				["cmd"] = ".tele NagrandGaradar",
				["ypos"] = 0.3696235418319702,
				["xpos"] = 0.5578593611717224,
			},
			["Geisterfelder"] = {
				["cmd"] = ".tele NagrandGeisterfelder",
				["ypos"] = 0.6551665663719177,
				["xpos"] = 0.3974847197532654,
			},
			["Halaa"] = {
				["cmd"] = ".tele NagrandHalaa",
				["ypos"] = 0.4378823637962341,
				["xpos"] = 0.4240548014640808,
			},
			["Halaanibecken"] = {
				["cmd"] = ".tele NagrandHalaanibecken",
				["ypos"] = 0.4239330291748047,
				["xpos"] = 0.4513326287269592,
			},
			["Himmelsweisensee"] = {
				["cmd"] = ".tele NagrandHimmelsweisensee",
				["ypos"] = 0.2492507696151733,
				["xpos"] = 0.5414775013923645,
			},
			["Hof des Lachenden Sch\195\164dels"] = {
				["cmd"] = ".tele NagrandHofdesLachendenSchaedels",
				["ypos"] = 0.2409430891275406,
				["xpos"] = 0.4669634699821472,
			},
			["Klanwacht"] = {
				["cmd"] = ".tele NagrandKlanwacht",
				["ypos"] = 0.6366099715232849,
				["xpos"] = 0.626277506351471,
			},
			["Konstruktionslager: Furcht"] = {
				["cmd"] = ".tele NagrandKonstruktionslagerFurcht",
				["ypos"] = 0.5124045610427856,
				["xpos"] = 0.1901507675647736,
			},
			["Konstruktionslager: Hass"] = {
				["cmd"] = ".tele NagrandKonstruktionslagerHass",
				["ypos"] = 0.36906698346138,
				["xpos"] = 0.2472748160362244,
			},
			["Mag'harische Prozession"] = {
				["cmd"] = ".tele NagrandMagharischeProzession",
				["ypos"] = 0.3589665293693543,
				["xpos"] = 0.3246252834796906,
			},
			["Nesingwarys Safari"] = {
				["cmd"] = ".tele NagrandNesingwarysSafari",
				["ypos"] = 0.4022217392921448,
				["xpos"] = 0.7150521278381348,
			},
			["Nordwindkluft"] = {
				["cmd"] = ".tele NagrandNordwindkluft",
				["ypos"] = 0.3411954641342163,
				["xpos"] = 0.4070467054843903,
			},
			["Oshu'gun"] = {
				["cmd"] = ".tele NagrandOshugun",
				["ypos"] = 0.7124298810958862,
				["xpos"] = 0.3584585189819336,
			},
			["Ruinen der Brennenden Klinge"] = {
				["cmd"] = ".tele NagrandRuinenderBrennendenKlinge",
				["ypos"] = 0.6949755549430847,
				["xpos"] = 0.7290394306182861,
			},
			["Ruinen des Lachenden Sch\195\164dels"] = {
				["cmd"] = ".tele NagrandRuinendesLachendenSchaedels",
				["ypos"] = 0.2340900599956513,
				["xpos"] = 0.4543371796607971,
			},
			["Schilftanz"] = {
				["cmd"] = ".tele NagrandSchilftanz",
				["ypos"] = 0.5259466171264648,
				["xpos"] = 0.7150991559028626,
			},
			["Schilftanzpass"] = {
				["cmd"] = ".tele NagrandSchilftanzpass",
				["ypos"] = 0.3559755980968475,
				["xpos"] = 0.7328096032142639,
			},
			["Sonnenwindposten"] = {
				["cmd"] = ".tele NagrandSonnenwindposten",
				["ypos"] = 0.4228470623493195,
				["xpos"] = 0.3218195140361786,
			},
			["Sonnenwindsee"] = {
				["cmd"] = ".tele NagrandSonnenwindsee",
				["ypos"] = 0.4567484259605408,
				["xpos"] = 0.375819593667984,
			},
			["S\195\188dwindkluft"] = {
				["cmd"] = ".tele NagrandSuedwindkluft",
				["ypos"] = 0.5594407320022583,
				["xpos"] = 0.4904873967170715,
			},
			["Telaar"] = {
				["cmd"] = ".tele NagrandTelaar",
				["ypos"] = 0.7235583662986755,
				["xpos"] = 0.5439028143882752,
			},
			["Telaaribecken"] = {
				["cmd"] = ".tele NagrandTelaaribecken",
				["ypos"] = 0.5212362408638001,
				["xpos"] = 0.5678231716156006,
			},
			["Thron der Elemente"] = {
				["cmd"] = ".tele NagrandThronderElemente",
				["ypos"] = 0.2358411848545075,
				["xpos"] = 0.6020982265472412,
			},
			["Totschl\195\164gerh\195\188gel"] = {
				["cmd"] = ".tele NagrandTotschlaegerhuegel",
				["ypos"] = 0.2192225307226181,
				["xpos"] = 0.2629164457321167,
			},
			["Verlassenes R\195\188stlager"] = {
				["cmd"] = ".tele NagrandVerlassenesRuestlager",
				["ypos"] = 0.5726787447929382,
				["xpos"] = 0.5126286149024963,
			},
			["Zangarkamm"] = {
				["cmd"] = ".tele NagrandZangarkamm",
				["ypos"] = 0.1704186499118805,
				["xpos"] = 0.334956169128418,
			},
			["Zwielichth\195\182he"] = {
				["cmd"] = ".tele NagrandZwielichthoehe",
				["ypos"] = 0.4089574813842773,
				["xpos"] = 0.1032421886920929,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 2,
			},
		},
		["Nethersturm"] = {
			["Area 52"] = {
				["cmd"] = ".tele NethersturmArea52",
				["ypos"] = 0.6476502418518066,
				["xpos"] = 0.3223700523376465,
			},
			["Arkatraz"] = {
				["cmd"] = ".tele NethersturmArkatraz",
				["ypos"] = 0.57802200,
				["xpos"] = 0.74288979,
			},
			["Arklonisgrat"] = {
				["cmd"] = ".tele NethersturmArklonisgrat",
				["ypos"] = 0.6783228516578674,
				["xpos"] = 0.4059431850910187,
			},
			["Biokuppel Fernfeld"] = {
				["cmd"] = ".tele NethersturmBiokuppelFernfeld",
				["ypos"] = 0.1180170029401779,
				["xpos"] = 0.4526552557945252,
			},
			["Biokuppel Himmelssitz"] = {
				["cmd"] = ".tele NethersturmBiokuppelHimmelssitz",
				["ypos"] = 0.378328263759613,
				["xpos"] = 0.3983629047870636,
			},
			["Biokuppel Mittelreich"] = {
				["cmd"] = ".tele NethersturmBiokuppelMittelreich",
				["ypos"] = 0.5147461295127869,
				["xpos"] = 0.4689368903636932,
			},
			["Biokuppel Sutheron"] = {
				["cmd"] = ".tele NethersturmBiokuppelSutheron",
				["ypos"] = 0.2706914246082306,
				["xpos"] = 0.4743772745132446,
			},
			["Botanika"] = {
				["cmd"] = ".tele NethersturmBotanika",
				["ypos"] = 0.55217804,
				["xpos"] = 0.71631577,
			},
			["Das Tr\195\188mmerfeld"] = {
				["cmd"] = ".tele NethersturmDasTruemmerfeld",
				["ypos"] = 0.5723193287849426,
				["xpos"] = 0.5047862529754639,
			},
			["Der H\195\188gel"] = {
				["cmd"] = ".tele NethersturmDerHuegel",
				["ypos"] = 0.7770565152168274,
				["xpos"] = 0.3009045720100403,
			},
			["Die Versuchsgr\195\188nde"] = {
				["cmd"] = ".tele NethersturmDieVersuchsgruende",
				["ypos"] = 0.6343775987625122,
				["xpos"] = 0.3750624358654022,
			},
			["Die Vortexfelder"] = {
				["cmd"] = ".tele NethersturmDieVortexfelder",
				["ypos"] = 0.6255416870117188,
				["xpos"] = 0.6416741013526917,
			},
			["Festung der St\195\188rme"] = {
				["cmd"] = ".tele NethersturmFestungderStuerme",
				["ypos"] = 0.6339470744132996,
				["xpos"] = 0.7088436484336853,
			},
			["Gyroplankenbr\195\188cke"] = {
				["cmd"] = ".tele NethersturmGyroplankenbruecke",
				["ypos"] = 0.5588932633399963,
				["xpos"] = 0.2133996784687042,
			},
			["Invasionspunkt: Oberanf\195\188hrer"] = {
				["cmd"] = ".tele NethersturmInvasionspunktOberanfuehrer",
				["ypos"] = 0.1915371865034103,
				["xpos"] = 0.3684974312782288,
			},
			["Invasionspunkt: Zerst\195\182rer"] = {
				["cmd"] = ".tele NethersturmInvasionspunktZerstoerer",
				["ypos"] = 0.6481452584266663,
				["xpos"] = 0.4977494776248932,
			},
			["Kluft der St\195\188rme"] = {
				["cmd"] = ".tele NethersturmKluftderStuerme",
				["ypos"] = 0.6031776070594788,
				["xpos"] = 0.6793907284736633,
			},
			["Konstruktionsbasis: Gehenna"] = {
				["cmd"] = ".tele NethersturmKonstruktionsbasisGehenna",
				["ypos"] = 0.2208134382963181,
				["xpos"] = 0.4058283567428589,
			},
			["Konstruktionsbasis: Vergessenheit"] = {
				["cmd"] = ".tele NethersturmKonstruktionsbasisVergessenheit",
				["ypos"] = 0.2690287232398987,
				["xpos"] = 0.3710050582885742,
			},
			["Kosmozang"] = {
				["cmd"] = ".tele NethersturmKosmozang",
				["ypos"] = 0.6700896620750427,
				["xpos"] = 0.6626660823822022,
			},
			["Lager von Dr. Bumm"] = {
				["cmd"] = ".tele NethersturmLagervonDr.Bumm",
				["ypos"] = 0.6014474630355835,
				["xpos"] = 0.3481261134147644,
			},
			["Leerenwindplateau"] = {
				["cmd"] = ".tele NethersturmLeerenwindplateau",
				["ypos"] = 0.3989704251289368,
				["xpos"] = 0.681191623210907,
			},
			["Manaschmiede Ara"] = {
				["cmd"] = ".tele NethersturmManaschmiedeAra",
				["ypos"] = 0.4056995809078217,
				["xpos"] = 0.2919915914535523,
			},
			["Manaschmiede B'naar"] = {
				["cmd"] = ".tele NethersturmManaschmiedeBnaar",
				["ypos"] = 0.6687309145927429,
				["xpos"] = 0.2577440738677979,
			},
			["Manaschmiede Coruu"] = {
				["cmd"] = ".tele NethersturmManaschmiedeCoruu",
				["ypos"] = 0.814684271812439,
				["xpos"] = 0.4648041427135468,
			},
			["Manaschmiede Duro"] = {
				["cmd"] = ".tele NethersturmManaschmiedeDuro",
				["ypos"] = 0.6295748353004456,
				["xpos"] = 0.5831611156463623,
			},
			["Manaschmiede Ultris"] = {
				["cmd"] = ".tele NethersturmManaschmiedeUltris",
				["ypos"] = 0.4133084714412689,
				["xpos"] = 0.6509494781494141,
			},
			["Mechanar"] = {
				["cmd"] = ".tele NethersturmMechanar",
				["ypos"] = 0.69640022,
				["xpos"] = 0.70526047,
			},
			["Mittelreichposten"] = {
				["cmd"] = ".tele NethersturmMittelreichposten",
				["ypos"] = 0.5610887408256531,
				["xpos"] = 0.4670588672161102,
			},
			["Netherstein"] = {
				["cmd"] = ".tele NethersturmNetherstein",
				["ypos"] = 0.1713578104972839,
				["xpos"] = 0.4923090934753418,
			},
			["Ratsplatz"] = {
				["cmd"] = ".tele NethersturmRatsplatz",
				["ypos"] = 0.8498932719230652,
				["xpos"] = 0.5735324025154114,
			},
			["Ruinen von Arklon"] = {
				["cmd"] = ".tele NethersturmRuinenvonArklon",
				["ypos"] = 0.7287740111351013,
				["xpos"] = 0.4122803509235382,
			},
			["Ruinen von Enkaat"] = {
				["cmd"] = ".tele NethersturmRuinenvonEnkaat",
				["ypos"] = 0.5329318046569824,
				["xpos"] = 0.3311251997947693,
			},
			["Ruinen von Farahlon"] = {
				["cmd"] = ".tele NethersturmRuinenvonFarahlon",
				["ypos"] = 0.2048501819372177,
				["xpos"] = 0.5255324244499207,
			},
			["Socrethars Sitz"] = {
				["cmd"] = ".tele NethersturmSocretharsSitz",
				["ypos"] = 0.1645022183656693,
				["xpos"] = 0.3097817003726959,
			},
			["Sonnenzornposten"] = {
				["cmd"] = ".tele NethersturmSonnenzornposten",
				["ypos"] = 0.7999640703201294,
				["xpos"] = 0.5482265949249268,
			},
			["Sternensturz"] = {
				["cmd"] = ".tele NethersturmSternensturz",
				["ypos"] = 0.385899543762207,
				["xpos"] = 0.720922589302063,
			},
			["St\195\188tzpunkt des Astraleums"] = {
				["cmd"] = ".tele NethersturmStuetzpunktdesAstraleums",
				["ypos"] = 0.4051802456378937,
				["xpos"] = 0.5579521656036377,
			},
			["Trelleummine"] = {
				["cmd"] = ".tele NethersturmTrelleummine",
				["ypos"] = 0.4451139271259308,
				["xpos"] = 0.2635790407657623,
			},
			["Wachposten des Protektorats"] = {
				["cmd"] = ".tele NethersturmWachpostendesProtektorats",
				["ypos"] = 0.3202170729637146,
				["xpos"] = 0.5915467739105225,
			},
			["Zugangsschacht Zeon"] = {
				["cmd"] = ".tele NethersturmZugangsschachtZeon",
				["ypos"] = 0.4597049355506897,
				["xpos"] = 0.610129714012146,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 3,
			},
		},
		["Orgrimmar"] = {
			["Die Gasse"] = {
				["cmd"] = ".tele OrgrimmarDieGasse",
				["ypos"] = 0.4419580698013306,
				["xpos"] = 0.5941158533096314,
			},
			["Die Kluft der Schatten"] = {
				["cmd"] = ".tele OrgrimmarDieKluftderSchatten",
				["ypos"] = 0.5008155703544617,
				["xpos"] = 0.4680644273757935,
			},
			["Eingang"] = {
				["cmd"] = ".tele OrgrimmarEingang",
				["ypos"] = 0.9481,
				["xpos"] = 0.4907,
			},
			["Feste Grommash"] = {
				["cmd"] = ".tele OrgrimmarFesteGrommash",
				["ypos"] = 0.3709096908569336,
				["xpos"] = 0.3848187625408173,
			},
			["Halle der Kriegerhelden"] = {
				["cmd"] = ".tele OrgrimmarHallederKriegerhelden",
				["ypos"] = 0.3095192015171051,
				["xpos"] = 0.7936556935310364,
			},
			["Orgrimmar"] = {
				["cmd"] = ".tele Orgrimmar",
				["ypos"] = 0.68888794,
				["xpos"] = 0.49390190,
			},
			["Tal der Ehre"] = {
				["cmd"] = ".tele OrgrimmarTalderEhre",
				["ypos"] = 0.2895904183387756,
				["xpos"] = 0.7260537147521973,
			},
			["Tal der Geister"] = {
				["cmd"] = ".tele OrgrimmarTalderGeister",
				["ypos"] = 0.7728153467178345,
				["xpos"] = 0.3556212186813355,
			},
			["Tal der St\195\164rke"] = {
				["cmd"] = ".tele OrgrimmarTalderStaerke",
				["ypos"] = 0.8244092464447022,
				["xpos"] = 0.5238931775093079,
			},
			["Tal der Weisheit"] = {
				["cmd"] = ".tele OrgrimmarTalderWeisheit",
				["ypos"] = 0.3656840026378632,
				["xpos"] = 0.42897629737854,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 17,
			},
		},
		["Rotkammgebirge"] = {
			["Althers M\195\188hle"] = {
				["cmd"] = ".tele RotkammgebirgeAlthersMuehle",
				["ypos"] = 0.4100100696086884,
				["xpos"] = 0.5322734117507935,
			},
			["Burg Steinwacht"] = {
				["cmd"] = ".tele RotkammgebirgeBurgSteinwacht",
				["ypos"] = 0.5597423911094666,
				["xpos"] = 0.6764392256736755,
			},
			["Der Immerruhsee"] = {
				["cmd"] = ".tele RotkammgebirgeDerImmerruhsee",
				["ypos"] = 0.513841986656189,
				["xpos"] = 0.169108659029007,
			},
			["Der Turm von Ilgalar"] = {
				["cmd"] = ".tele RotkammgebirgeDerTurmvonIlgalar",
				["ypos"] = 0.4882448315620422,
				["xpos"] = 0.8113373517990112,
			},
			["Drei Ecken"] = {
				["cmd"] = ".tele RotkammgebirgeDreiEcken",
				["ypos"] = 0.7023739814758301,
				["xpos"] = 0.1562512069940567,
			},
			["Renders Fels"] = {
				["cmd"] = ".tele RotkammgebirgeRendersFels",
				["ypos"] = 0.07762166112661362,
				["xpos"] = 0.3498871326446533,
			},
			["Renders Tal"] = {
				["cmd"] = ".tele RotkammgebirgeRendersTal",
				["ypos"] = 0.78651362657547,
				["xpos"] = 0.7451303601264954,
			},
			["Rethbanh\195\182hlen"] = {
				["cmd"] = ".tele RotkammgebirgeRethbanhoehlen",
				["ypos"] = 0.2810052931308746,
				["xpos"] = 0.2052488029003143,
			},
			["Rotkammschlucht"] = {
				["cmd"] = ".tele RotkammgebirgeRotkammschlucht",
				["ypos"] = 0.2573924362659454,
				["xpos"] = 0.3374558091163635,
			},
			["Seenhain"] = {
				["cmd"] = ".tele RotkammgebirgeSeenhain",
				["ypos"] = 0.4854269325733185,
				["xpos"] = 0.3291358351707459,
			},
			["Steinwachtf\195\164lle"] = {
				["cmd"] = ".tele RotkammgebirgeSteinwachtfaelle",
				["ypos"] = 0.626808762550354,
				["xpos"] = 0.8084543347358704,
			},
			["Uferpfad"] = {
				["cmd"] = ".tele RotkammgebirgeUferpfad",
				["ypos"] = 0.7482723593711853,
				["xpos"] = 0.4391551017761231,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 15,
			},
		},
		["Schattenmondtal"] = {
			["Altar der Sha'tar"] = {
				["cmd"] = ".tele SchattenmondtalAltarderShatar",
				["ypos"] = 0.3039227724075317,
				["xpos"] = 0.6165945529937744,
			},
			["Altar der Verdammnis"] = {
				["cmd"] = ".tele SchattenmondtalAltarderVerdammnis",
				["ypos"] = 0.4510728120803833,
				["xpos"] = 0.4207490980625153,
			},
			["Der faulige Teich"] = {
				["cmd"] = ".tele SchattenmondtalDerfauligeTeich",
				["ypos"] = 0.4032991230487824,
				["xpos"] = 0.2589636445045471,
			},
			["Der Schwarze Tempel"] = {
				["cmd"] = ".tele SchattenmondtalDerSchwarzeTempel",
				["ypos"] = 0.4634476006031036,
				["xpos"] = 0.7105425596237183,
			},
			["Die Hand von Gul'dan"] = {
				["cmd"] = ".tele SchattenmondtalDieHandvonGuldan",
				["ypos"] = 0.4430900812149048,
				["xpos"] = 0.5151236653327942,
			},
			["Die Teufelsgruben"] = {
				["cmd"] = ".tele SchattenmondtalDieTeufelsgruben",
				["ypos"] = 0.5102245807647705,
				["xpos"] = 0.4916672706604004,
			},
			["Die Todesschmiede"] = {
				["cmd"] = ".tele SchattenmondtalDieTodesschmiede",
				["ypos"] = 0.3801172971725464,
				["xpos"] = 0.4027000069618225,
			},
			["Echsennarbe"] = {
				["cmd"] = ".tele SchattenmondtalEchsennarbe",
				["ypos"] = 0.2883009612560272,
				["xpos"] = 0.4557999968528748,
			},
			["Feste der Legion"] = {
				["cmd"] = ".tele SchattenmondtalFestederLegion",
				["ypos"] = 0.3594664037227631,
				["xpos"] = 0.2464109063148499,
			},
			["Festung des Drachenmals"] = {
				["cmd"] = ".tele SchattenmondtalFestungdesDrachenmals",
				["ypos"] = 0.609595537185669,
				["xpos"] = 0.6788727045059204,
			},
			["Invasionspunkt: Katastrophe"] = {
				["cmd"] = ".tele SchattenmondtalInvasionspunktKatastrophe",
				["ypos"] = 0.216377317905426,
				["xpos"] = 0.3291709125041962,
			},
			["Kerker des W\195\164chters"] = {
				["cmd"] = ".tele SchattenmondtalKerkerdesWaechters",
				["ypos"] = 0.5003545880317688,
				["xpos"] = 0.5725218057632446,
			},
			["Netherschwingenfelder"] = {
				["cmd"] = ".tele SchattenmondtalNetherschwingenfelder",
				["ypos"] = 0.5770291090011597,
				["xpos"] = 0.6170963644981384,
			},
			["Netherschwingenscherbe"] = {
				["cmd"] = ".tele SchattenmondtalNetherschwingenscherbe",
				["ypos"] = 0.8531845808029175,
				["xpos"] = 0.7090749144554138,
			},
			["Pfad der Eroberung"] = {
				["cmd"] = ".tele SchattenmondtalPfadderEroberung",
				["ypos"] = 0.6643072962760925,
				["xpos"] = 0.528661847114563,
			},
			["Ruinen von Baa'ri"] = {
				["cmd"] = ".tele SchattenmondtalRuinenvonBaari",
				["ypos"] = 0.3781318366527557,
				["xpos"] = 0.5824945569038391,
			},
			["Ruinen von Karabor"] = {
				["cmd"] = ".tele SchattenmondtalRuinenvonKarabor",
				["ypos"] = 0.5149236917495728,
				["xpos"] = 0.7058256268501282,
			},
			["Sanktum der Sterne"] = {
				["cmd"] = ".tele SchattenmondtalSanktumderSterne",
				["ypos"] = 0.5826718211174011,
				["xpos"] = 0.566821813583374,
			},
			["Schlackenwacht"] = {
				["cmd"] = ".tele SchattenmondtalSchlackenwacht",
				["ypos"] = 0.3811700642108917,
				["xpos"] = 0.3839181959629059,
			},
			["St\195\164tte der Illidari"] = {
				["cmd"] = ".tele SchattenmondtalStaettederIllidari",
				["ypos"] = 0.5028637051582336,
				["xpos"] = 0.3029727339744568,
			},
			["St\195\164tte der Mondfinsternis"] = {
				["cmd"] = ".tele SchattenmondtalStaettederMondfinsternis",
				["ypos"] = 0.6906554698944092,
				["xpos"] = 0.4643454551696777,
			},
			["Terrasse von Ata'mal"] = {
				["cmd"] = ".tele SchattenmondtalTerrassevonAtamal",
				["ypos"] = 0.3669663965702057,
				["xpos"] = 0.706466555595398,
			},
			["Wildhammerfeste"] = {
				["cmd"] = ".tele SchattenmondtalWildhammerfeste",
				["ypos"] = 0.5486491322517395,
				["xpos"] = 0.3705327212810516,
			},
			["Wrack der Sketh'lon"] = {
				["cmd"] = ".tele SchattenmondtalWrackderSkethlon",
				["ypos"] = 0.3027009665966034,
				["xpos"] = 0.3757963478565216,
			},
			["Zerschlagene Weiten"] = {
				["cmd"] = ".tele SchattenmondtalZerschlageneWeiten",
				["ypos"] = 0.1492100208997726,
				["xpos"] = 0.576776385307312,
			},
			["Zisterne der Echsennarbe"] = {
				["cmd"] = ".tele SchattenmondtalZisternederEchsennarbe",
				["ypos"] = 0.2711873054504395,
				["xpos"] = 0.5280836224555969,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 4,
			},
		},
		["Schergrat"] = {
			["Arena des Zirkels des Blutes"] = {
				["cmd"] = ".tele SchergratArenadesZirkelsdesBlutes",
				["ypos"] = 0.4340552389621735,
				["xpos"] = 0.5375950932502747,
			},
			["Au\195\159enposten der Blutschl\195\164ger"] = {
				["cmd"] = ".tele SchergratAussenpostenderBlutschlaeger",
				["ypos"] = 0.7661898136138916,
				["xpos"] = 0.4575563669204712,
			},
			["Au\195\159enposten der Speerspie\195\159er"] = {
				["cmd"] = ".tele SchergratAussenpostenderSpeerspiesser",
				["ypos"] = 0.5698764324188232,
				["xpos"] = 0.5728189945220947,
			},
			["Blutschl\195\164gerklamm"] = {
				["cmd"] = ".tele SchergratBlutschlaegerklamm",
				["ypos"] = 0.6808405518531799,
				["xpos"] = 0.4529277384281158,
			},
			["Br\195\188cke des Wyrmsch\195\164dels"] = {
				["cmd"] = ".tele SchergratBrueckedesWyrmschaedels",
				["ypos"] = 0.380110502243042,
				["xpos"] = 0.5325462222099304,
			},
			["Der ewige Hain"] = {
				["cmd"] = ".tele SchergratDerewigeHain",
				["ypos"] = 0.3818718492984772,
				["xpos"] = 0.6212687492370606,
			},
			["Der lebende Hain"] = {
				["cmd"] = ".tele SchergratDerlebendeHain",
				["ypos"] = 0.7328303456306458,
				["xpos"] = 0.3866236209869385,
			},
			["Der singende Bergr\195\188cken"] = {
				["cmd"] = ".tele SchergratDersingendeBergruecken",
				["ypos"] = 0.7753142714500427,
				["xpos"] = 0.6265203952789307,
			},
			["Dolchrachenklamm"] = {
				["cmd"] = ".tele SchergratDolchrachenklamm",
				["ypos"] = 0.3203566372394562,
				["xpos"] = 0.5609996318817139,
			},
			["Donnerfeste"] = {
				["cmd"] = ".tele SchergratDonnerfeste",
				["ypos"] = 0.5600552558898926,
				["xpos"] = 0.5163249969482422,
			},
			["Dorf der Mok'Nathal"] = {
				["cmd"] = ".tele SchergratDorfderMokNathal",
				["ypos"] = 0.6221925616264343,
				["xpos"] = 0.746651291847229,
			},
			["Drachenend"] = {
				["cmd"] = ".tele SchergratDrachenend",
				["ypos"] = 0.4880746304988861,
				["xpos"] = 0.5464945435523987,
			},
			["Draenethystmine"] = {
				["cmd"] = ".tele SchergratDraenethystmine",
				["ypos"] = 0.8317944407463074,
				["xpos"] = 0.4240116775035858,
			},
			["Fels'mok"] = {
				["cmd"] = ".tele SchergratFelsmok",
				["ypos"] = 0.2214644104242325,
				["xpos"] = 0.30996373295784,
			},
			["Grabenschlucht"] = {
				["cmd"] = ".tele SchergratGrabenschlucht",
				["ypos"] = 0.4239105582237244,
				["xpos"] = 0.4800208210945129,
			},
			["Grishnath"] = {
				["cmd"] = ".tele SchergratGrishnath",
				["ypos"] = 0.2094616740942001,
				["xpos"] = 0.4134272634983063,
			},
			["Grund der Speerspie\195\159er"] = {
				["cmd"] = ".tele SchergratGrundderSpeerspiesser",
				["ypos"] = 0.5202810764312744,
				["xpos"] = 0.4746807813644409,
			},
			["Konstruktionslager: Groll"] = {
				["cmd"] = ".tele SchergratKonstruktionslagerGroll",
				["ypos"] = 0.4042211771011353,
				["xpos"] = 0.7388226389884949,
			},
			["Konstruktionslager: Terror"] = {
				["cmd"] = ".tele SchergratKonstruktionslagerTerror",
				["ypos"] = 0.8022506833076477,
				["xpos"] = 0.2842733860015869,
			},
			["Konstruktionslager: Wut"] = {
				["cmd"] = ".tele SchergratKonstruktionslagerWut",
				["ypos"] = 0.405078262090683,
				["xpos"] = 0.3472485542297363,
			},
			["Kristallr\195\188cken"] = {
				["cmd"] = ".tele SchergratKristallruecken",
				["ypos"] = 0.1108294129371643,
				["xpos"] = 0.7133278250694275,
			},
			["Lager der Blutschl\195\164ger"] = {
				["cmd"] = ".tele SchergratLagerderBlutschlaeger",
				["ypos"] = 0.2696276009082794,
				["xpos"] = 0.5646992325782776,
			},
			["Landeplatz von Bash'ir"] = {
				["cmd"] = ".tele SchergratLandeplatzvonBashir",
				["ypos"] = 0.1815786063671112,
				["xpos"] = 0.5007748007774353,
			},
			["Lashhversteck"] = {
				["cmd"] = ".tele SchergratLashhversteck",
				["ypos"] = 0.7790303826332092,
				["xpos"] = 0.3542531430721283,
			},
			["Messergrat"] = {
				["cmd"] = ".tele SchergratMessergrat",
				["ypos"] = 0.536533534526825,
				["xpos"] = 0.6497775316238403,
			},
			["Messerschlucht"] = {
				["cmd"] = ".tele SchergratMesserschlucht",
				["ypos"] = 0.3349612653255463,
				["xpos"] = 0.7124374508857727,
			},
			["Ogri'la"] = {
				["cmd"] = ".tele SchergratOgrila",
				["ypos"] = 0.5799880027770996,
				["xpos"] = 0.2875047028064728,
			},
			["Pechschwingenkoven"] = {
				["cmd"] = ".tele SchergratPechschwingenkoven",
				["ypos"] = 0.3338994681835175,
				["xpos"] = 0.3187600076198578,
			},
			["Rabenwald"] = {
				["cmd"] = ".tele SchergratRabenwald",
				["ypos"] = 0.2702745497226715,
				["xpos"] = 0.3220908343791962,
			},
			["Razaans Landeplatz"] = {
				["cmd"] = ".tele SchergratRazaansLandeplatz",
				["ypos"] = 0.4295593798160553,
				["xpos"] = 0.6656135320663452,
			},
			["Ruuanversteck"] = {
				["cmd"] = ".tele SchergratRuuanversteck",
				["ypos"] = 0.3203760087490082,
				["xpos"] = 0.6470788717269898,
			},
			["Ruuanwald"] = {
				["cmd"] = ".tele SchergratRuuanwald",
				["ypos"] = 0.343480110168457,
				["xpos"] = 0.6036743521690369,
			},
			["Schuppenfl\195\188gelbank"] = {
				["cmd"] = ".tele SchergratSchuppenfluegelbank",
				["ypos"] = 0.6632193326950073,
				["xpos"] = 0.681982159614563,
			},
			["Schwelle des Todes"] = {
				["cmd"] = ".tele SchergratSchwelledesTodes",
				["ypos"] = 0.5918469429016113,
				["xpos"] = 0.6358863115310669,
			},
			["Skald"] = {
				["cmd"] = ".tele SchergratSkald",
				["ypos"] = 0.1962921172380447,
				["xpos"] = 0.7168595790863037,
			},
			["Sylvanaar"] = {
				["cmd"] = ".tele SchergratSylvanaar",
				["ypos"] = 0.6496211290359497,
				["xpos"] = 0.3676005601882935,
			},
			["S\195\164belflucht"] = {
				["cmd"] = ".tele SchergratSaebelflucht",
				["ypos"] = 0.9560395479202271,
				["xpos"] = 0.5304909348487854,
			},
			["S\195\164belzahnschlucht"] = {
				["cmd"] = ".tele SchergratSaebelzahnschlucht",
				["ypos"] = 0.929406464099884,
				["xpos"] = 0.3199950754642487,
			},
			["Toshleys Station"] = {
				["cmd"] = ".tele SchergratToshleysStation",
				["ypos"] = 0.6914939880371094,
				["xpos"] = 0.6052135229110718,
			},
			["Trogmas Besitz"] = {
				["cmd"] = ".tele SchergratTrogmasBesitz",
				["ypos"] = 0.7439179420471191,
				["xpos"] = 0.7170014977455139,
			},
			["Tunnel des Wyrmsch\195\164dels"] = {
				["cmd"] = ".tele SchergratTunneldesWyrmschaedels",
				["ypos"] = 0.3322543203830719,
				["xpos"] = 0.4723176658153534,
			},
			["Vekhaar"] = {
				["cmd"] = ".tele SchergratVekhaar",
				["ypos"] = 0.7005326747894287,
				["xpos"] = 0.7435508370399475,
			},
			["Vekhversteck"] = {
				["cmd"] = ".tele SchergratVekhversteck",
				["ypos"] = 0.7496414184570313,
				["xpos"] = 0.7812061309814453,
			},
			["Verfluchtes Dunkel"] = {
				["cmd"] = ".tele SchergratVerfluchtesDunkel",
				["ypos"] = 0.477849692106247,
				["xpos"] = 0.5863175988197327,
			},
			["Wehr der Speerspie\195\159er"] = {
				["cmd"] = ".tele SchergratWehrderSpeerspiesser",
				["ypos"] = 0.5389723181724548,
				["xpos"] = 0.4160816967487335,
			},
			["Zackengrat"] = {
				["cmd"] = ".tele SchergratZackengrat",
				["ypos"] = 0.6553806066513062,
				["xpos"] = 0.5159415602684021,
			},
			["Zerschlagene Wildnis"] = {
				["cmd"] = ".tele SchergratZerschlageneWildnis",
				["ypos"] = 0.2383192926645279,
				["xpos"] = 0.7820165157318115,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 5,
			},
		},
		["Schlingendorntal"] = {
			["Basislager von Grom'gol"] = {
				["cmd"] = ".tele SchlingendorntalBasislagervonGromgol",
				["ypos"] = 0.283247172832489,
				["xpos"] = 0.314995139837265,
			},
			["Beutebucht"] = {
				["cmd"] = ".tele SchlingendorntalBeutebucht",
				["ypos"] = 0.7611008882522583,
				["xpos"] = 0.2823083698749542,
			},
			["Das finstere Riff"] = {
				["cmd"] = ".tele SchlingendorntalDasfinstereRiff",
				["ypos"] = 0.2562547922134399,
				["xpos"] = 0.2506920099258423,
			},
			["Das Kristallufer"] = {
				["cmd"] = ".tele SchlingendorntalDasKristallufer",
				["ypos"] = 0.6853833198547363,
				["xpos"] = 0.3711270391941071,
			},
			["Die gro\195\159e Arena"] = {
				["cmd"] = ".tele SchlingendorntalDiegrosseArena",
				["ypos"] = 0.4687732458114624,
				["xpos"] = 0.2965240478515625,
			},
			["Die Insel Jaguero"] = {
				["cmd"] = ".tele SchlingendorntalDieInselJaguero",
				["ypos"] = 0.8396358489990234,
				["xpos"] = 0.41579869389534,
			},
			["Die Insel Yojamba"] = {
				["cmd"] = ".tele SchlingendorntalDieInselYojamba",
				["ypos"] = 0.1536963135004044,
				["xpos"] = 0.1540486961603165,
			},
			["Die ungez\195\164hmte K\195\188ste"] = {
				["cmd"] = ".tele SchlingendorntalDieungezaehmteKueste",
				["ypos"] = 0.3416708111763001,
				["xpos"] = 0.3543664813041687,
			},
			["Die wilden Ufer"] = {
				["cmd"] = ".tele SchlingendorntalDiewildenUfer",
				["ypos"] = 0.8282822966575623,
				["xpos"] = 0.2687046229839325,
			},
			["Geisterh\195\182hlenbau"] = {
				["cmd"] = ".tele SchlingendorntalGeisterhoehlenbau",
				["ypos"] = 0.6125301122665405,
				["xpos"] = 0.3486810922622681,
			},
			["Janeirospitze"] = {
				["cmd"] = ".tele SchlingendorntalJaneirospitze",
				["ypos"] = 0.707206130027771,
				["xpos"] = 0.2361485511064529,
			},
			["Kristalladermine"] = {
				["cmd"] = ".tele SchlingendorntalKristalladermine",
				["ypos"] = 0.5021307468414307,
				["xpos"] = 0.4138290584087372,
			},
			["Kurzens Truppenlager"] = {
				["cmd"] = ".tele SchlingendorntalKurzensTruppenlager",
				["ypos"] = 0.09819786250591278,
				["xpos"] = 0.4510864317417145,
			},
			["Nebeltal"] = {
				["cmd"] = ".tele SchlingendorntalNebeltal",
				["ypos"] = 0.6600000858306885,
				["xpos"] = 0.3276112377643585,
			},
			["Nek'maniquellbrunnen"] = {
				["cmd"] = ".tele SchlingendorntalNekmaniquellbrunnen",
				["ypos"] = 0.626035213470459,
				["xpos"] = 0.2826712727546692,
			},
			["Nesingwarys Expedition"] = {
				["cmd"] = ".tele SchlingendorntalNesingwarysExpedition",
				["ypos"] = 0.1070859804749489,
				["xpos"] = 0.3568098843097687,
			},
			["Ogerh\195\188gel der Mosh'Ogg"] = {
				["cmd"] = ".tele SchlingendorntalOgerhuegelderMoshOgg",
				["ypos"] = 0.2768345773220062,
				["xpos"] = 0.4985065460205078,
			},
			["Rebellenlager"] = {
				["cmd"] = ".tele SchlingendorntalRebellenlager",
				["ypos"] = 0.03355534374713898,
				["xpos"] = 0.3786128759384155,
			},
			["Ruinen von Aboraz"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonAboraz",
				["ypos"] = 0.5931439995765686,
				["xpos"] = 0.3979319334030151,
			},
			["Ruinen von Bal'lal"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonBallal",
				["ypos"] = 0.1900843530893326,
				["xpos"] = 0.2959575951099396,
			},
			["Ruinen von Balia'mah"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonBaliamah",
				["ypos"] = 0.323110431432724,
				["xpos"] = 0.4606025516986847,
			},
			["Ruinen von Jubuwal"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonJubuwal",
				["ypos"] = 0.5203956961631775,
				["xpos"] = 0.347694456577301,
			},
			["Ruinen von Kal'ai"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonKalai",
				["ypos"] = 0.2265307009220123,
				["xpos"] = 0.3450162708759308,
			},
			["Ruinen von Mizjah"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonMizjah",
				["ypos"] = 0.2955760657787323,
				["xpos"] = 0.371010959148407,
			},
			["Ruinen von Tkashi"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonTkashi",
				["ypos"] = 0.1561986804008484,
				["xpos"] = 0.3381318747997284,
			},
			["Ruinen von Ziata'jai"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonZiatajai",
				["ypos"] = 0.3592604398727417,
				["xpos"] = 0.4204489886760712,
			},
			["Ruinen von Zul'Kunda"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonZulKunda",
				["ypos"] = 0.1234437897801399,
				["xpos"] = 0.2379316538572311,
			},
			["Ruinen von Zul'Mamwe"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonZulMamwe",
				["ypos"] = 0.4194231927394867,
				["xpos"] = 0.4775514304637909,
			},
			["Ruinen von Zuuldaia"] = {
				["cmd"] = ".tele SchlingendorntalRuinenvonZuuldaia",
				["ypos"] = 0.1209049224853516,
				["xpos"] = 0.2030361294746399,
			},
			["St\195\188tzpunkt der Venture Co."] = {
				["cmd"] = ".tele SchlingendorntalStuetzpunktderVentureCo.",
				["ypos"] = 0.2015209794044495,
				["xpos"] = 0.4302263855934143,
			},
			["S\195\188dliche ungez\195\164hmte K\195\188ste"] = {
				["cmd"] = ".tele SchlingendorntalSuedlicheungezaehmteKueste",
				["ypos"] = 0.6982854008674622,
				["xpos"] = 0.2764576971530914,
			},
			["Truppenlager der Blutsegelbukaniere"] = {
				["cmd"] = ".tele SchlingendorntalTruppenlagerderBlutsegelbukaniere",
				["ypos"] = 0.4949619770050049,
				["xpos"] = 0.2273664772510529,
			},
			["Zul'Gurub"] = {
				["cmd"] = ".tele SchlingendorntalZulGurub",
				["ypos"] = 0.1757548749446869,
				["xpos"] = 0.5377930998802185,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 16,
			},
		},
		["Sengende Schlucht"] = {
			["Das Meer der Asche"] = {
				["cmd"] = ".tele SengendeSchluchtDasMeerderAsche",
				["ypos"] = 0.6449398398399353,
				["xpos"] = 0.5258926749229431,
			},
			["Der Kessel"] = {
				["cmd"] = ".tele SengendeSchluchtDerKessel",
				["ypos"] = 0.5303888320922852,
				["xpos"] = 0.4542491436004639,
			},
			["Der Schwarzfels"] = {
				["cmd"] = ".tele SengendeSchluchtDerSchwarzfels",
				["ypos"] = 0.8183799982070923,
				["xpos"] = 0.3358715176582336,
			},
			["Die Schlackengrube"] = {
				["cmd"] = ".tele SengendeSchluchtDieSchlackengrube",
				["ypos"] = 0.4584038257598877,
				["xpos"] = 0.4981246888637543,
			},
			["Feuerwachtgrat"] = {
				["cmd"] = ".tele SengendeSchluchtFeuerwachtgrat",
				["ypos"] = 0.367402970790863,
				["xpos"] = 0.2268905639648438,
			},
			["Gerbers Lager"] = {
				["cmd"] = ".tele SengendeSchluchtGerbersLager",
				["ypos"] = 0.7507312893867493,
				["xpos"] = 0.633970320224762,
			},
			["Ru\195\159schlacks Grabungsst\195\164tte"] = {
				["cmd"] = ".tele SengendeSchluchtRussschlacksGrabungsstaette",
				["ypos"] = 0.5962488651275635,
				["xpos"] = 0.6196631789207459,
			},
			["Schwarzbrandh\195\182hle"] = {
				["cmd"] = ".tele SengendeSchluchtSchwarzbrandhoehle",
				["ypos"] = 0.7821241021156311,
				["xpos"] = 0.2170714139938355,
			},
			["Sengende Schlucht"] = {
				["cmd"] = ".tele SengendeSchluchtSengendeSchlucht",
				["ypos"] = 0.6145567297935486,
				["xpos"] = 0.3332401216030121,
			},
			["Staubfeuertal"] = {
				["cmd"] = ".tele SengendeSchluchtStaubfeuertal",
				["ypos"] = 0.3591768443584442,
				["xpos"] = 0.6962289214134216,
			},
			["Steinwerkpass"] = {
				["cmd"] = ".tele SengendeSchluchtSteinwerkpass",
				["ypos"] = 0.05471903085708618,
				["xpos"] = 0.8863339424133301,
			},
			["Thoriumspitze"] = {
				["cmd"] = ".tele SengendeSchluchtThoriumspitze",
				["ypos"] = 0.2724380493164063,
				["xpos"] = 0.3704387843608856,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 17,
			},
		},
		["Shattrath"] = {
			["Bibliothek der Seher"] = {
				["cmd"] = ".tele ShattrathBibliothekderSeher",
				["ypos"] = 0.88704781,
				["xpos"] = 0.44186005,
			},
			["Schrein des endlosen Lichts"] = {
				["cmd"] = ".tele ShattrathSchreindesendlosenLichts",
				["ypos"] = 0.3007297515869141,
				["xpos"] = 0.2464525997638702,
			},
			["Taverne Weltenend"] = {
				["cmd"] = ".tele ShattrathTaverneWeltenend",
				["ypos"] = 0.3237077593803406,
				["xpos"] = 0.7512103915214539,
			},
			["Terrasse des Lichts"] = {
				["cmd"] = ".tele Shattrath",
				["ypos"] = 0.4311566352844238,
				["xpos"] = 0.561759889125824,
			},
			["Unteres Viertel"] = {
				["cmd"] = ".tele ShattrathUnteresViertel",
				["ypos"] = 0.2360331416130066,
				["xpos"] = 0.6983264684677124,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 6,
			},
		},
		["Sholazarbecken"] = {
			["Baldachin der Regenrufer"] = {
				["cmd"] = ".tele SholazarbeckenBaldachinderRegenrufer",
				["ypos"] = 0.5749151706695557,
				["xpos"] = 0.5303452014923096,
			},
			["Das Wilde Dickicht"] = {
				["cmd"] = ".tele SholazarbeckenDasWildeDickicht",
				["ypos"] = 0.2531292140483856,
				["xpos"] = 0.4876641035079956,
			},
			["Die Himmelszelts\195\164ule"] = {
				["cmd"] = ".tele SholazarbeckenDieHimmelszeltsaeule",
				["ypos"] = 0.7853163480758667,
				["xpos"] = 0.5312842130661011,
			},
			["Die Lawine"] = {
				["cmd"] = ".tele SholazarbeckenDieLawine",
				["ypos"] = 0.4509037435054779,
				["xpos"] = 0.725405216217041,
			},
			["Die Lebensbluts\195\164ule"] = {
				["cmd"] = ".tele SholazarbeckenDieLebensblutsaeule",
				["ypos"] = 0.5833719968795776,
				["xpos"] = 0.6676445603370667,
			},
			["Die Mooslichts\195\164ule"] = {
				["cmd"] = ".tele SholazarbeckenDieMooslichtsaeule",
				["ypos"] = 0.7572739124298096,
				["xpos"] = 0.3681828379631043,
			},
			["Die Schimmers\195\164ule"] = {
				["cmd"] = ".tele SholazarbeckenDieSchimmersaeule",
				["ypos"] = 0.3615975975990295,
				["xpos"] = 0.5016599893569946,
			},
			["Die Sonnenstrahls\195\164ule"] = {
				["cmd"] = ".tele SholazarbeckenDieSonnenstrahlsaeule",
				["ypos"] = 0.5348382592201233,
				["xpos"] = 0.3286259174346924,
			},
			["Die Verlorenen Lande"] = {
				["cmd"] = ".tele SholazarbeckenDieVerlorenenLande",
				["ypos"] = 0.4872249662876129,
				["xpos"] = 0.6735726594924927,
			},
			["Flussnabel"] = {
				["cmd"] = ".tele SholazarbeckenFlussnabel",
				["ypos"] = 0.6677818298339844,
				["xpos"] = 0.4810804128646851,
			},
			["Hort der Sch\195\182pfer"] = {
				["cmd"] = ".tele SholazarbeckenHortderSchoepfer",
				["ypos"] = 0.4029587507247925,
				["xpos"] = 0.290643721818924,
			},
			["H\195\188gel der Wildherzen"] = {
				["cmd"] = ".tele SholazarbeckenHuegelderWildherzen",
				["ypos"] = 0.6972567439079285,
				["xpos"] = 0.5504657030105591,
			},
			["Katarakt der Regenrufer"] = {
				["cmd"] = ".tele SholazarbeckenKataraktderRegenrufer",
				["ypos"] = 0.4907019138336182,
				["xpos"] = 0.6375716328620911,
			},
			["Nesingwarys Basislager"] = {
				["cmd"] = ".tele SholazarbeckenNesingwarysBasislager",
				["ypos"] = 0.5911230444908142,
				["xpos"] = 0.271344929933548,
			},
			["Sholazarbecken"] = {
				["cmd"] = ".tele Sholazarbecken",
				["ypos"] = 0.3545937538146973,
				["xpos"] = 0.5590924024581909,
			},
			["Warte der Sch\195\182pfer"] = {
				["cmd"] = ".tele SholazarbeckenWartederSchoepfer",
				["ypos"] = 0.5428853034973145,
				["xpos"] = 0.7955090999603272,
			},
			["Wildwuchsmangal"] = {
				["cmd"] = ".tele SholazarbeckenWildwuchsmangal",
				["ypos"] = 0.5622471570968628,
				["xpos"] = 0.442850261926651,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 10,
			},
		},
		["Silbermond"] = {
			["Der Basar"] = {
				["cmd"] = ".tele SilbermondDerBasar",
				["ypos"] = 0.6910255551338196,
				["xpos"] = 0.6071855425834656,
			},
			["Der k\195\182nigliche Markt"] = {
				["cmd"] = ".tele SilbermondDerkoeniglicheMarkt",
				["ypos"] = 0.5827172994613648,
				["xpos"] = 0.8558938503265381,
			},
			["Inneres Sanktum"] = {
				["cmd"] = ".tele SilbermondInneresSanktum",
				["ypos"] = 0.1750299334526062,
				["xpos"] = 0.5147926211357117,
			},
			["M\195\182rdergasse"] = {
				["cmd"] = ".tele SilbermondMoerdergasse",
				["ypos"] = 0.519935667514801,
				["xpos"] = 0.7603148221969605,
			},
			["Platz der Weltenwanderer"] = {
				["cmd"] = ".tele SilbermondPlatzderWeltenwanderer",
				["ypos"] = 0.3756574392318726,
				["xpos"] = 0.841555655002594,
			},
			["Sonnenhof"] = {
				["cmd"] = ".tele SilbermondSonnenhof",
				["ypos"] = 0.3302797377109528,
				["xpos"] = 0.6434062719345093,
			},
			["Sonnenzornturm"] = {
				["cmd"] = ".tele SilbermondSonnenzornturm",
				["ypos"] = 0.2207925319671631,
				["xpos"] = 0.5547609329223633,
			},
			["Stra\195\159e der Urahnen"] = {
				["cmd"] = ".tele Silbermond",
				["ypos"] = 0.7924050688743591,
				["xpos"] = 0.7422624826431274,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 18,
			},
		},
		["Silberwald"] = {
			["Berens List"] = {
				["cmd"] = ".tele SilberwaldBerensList",
				["ypos"] = 0.7271511554718018,
				["xpos"] = 0.6087297201156616,
			},
			["Burg Schattenfang"] = {
				["cmd"] = ".tele SilberwaldBurgSchattenfang",
				["ypos"] = 0.6829552054405212,
				["xpos"] = 0.4557178914546967,
			},
			["Das Grabmal"] = {
				["cmd"] = ".tele SilberwaldDasGrabmal",
				["ypos"] = 0.4138866662979126,
				["xpos"] = 0.4377785623073578,
			},
			["Das Huschdunkel"] = {
				["cmd"] = ".tele SilberwaldDasHuschdunkel",
				["ypos"] = 0.1332202255725861,
				["xpos"] = 0.3553071022033691,
			},
			["Das Ivarfeld"] = {
				["cmd"] = ".tele SilberwaldDasIvarfeld",
				["ypos"] = 0.1360631138086319,
				["xpos"] = 0.5256357192993164,
			},
			["Das Todesfeld"] = {
				["cmd"] = ".tele SilberwaldDasTodesfeld",
				["ypos"] = 0.225270226597786,
				["xpos"] = 0.4545595049858093,
			},
			["Der Graum\195\164hnenwall"] = {
				["cmd"] = ".tele SilberwaldDerGraumaehnenwall",
				["ypos"] = 0.8657295107841492,
				["xpos"] = 0.4577904343605042,
			},
			["Die Morgeninseln"] = {
				["cmd"] = ".tele SilberwaldDieMorgeninseln",
				["ypos"] = 0.2444023638963699,
				["xpos"] = 0.7735145092010498,
			},
			["Die verfallene F\195\164hre"] = {
				["cmd"] = ".tele SilberwaldDieverfalleneFaehre",
				["ypos"] = 0.3539173901081085,
				["xpos"] = 0.5893159508705139,
			},
			["Insel Fenris"] = {
				["cmd"] = ".tele SilberwaldInselFenris",
				["ypos"] = 0.332045316696167,
				["xpos"] = 0.6481310725212097,
			},
			["Lohenscheit"] = {
				["cmd"] = ".tele SilberwaldLohenscheit",
				["ypos"] = 0.7439759969711304,
				["xpos"] = 0.453840434551239,
			},
			["Maldens Obsthain"] = {
				["cmd"] = ".tele SilberwaldMaldensObsthain",
				["ypos"] = 0.09013807773590088,
				["xpos"] = 0.5658999681472778,
			},
			["M\195\188hlenbern"] = {
				["cmd"] = ".tele SilberwaldMuehlenbern",
				["ypos"] = 0.6405788064002991,
				["xpos"] = 0.6272323727607727,
			},
			["N\195\182rdliche Gezeitenlichtung"] = {
				["cmd"] = ".tele SilberwaldNoerdlicheGezeitenlichtung",
				["ypos"] = 0.2833127379417419,
				["xpos"] = 0.3803571164608002,
			},
			["N\195\182rdlicher Gezeitenstrom"] = {
				["cmd"] = ".tele SilberwaldNoerdlicherGezeitenstrom",
				["ypos"] = 0.4480870962142944,
				["xpos"] = 0.381418913602829,
			},
			["Olsens Acker"] = {
				["cmd"] = ".tele SilberwaldOlsensAcker",
				["ypos"] = 0.5473062992095947,
				["xpos"] = 0.4650856852531433,
			},
			["S\195\188dlicher Gezeitenstrom"] = {
				["cmd"] = ".tele SilberwaldSuedlicherGezeitenstrom",
				["ypos"] = 0.8016184568405151,
				["xpos"] = 0.391171395778656,
			},
			["Tiefenfelsmine"] = {
				["cmd"] = ".tele SilberwaldTiefenfelsmine",
				["ypos"] = 0.4615873992443085,
				["xpos"] = 0.5633571147918701,
			},
			["Valgans Feld"] = {
				["cmd"] = ".tele SilberwaldValgansFeld",
				["ypos"] = 0.2506391704082489,
				["xpos"] = 0.5264880657196045,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 19,
			},
		},
		["Silithus"] = {
			["Au\195\159enposten des Schattenhammers"] = {
				["cmd"] = ".tele SilithusAussenpostendesSchattenhammers",
				["ypos"] = 0.8339250087738037,
				["xpos"] = 0.1931087374687195,
			},
			["Basislager des Schattenhammers"] = {
				["cmd"] = ".tele SilithusBasislagerdesSchattenhammers",
				["ypos"] = 0.4513431191444397,
				["xpos"] = 0.3965404033660889,
			},
			["Bau des Ashischwarms"] = {
				["cmd"] = ".tele SilithusBaudesAshischwarms",
				["ypos"] = 0.2518319189548492,
				["xpos"] = 0.4985520541667938,
			},
			["Bau des Regalschwarms"] = {
				["cmd"] = ".tele SilithusBaudesRegalschwarms",
				["ypos"] = 0.58433445,
				["xpos"] = 0.81189163,
			},
			["Bau des Zoraschwarms"] = {
				["cmd"] = ".tele SilithusBaudesZoraschwarms",
				["ypos"] = 0.24814157,
				["xpos"] = 0.57903778,
			},
			["Bronzebarts Lager"] = {
				["cmd"] = ".tele SilithusBronzebartsLager",
				["ypos"] = 0.8892210721969605,
				["xpos"] = 0.4107698202133179,
			},
			["Burg Cenarius"] = {
				["cmd"] = ".tele SilithusBurgCenarius",
				["ypos"] = 0.3757652342319489,
				["xpos"] = 0.5096452832221985,
			},
			["Das Kristalltal"] = {
				["cmd"] = ".tele SilithusDasKristalltal",
				["ypos"] = 0.1567853540182114,
				["xpos"] = 0.2460983246564865,
			},
			["Der Skarab\195\164uswall"] = {
				["cmd"] = ".tele SilithusDerSkarabaeuswall",
				["ypos"] = 0.8747442960739136,
				["xpos"] = 0.2818512320518494,
			},
			["Die Schwarms\195\164ule"] = {
				["cmd"] = ".tele SilithusDieSchwarmsaeule",
				["ypos"] = 0.5217186808586121,
				["xpos"] = 0.5367094278335571,
			},
			["Heldenwacht"] = {
				["cmd"] = ".tele SilithusHeldenwacht",
				["ypos"] = 0.1814126074314117,
				["xpos"] = 0.8158438801765442,
			},
			["Hirschhaupts St\195\164tte"] = {
				["cmd"] = ".tele SilithusHirschhauptsStaette",
				["ypos"] = 0.2460851967334747,
				["xpos"] = 0.7002708315849304,
			},
			["Kavernen des Schattenhammers"] = {
				["cmd"] = ".tele SilithusKavernendesSchattenhammers",
				["ypos"] = 0.151949867606163,
				["xpos"] = 0.6886951327323914,
			},
			["Knochen von Grakkarond"] = {
				["cmd"] = ".tele SilithusKnochenvonGrakkarond",
				["ypos"] = 0.5474881529808044,
				["xpos"] = 0.4713166654109955,
			},
			["Ortells Unterschlupf"] = {
				["cmd"] = ".tele SilithusOrtellsUnterschlupf",
				["ypos"] = 0.7003601789474487,
				["xpos"] = 0.6619868874549866,
			},
			["Posten des Schattenhammers"] = {
				["cmd"] = ".tele SilithusPostendesSchattenhammers",
				["ypos"] = 0.3410745859146118,
				["xpos"] = 0.271075040102005,
			},
			["S\195\188dwindposten"] = {
				["cmd"] = ".tele SilithusSuedwindposten",
				["ypos"] = 0.534616231918335,
				["xpos"] = 0.6158974170684815,
			},
			["Tempel von Ahn'Qiraj"] = {
				["cmd"] = ".tele SilithusTempelvonAhnQiraj",
				["ypos"] = 0.9807,
				["xpos"] = 0.1561,
			},
			["Tore von Ahn'Qiraj"] = {
				["cmd"] = ".tele SilithusTorevonAhnQiraj",
				["ypos"] = 0.9909,
				["xpos"] = 0.2875,
			},
			["Verw\195\188steter St\195\188tzpunkt des Schattenhammers"] = {
				["cmd"] = ".tele SilithusVerwuesteterStuetzpunktdesSchattenhammers",
				["ypos"] = 0.08634230494499207,
				["xpos"] = 0.217597171664238,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 18,
			},
		},
		["Steinkrallengebirge"] = {
			["Camp Aparaje"] = {
				["cmd"] = ".tele SteinkrallengebirgeCampAparaje",
				["ypos"] = 0.9225486516952515,
				["xpos"] = 0.7805343270301819,
			},
			["Das verbrannte Tal"] = {
				["cmd"] = ".tele SteinkrallengebirgeDasverbrannteTal",
				["ypos"] = 0.6432788372039795,
				["xpos"] = 0.3372211754322052,
			},
			["Der Krallenbau"] = {
				["cmd"] = ".tele SteinkrallengebirgeDerKrallenbau",
				["ypos"] = 0.1520176827907562,
				["xpos"] = 0.299072265625,
			},
			["Der Steinkrallengipfel"] = {
				["cmd"] = ".tele SteinkrallengebirgeDerSteinkrallengipfel",
				["ypos"] = 0.1260242611169815,
				["xpos"] = 0.3636232018470764,
			},
			["Der Steinkrallenpfad"] = {
				["cmd"] = ".tele SteinkrallengebirgeDerSteinkrallenpfad",
				["ypos"] = 0.4286305904388428,
				["xpos"] = 0.7811962962150574,
			},
			["Die Scherwindklippe"] = {
				["cmd"] = ".tele SteinkrallengebirgeDieScherwindklippe",
				["ypos"] = 0.5049875378608704,
				["xpos"] = 0.5802274346351624,
			},
			["Felskesselsee"] = {
				["cmd"] = ".tele SteinkrallengebirgeFelskesselsee",
				["ypos"] = 0.3970380127429962,
				["xpos"] = 0.6358493566513062,
			},
			["Hochwipfeltal"] = {
				["cmd"] = ".tele SteinkrallengebirgeHochwipfeltal",
				["ypos"] = 0.9691380262374878,
				["xpos"] = 0.8305405974388123,
			},
			["Malaka'jin"] = {
				["cmd"] = ".tele SteinkrallengebirgeMalakajin",
				["ypos"] = 0.9546420574188232,
				["xpos"] = 0.7267589569091797,
			},
			["Mirkfallonsee"] = {
				["cmd"] = ".tele SteinkrallengebirgeMirkfallonsee",
				["ypos"] = 0.4133685827255249,
				["xpos"] = 0.4537062644958496,
			},
			["Posten der Grimmtotem"] = {
				["cmd"] = ".tele SteinkrallengebirgePostenderGrimmtotem",
				["ypos"] = 0.8602359890937805,
				["xpos"] = 0.7310068607330322,
			},
			["Scherwindmine"] = {
				["cmd"] = ".tele SteinkrallengebirgeScherwindmine",
				["ypos"] = 0.5958210825920105,
				["xpos"] = 0.7381271719932556,
			},
			["Schwarzwolfschnellen"] = {
				["cmd"] = ".tele SteinkrallengebirgeSchwarzwolfschnellen",
				["ypos"] = 0.5393985509872437,
				["xpos"] = 0.6541659832000732,
			},
			["Sishircanyon"] = {
				["cmd"] = ".tele SteinkrallengebirgeSishircanyon",
				["ypos"] = 0.7505279779434204,
				["xpos"] = 0.5326594114303589,
			},
			["Sonnenfels"] = {
				["cmd"] = ".tele SteinkrallengebirgeSonnenfels",
				["ypos"] = 0.6044687032699585,
				["xpos"] = 0.4690531492233276,
			},
			["Steinschlagh\195\182hle"] = {
				["cmd"] = ".tele SteinkrallengebirgeSteinschlaghoehle",
				["ypos"] = 0.9286316633224487,
				["xpos"] = 0.6146170496940613,
			},
			["Steinschlagklamm"] = {
				["cmd"] = ".tele SteinkrallengebirgeSteinschlagklamm",
				["ypos"] = 0.8896686434745789,
				["xpos"] = 0.6675267815589905,
			},
			["Weberpass"] = {
				["cmd"] = ".tele SteinkrallengebirgeWeberpass",
				["ypos"] = 0.7139595746994019,
				["xpos"] = 0.5976676344871521,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 19,
			},
		},
		["Sturmwind"] = {
			["Altstadt"] = {
				["cmd"] = ".tele SturmwindAltstadt",
				["ypos"] = 0.6523872017860413,
				["xpos"] = 0.7669510841369629,
			},
			["Burg Sturmwind"] = {
				["cmd"] = ".tele SturmwindBurgSturmwind",
				["ypos"] = 0.427251398563385,
				["xpos"] = 0.7638554573059082,
			},
			["Das Magierviertel"] = {
				["cmd"] = ".tele SturmwindDasMagierviertel",
				["ypos"] = 0.8162583708763123,
				["xpos"] = 0.4241084158420563,
			},
			["Das Tal der Helden"] = {
				["cmd"] = ".tele SturmwindDasTalderHelden",
				["ypos"] = 0.9336701631546021,
				["xpos"] = 0.7451815009117127,
			},
			["Der Park"] = {
				["cmd"] = ".tele SturmwindDerPark",
				["ypos"] = 0.6711152791976929,
				["xpos"] = 0.3615014553070068,
			},
			["Hafen von Sturmwind"] = {
				["cmd"] = ".tele SturmwindHafenvonSturmwind",
				["ypos"] = 0.367130845785141,
				["xpos"] = 0.2943155765533447,
			},
			["Handelsdistrikt"] = {
				["cmd"] = ".tele Sturmwind",
				["ypos"] = 0.7173073887825012,
				["xpos"] = 0.6293654441833496,
			},
			["Kathedralenplatz"] = {
				["cmd"] = ".tele SturmwindKathedralenplatz",
				["ypos"] = 0.5345227122306824,
				["xpos"] = 0.5415739417076111,
			},
			["Magiersanktum"] = {
				["cmd"] = ".tele SturmwindMagiersanktum",
				["ypos"] = 0.8725767135620117,
				["xpos"] = 0.4903919696807861,
			},
			["Zwergendistrikt"] = {
				["cmd"] = ".tele SturmwindZwergendistrikt",
				["ypos"] = 0.3734311461448669,
				["xpos"] = 0.6395742893218994,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 20,
			},
		},
		["Suempfe des Elends"] = {
			["Tempel von Atal'Hakkar"] = {
				["cmd"] = ".tele SuempfedesElendsTempelvonAtalHakkar",
				["ypos"] = 0.55835011,
				["xpos"] = 0.69595322,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 21,
			},
		},
		["Sumpfland"] = {
			["Baradinbucht"] = {
				["cmd"] = ".tele SumpflandBaradinbucht",
				["ypos"] = 0.1408334225416184,
				["xpos"] = 0.3157165050506592,
			},
			["Blaukiemenmarschen"] = {
				["cmd"] = ".tele SumpflandBlaukiemenmarschen",
				["ypos"] = 0.3741794228553772,
				["xpos"] = 0.2041584700345993,
			},
			["Bucht von Menethil"] = {
				["cmd"] = ".tele SumpflandBuchtvonMenethil",
				["ypos"] = 0.5827749371528626,
				["xpos"] = 0.1687173992395401,
			},
			["Der gr\195\188ne G\195\188rtel"] = {
				["cmd"] = ".tele SumpflandDergrueneGuertel",
				["ypos"] = 0.4408371448516846,
				["xpos"] = 0.6507678031921387,
			},
			["Die verlorene Flotte"] = {
				["cmd"] = ".tele SumpflandDieverloreneFlotte",
				["ypos"] = 0.2928194105625153,
				["xpos"] = 0.1529777497053146,
			},
			["Dun Algaz"] = {
				["cmd"] = ".tele SumpflandDunAlgaz",
				["ypos"] = 0.7560791969299316,
				["xpos"] = 0.4768048524856567,
			},
			["Dun Modr"] = {
				["cmd"] = ".tele SumpflandDunModr",
				["ypos"] = 0.1659114509820938,
				["xpos"] = 0.4719008803367615,
			},
			["Eisenbarts Grabmal"] = {
				["cmd"] = ".tele SumpflandEisenbartsGrabmal",
				["ypos"] = 0.2544375360012054,
				["xpos"] = 0.4426341652870178,
			},
			["Grim Batol"] = {
				["cmd"] = ".tele SumpflandGrimBatol",
				["ypos"] = 0.6915459632873535,
				["xpos"] = 0.7402003407478333,
			},
			["Hafen von Menethil"] = {
				["cmd"] = ".tele SumpflandHafenvonMenethil",
				["ypos"] = 0.5777319073677063,
				["xpos"] = 0.08838207274675369,
			},
			["H\195\188gel der D\195\188sterschmiede"] = {
				["cmd"] = ".tele SumpflandHuegelderDuesterschmiede",
				["ypos"] = 0.2487189918756485,
				["xpos"] = 0.6023207902908325,
			},
			["Lager der Grollhauer"] = {
				["cmd"] = ".tele SumpflandLagerderGrollhauer",
				["ypos"] = 0.4445911347866058,
				["xpos"] = 0.4538857042789459,
			},
			["Moosfellmoor"] = {
				["cmd"] = ".tele SumpflandMoosfellmoor",
				["ypos"] = 0.5771594047546387,
				["xpos"] = 0.6074286103248596,
			},
			["Raptorgrat"] = {
				["cmd"] = ".tele SumpflandRaptorgrat",
				["ypos"] = 0.3608480393886566,
				["xpos"] = 0.68922358751297,
			},
			["Sonnenwendmarschen"] = {
				["cmd"] = ".tele SumpflandSonnenwendmarschen",
				["ypos"] = 0.261264979839325,
				["xpos"] = 0.2650526463985443,
			},
			["Sumpfland"] = {
				["cmd"] = ".tele SumpflandSumpfland",
				["ypos"] = 0.3961412310600281,
				["xpos"] = 0.500898540019989,
			},
			["Thelgenfelsen"] = {
				["cmd"] = ".tele SumpflandThelgenfelsen",
				["ypos"] = 0.6382993459701538,
				["xpos"] = 0.5311378240585327,
			},
			["Tore des Drachenmals"] = {
				["cmd"] = ".tele SumpflandToredesDrachenmals",
				["ypos"] = 0.4779114425182343,
				["xpos"] = 0.807168185710907,
			},
			["Whelgars Ausgrabungsst\195\164tte"] = {
				["cmd"] = ".tele SumpflandWhelgarsAusgrabungsstaette",
				["ypos"] = 0.4988819658756256,
				["xpos"] = 0.3528052270412445,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 22,
			},
		},
		["S�mpfe des Elends"] = {
			["Das neblige Tal"] = {
				["cmd"] = ".tele SuempfedesElendsDasnebligeTal",
				["ypos"] = 0.3155753314495087,
				["xpos"] = 0.09098358452320099,
			},
			["Der sichere Hafen"] = {
				["cmd"] = ".tele SuempfedesElendsDersichereHafen",
				["ypos"] = 0.330556184053421,
				["xpos"] = 0.2626016438007355,
			},
			["Der Wabersumpf"] = {
				["cmd"] = ".tele SuempfedesElendsDerWabersumpf",
				["ypos"] = 0.3773736953735352,
				["xpos"] = 0.4364748001098633,
			},
			["Itharius' H\195\182hle"] = {
				["cmd"] = ".tele SuempfedesElendsIthariusHoehle",
				["ypos"] = 0.6800603270530701,
				["xpos"] = 0.1345108151435852,
			},
			["Nebelschilfposten"] = {
				["cmd"] = ".tele SuempfedesElendsNebelschilfposten",
				["ypos"] = 0.8055601119995117,
				["xpos"] = 0.8285117745399475,
			},
			["Nebelschilfstrand"] = {
				["cmd"] = ".tele SuempfedesElendsNebelschilfstrand",
				["ypos"] = 0.26247438788414,
				["xpos"] = 0.8910096883773804,
			},
			["Sorgendunkel"] = {
				["cmd"] = ".tele SuempfedesElendsSorgendunkel",
				["ypos"] = 0.5721015930175781,
				["xpos"] = 0.8546212911605835,
			},
			["Splitterspeerkreuzung"] = {
				["cmd"] = ".tele SuempfedesElendsSplitterspeerkreuzung",
				["ypos"] = 0.4981215000152588,
				["xpos"] = 0.1666190177202225,
			},
			["Stagalsumpfh\195\182hle"] = {
				["cmd"] = ".tele SuempfedesElendsStagalsumpfhoehle",
				["ypos"] = 0.7670702338218689,
				["xpos"] = 0.6631674766540527,
			},
			["Steinard"] = {
				["cmd"] = ".tele SuempfedesElendsSteinard",
				["ypos"] = 0.5438693165779114,
				["xpos"] = 0.4536996483802795,
			},
			["Tr\195\164nenteich"] = {
				["cmd"] = ".tele SuempfedesElendsTraenenteich",
				["ypos"] = 0.4464306235313416,
				["xpos"] = 0.7626652717590332,
			},
			["Zuflucht der Verirrten"] = {
				["cmd"] = ".tele SuempfedesElendsZufluchtderVerirrten",
				["ypos"] = 0.2351259738206863,
				["xpos"] = 0.5865345001220703,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 21,
			},
		},
		["Tanaris"] = {
			["Dampfdruckpier"] = {
				["cmd"] = ".tele TanarisDampfdruckpier",
				["ypos"] = 0.2320587486028671,
				["xpos"] = 0.6707754135131836,
			},
			["Der Giftige Unterschlupf"] = {
				["cmd"] = ".tele TanarisDerGiftigeUnterschlupf",
				["ypos"] = 0.4703079462051392,
				["xpos"] = 0.3350305557250977,
			},
			["Die ewigen Sande"] = {
				["cmd"] = ".tele TanarisDieewigenSande",
				["ypos"] = 0.4491080343723297,
				["xpos"] = 0.4297446012496948,
			},
			["Die Klaffende Schlucht"] = {
				["cmd"] = ".tele TanarisDieKlaffendeSchlucht",
				["ypos"] = 0.7438160181045532,
				["xpos"] = 0.5403662919998169,
			},
			["Disteltal"] = {
				["cmd"] = ".tele TanarisDisteltal",
				["ypos"] = 0.6521978974342346,
				["xpos"] = 0.2962014675140381,
			},
			["Gadgetzan"] = {
				["cmd"] = ".tele TanarisGadgetzan",
				["ypos"] = 0.2715503871440888,
				["xpos"] = 0.5217655897140503,
			},
			["H\195\182hlen der Zeit"] = {
				["cmd"] = ".tele TanarisHoehlenderZeit",
				["ypos"] = 0.5010915994644165,
				["xpos"] = 0.649232804775238,
			},
			["H\195\182hlen der Zeit - Ausmerzen von Stratholme"] = {
				["cmd"] = ".tele TanarisHoehlenderZeitAusmerzenvonStratholme",
				["ypos"] = 0.62649349,
				["xpos"] = 0.61457108,
			},
			["H\195\182hlen der Zeit - Der schwarze Morast"] = {
				["cmd"] = ".tele TanarisHoehlenderZeitDerschwarzeMorast",
				["ypos"] = 0.62731064,
				["xpos"] = 0.57467319,
			},
			["H\195\182hlen der Zeit - Hyjalgipfel"] = {
				["cmd"] = ".tele TanarisHoehlenderZeitHyjalgipfel",
				["ypos"] = 0.49992359,
				["xpos"] = 0.57378387,
			},
			["H\195\182hlen der Zeit - Vorgebirge des alten H\195\188gellandes"] = {
				["cmd"] = ".tele TanarisHoehlenderZeitVorgebirgedesaltenHuegellande",
				["ypos"] = 0.53956161,
				["xpos"] = 0.55686359,
			},
			["Landendestrand"] = {
				["cmd"] = ".tele TanarisLandendestrand",
				["ypos"] = 0.9457158446311951,
				["xpos"] = 0.5360339283943176,
			},
			["Mast- und Schotbucht"] = {
				["cmd"] = ".tele TanarisMast-undSchotbucht",
				["ypos"] = 0.4692422151565552,
				["xpos"] = 0.7417842745780945,
			},
			["Ostmondruinen"] = {
				["cmd"] = ".tele TanarisOstmondruinen",
				["ypos"] = 0.6505893468856812,
				["xpos"] = 0.4662476181983948,
			},
			["Sandmarterwache"] = {
				["cmd"] = ".tele TanarisSandmarterwache",
				["ypos"] = 0.2977892458438873,
				["xpos"] = 0.3960728943347931,
			},
			["S\195\188dbrandung"] = {
				["cmd"] = ".tele TanarisSuedbrandung",
				["ypos"] = 0.606140673160553,
				["xpos"] = 0.6524285674095154,
			},
			["S\195\188dmondruinen"] = {
				["cmd"] = ".tele TanarisSuedmondruinen",
				["ypos"] = 0.7241391539573669,
				["xpos"] = 0.4051145315170288,
			},
			["Tagschattenruinen"] = {
				["cmd"] = ".tele TanarisTagschattenruinen",
				["ypos"] = 0.2271695584058762,
				["xpos"] = 0.592576801776886,
			},
			["Tal der Beh\195\188ter"] = {
				["cmd"] = ".tele TanarisTalderBehueter",
				["ypos"] = 0.7702719569206238,
				["xpos"] = 0.3685311079025269,
			},
			["Truppenlager der D\195\188nenbrecher"] = {
				["cmd"] = ".tele TanarisTruppenlagerderDuenenbrecher",
				["ypos"] = 0.5690304636955261,
				["xpos"] = 0.4063242375850678,
			},
			["Wasserfeld"] = {
				["cmd"] = ".tele TanarisWasserfeld",
				["ypos"] = 0.3226222693920136,
				["xpos"] = 0.6346213817596436,
			},
			["Zalashjis Bau"] = {
				["cmd"] = ".tele TanarisZalashjisBau",
				["ypos"] = 0.3213150799274445,
				["xpos"] = 0.6770107746124268,
			},
			["Zerbrochene S\195\164ule"] = {
				["cmd"] = ".tele TanarisZerbrocheneSaeule",
				["ypos"] = 0.4613504111766815,
				["xpos"] = 0.5324704647064209,
			},
			["Zul'Farrak"] = {
				["cmd"] = ".tele TanarisZulFarrak",
				["ypos"] = 0.2030449658632278,
				["xpos"] = 0.3873392939567566,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 20,
			},
		},
		["Tausend Nadeln"] = {
			["Bau der Wildfedern"] = {
				["cmd"] = ".tele TausendNadelnBauderWildfedern",
				["ypos"] = 0.5099875926971436,
				["xpos"] = 0.2735356390476227,
			},
			["Camp E'thok"] = {
				["cmd"] = ".tele TausendNadelnCampEthok",
				["ypos"] = 0.2230136692523956,
				["xpos"] = 0.18587426841259,
			},
			["Der gro\195\159e Aufzug"] = {
				["cmd"] = ".tele TausendNadelnDergrosseAufzug",
				["ypos"] = 0.2224375456571579,
				["xpos"] = 0.3221765458583832,
			},
			["Der kreischende Canyon"] = {
				["cmd"] = ".tele TausendNadelnDerkreischendeCanyon",
				["ypos"] = 0.4961782693862915,
				["xpos"] = 0.2787580490112305,
			},
			["Der Steilhang"] = {
				["cmd"] = ".tele TausendNadelnDerSteilhang",
				["ypos"] = 0.3524296283721924,
				["xpos"] = 0.1151990219950676,
			},
			["Der Wetterwinkel"] = {
				["cmd"] = ".tele TausendNadelnDerWetterwinkel",
				["ypos"] = 0.4255103468894959,
				["xpos"] = 0.5366288423538208,
			},
			["D\195\188sterwolkengipfel"] = {
				["cmd"] = ".tele TausendNadelnDuesterwolkengipfel",
				["ypos"] = 0.3850064277648926,
				["xpos"] = 0.3435924649238586,
			},
			["Eisensteinlager"] = {
				["cmd"] = ".tele TausendNadelnEisensteinlager",
				["ypos"] = 0.641607940196991,
				["xpos"] = 0.677830696105957,
			},
			["Freiwindposten"] = {
				["cmd"] = ".tele TausendNadelnFreiwindposten",
				["ypos"] = 0.5013864636421204,
				["xpos"] = 0.4554856419563294,
			},
			["Illusionenrennbahn"] = {
				["cmd"] = ".tele TausendNadelnIllusionenrennbahn",
				["ypos"] = 0.7621002197265625,
				["xpos"] = 0.7882606387138367,
			},
			["Rostnagels Grabungsst\195\164tte"] = {
				["cmd"] = ".tele TausendNadelnRostnagelsGrabungsstaette",
				["ypos"] = 0.8621228933334351,
				["xpos"] = 0.6907629370689392,
			},
			["Ruinen von Tahonda"] = {
				["cmd"] = ".tele TausendNadelnRuinenvonTahonda",
				["ypos"] = 0.877375066280365,
				["xpos"] = 0.7769492864608765,
			},
			["Schlucht der heulenden Winde"] = {
				["cmd"] = ".tele TausendNadelnSchluchtderheulendenWinde",
				["ypos"] = 0.4709569811820984,
				["xpos"] = 0.5435606241226196,
			},
			["Spalthufklippe"] = {
				["cmd"] = ".tele TausendNadelnSpalthufklippe",
				["ypos"] = 0.3804284632205963,
				["xpos"] = 0.4254447519779205,
			},
			["Weazels Krater"] = {
				["cmd"] = ".tele TausendNadelnWeazelsKrater",
				["ypos"] = 0.6516291499137878,
				["xpos"] = 0.7798513770103455,
			},
			["Wei\195\159gipfelposten"] = {
				["cmd"] = ".tele TausendNadelnWeissgipfelposten",
				["ypos"] = 0.3174353241920471,
				["xpos"] = 0.2140288203954697,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 21,
			},
		},
		["Tausendwintersee"] = {
			["Eiswasserf\195\164lle"] = {
				["cmd"] = ".tele Tausendwintersee",
				["ypos"] = 0.4783557057380676,
				["xpos"] = 0.7526841759681702,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 11,
			},
		},
		["Teldrassil"] = {
			["Al'Amethsee"] = {
				["cmd"] = ".tele TeldrassilAlAmethsee",
				["ypos"] = 0.729308545589447,
				["xpos"] = 0.5162555575370789,
			},
			["Aldrassil"] = {
				["cmd"] = ".tele TeldrassilAldrassil",
				["ypos"] = 0.4053185284137726,
				["xpos"] = 0.5923656225204468,
			},
			["Die Kluft"] = {
				["cmd"] = ".tele TeldrassilDieKluft",
				["ypos"] = 0.4474228918552399,
				["xpos"] = 0.5139923691749573,
			},
			["Die Lichtung des Orakels"] = {
				["cmd"] = ".tele TeldrassilDieLichtungdesOrakels",
				["ypos"] = 0.3447709381580353,
				["xpos"] = 0.380786120891571,
			},
			["Dolanaar"] = {
				["cmd"] = ".tele TeldrassilDolanaar",
				["ypos"] = 0.5832780599594116,
				["xpos"] = 0.5595356225967407,
			},
			["Grabh\195\188gel von Ban'ethil"] = {
				["cmd"] = ".tele TeldrassilGrabhuegelvonBanethil",
				["ypos"] = 0.5794147253036499,
				["xpos"] = 0.4433412253856659,
			},
			["H\195\182hle der Knarzklauen"] = {
				["cmd"] = ".tele TeldrassilHoehlederKnarzklauen",
				["ypos"] = 0.8004713654518127,
				["xpos"] = 0.3866166770458221,
			},
			["Laubschattental"] = {
				["cmd"] = ".tele TeldrassilLaubschattental",
				["ypos"] = 0.333392322063446,
				["xpos"] = 0.6040955781936646,
			},
			["Lichtung von Ban'ethil"] = {
				["cmd"] = ".tele TeldrassilLichtungvonBanethil",
				["ypos"] = 0.5246731042861939,
				["xpos"] = 0.4625982642173767,
			},
			["Quellsee"] = {
				["cmd"] = ".tele TeldrassilQuellsee",
				["ypos"] = 0.4285560548305512,
				["xpos"] = 0.4298970997333527,
			},
			["Rut'theran"] = {
				["cmd"] = ".tele TeldrassilRuttheran",
				["ypos"] = 0.9234904646873474,
				["xpos"] = 0.5617896318435669,
			},
			["Schattenweberh\195\182hle"] = {
				["cmd"] = ".tele TeldrassilSchattenweberhoehle",
				["ypos"] = 0.3201283514499664,
				["xpos"] = 0.5685892701148987,
			},
			["Sternenhauch"] = {
				["cmd"] = ".tele TeldrassilSternenhauch",
				["ypos"] = 0.5865041017532349,
				["xpos"] = 0.6738951802253723,
			},
			["Teiche von Arlithrien"] = {
				["cmd"] = ".tele TeldrassilTeichevonArlithrien",
				["ypos"] = 0.6688530445098877,
				["xpos"] = 0.4068576097488403,
			},
			["Teufelsfels"] = {
				["cmd"] = ".tele TeldrassilTeufelsfels",
				["ypos"] = 0.5274372696876526,
				["xpos"] = 0.546768844127655,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 22,
			},
		},
		["Teufelswald"] = {
			["Blutgiftposten"] = {
				["cmd"] = ".tele TeufelswaldBlutgiftposten",
				["ypos"] = 0.5256715416908264,
				["xpos"] = 0.3470796048641205,
			},
			["Das Smaragdrefugium"] = {
				["cmd"] = ".tele TeufelswaldDasSmaragdrefugium",
				["ypos"] = 0.8202143907546997,
				["xpos"] = 0.510225772857666,
			},
			["Der Eisenwald"] = {
				["cmd"] = ".tele TeufelswaldDerEisenwald",
				["ypos"] = 0.2434781789779663,
				["xpos"] = 0.4655072689056397,
			},
			["Die Blutgiftf\195\164lle"] = {
				["cmd"] = ".tele TeufelswaldDieBlutgiftfaelle",
				["ypos"] = 0.4834714233875275,
				["xpos"] = 0.4096133708953857,
			},
			["Eisenstammh\195\182hle"] = {
				["cmd"] = ".tele TeufelswaldEisenstammhoehle",
				["ypos"] = 0.1746316701173782,
				["xpos"] = 0.5574056506156921,
			},
			["Holzschlundfeste"] = {
				["cmd"] = ".tele TeufelswaldHolzschlundfeste",
				["ypos"] = 0.08841746300458908,
				["xpos"] = 0.6465859413146973,
			},
			["Jadefeuerbach"] = {
				["cmd"] = ".tele TeufelswaldJadefeuerbach",
				["ypos"] = 0.2077964991331101,
				["xpos"] = 0.4194880723953247,
			},
			["Jadefeuertal"] = {
				["cmd"] = ".tele TeufelswaldJadefeuertal",
				["ypos"] = 0.8628628253936768,
				["xpos"] = 0.4133919179439545,
			},
			["Jaedenar"] = {
				["cmd"] = ".tele TeufelswaldJaedenar",
				["ypos"] = 0.5882644653320313,
				["xpos"] = 0.3923280239105225,
			},
			["Lager der Totenwaldfelle"] = {
				["cmd"] = ".tele TeufelswaldLagerderTotenwaldfelle",
				["ypos"] = 0.9274759292602539,
				["xpos"] = 0.4894520938396454,
			},
			["Morlos'Aran"] = {
				["cmd"] = ".tele TeufelswaldMorlosAran",
				["ypos"] = 0.871779203414917,
				["xpos"] = 0.5799906253814697,
			},
			["Nachtlaublichtung"] = {
				["cmd"] = ".tele TeufelswaldNachtlaublichtung",
				["ypos"] = 0.2407128065824509,
				["xpos"] = 0.6215330362319946,
			},
			["Narbengrund"] = {
				["cmd"] = ".tele TeufelswaldNarbengrund",
				["ypos"] = 0.4302869141101837,
				["xpos"] = 0.4159213602542877,
			},
			["Revier der Teufelspfoten"] = {
				["cmd"] = ".tele TeufelswaldRevierderTeufelspfoten",
				["ypos"] = 0.07447316497564316,
				["xpos"] = 0.6186850070953369,
			},
			["Ruinen von Constellas"] = {
				["cmd"] = ".tele TeufelswaldRuinenvonConstellas",
				["ypos"] = 0.6807266473770142,
				["xpos"] = 0.3787018954753876,
			},
			["Schattenfeste"] = {
				["cmd"] = ".tele TeufelswaldSchattenfeste",
				["ypos"] = 0.5851325988769531,
				["xpos"] = 0.3540077209472656,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 23,
			},
		},
		["Tirisfal"] = {
			["Agamands M\195\188hlen"] = {
				["cmd"] = ".tele TirisfalAgamandsMuehlen",
				["ypos"] = 0.3433127999305725,
				["xpos"] = 0.4838095307350159,
			},
			["Alptraumtal"] = {
				["cmd"] = ".tele TirisfalAlptraumtal",
				["ypos"] = 0.5855206251144409,
				["xpos"] = 0.4149357378482819,
			},
			["Au\195\159enposten der Kreuzz\195\188gler"] = {
				["cmd"] = ".tele TirisfalAussenpostenderKreuzzuegler",
				["ypos"] = 0.2644646465778351,
				["xpos"] = 0.793517529964447,
			},
			["Balnirs Bauernhof"] = {
				["cmd"] = ".tele TirisfalBalnirsBauernhof",
				["ypos"] = 0.5993327498435974,
				["xpos"] = 0.76708984375,
			},
			["Blendwassersee"] = {
				["cmd"] = ".tele TirisfalBlendwassersee",
				["ypos"] = 0.3825294375419617,
				["xpos"] = 0.7152828574180603,
			},
			["Brill"] = {
				["cmd"] = ".tele TirisfalBrill",
				["ypos"] = 0.5234389901161194,
				["xpos"] = 0.6073166728019714,
			},
			["Das Bollwerk"] = {
				["cmd"] = ".tele TirisfalDasBollwerk",
				["ypos"] = 0.7042256593704224,
				["xpos"] = 0.8457096219062805,
			},
			["Das gro\195\159e Vestib\195\188l"] = {
				["cmd"] = ".tele TirisfalDasgrosseVestibuel",
				["ypos"] = 0.4659468829631805,
				["xpos"] = 0.3051124215126038,
			},
			["Das verlassene Anwesen"] = {
				["cmd"] = ".tele TirisfalDasverlasseneAnwesen",
				["ypos"] = 0.5611650943756104,
				["xpos"] = 0.5255542397499085,
			},
			["Die fl\195\188sternde K\195\188ste"] = {
				["cmd"] = ".tele TirisfalDiefluesterndeKueste",
				["ypos"] = 0.4310638606548309,
				["xpos"] = 0.3599055707454681,
			},
			["Die Nordk\195\188ste"] = {
				["cmd"] = ".tele TirisfalDieNordkueste",
				["ypos"] = 0.2926837503910065,
				["xpos"] = 0.6491865515708923,
			},
			["Garrens Schlupfwinkel"] = {
				["cmd"] = ".tele TirisfalGarrensSchlupfwinkel",
				["ypos"] = 0.3239269256591797,
				["xpos"] = 0.5830832123756409,
			},
			["Giftwebertal"] = {
				["cmd"] = ".tele TirisfalGiftwebertal",
				["ypos"] = 0.4374006688594818,
				["xpos"] = 0.8655392527580261,
			},
			["Gunthers Zufluchtsort"] = {
				["cmd"] = ".tele TirisfalGunthersZufluchtsort",
				["ypos"] = 0.4227451682090759,
				["xpos"] = 0.6827398538589478,
			},
			["Nachtwebergrund"] = {
				["cmd"] = ".tele TirisfalNachtwebergrund",
				["ypos"] = 0.5939168334007263,
				["xpos"] = 0.268900454044342,
			},
			["Schattengrab"] = {
				["cmd"] = ".tele TirisfalSchattengrab",
				["ypos"] = 0.7217260599136353,
				["xpos"] = 0.2998978793621063,
			},
			["Sollidens Bauernhof"] = {
				["cmd"] = ".tele TirisfalSollidensBauernhof",
				["ypos"] = 0.5196586847305298,
				["xpos"] = 0.3766923546791077,
			},
			["Todesend"] = {
				["cmd"] = ".tele TirisfalTodesend",
				["ypos"] = 0.6527335643768311,
				["xpos"] = 0.3198723793029785,
			},
			["Zeppelinturm Nordend"] = {
				["cmd"] = ".tele TirisfalZeppelinturmNordend",
				["ypos"] = 0.58940083,
				["xpos"] = 0.59203171,
			},
			["Zeppelinturm OG SDT"] = {
				["cmd"] = ".tele TirisfalZeppelinturmOGSDT",
				["ypos"] = 0.58870701,
				["xpos"] = 0.61096794,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 23,
			},
		},
		["Unterstadt"] = {
			["Das Apothekarium"] = {
				["cmd"] = ".tele UnterstadtDasApothekarium",
				["ypos"] = 0.5793576836585999,
				["xpos"] = 0.5700544714927673,
			},
			["Handwerksviertel"] = {
				["cmd"] = ".tele Unterstadt",
				["ypos"] = 0.4553405046463013,
				["xpos"] = 0.6604619026184082,
			},
			["Kriegsviertel"] = {
				["cmd"] = ".tele UnterstadtKriegsviertel",
				["ypos"] = 0.2351219952106476,
				["xpos"] = 0.5276059508323669,
			},
			["K\195\182nigsviertel"] = {
				["cmd"] = ".tele UnterstadtKoenigsviertel",
				["ypos"] = 0.9029048681259155,
				["xpos"] = 0.5661877393722534,
			},
			["Magieviertel"] = {
				["cmd"] = ".tele UnterstadtMagieviertel",
				["ypos"] = 0.1675582975149155,
				["xpos"] = 0.8446989059448242,
			},
			["Ruinen von Lordaeron"] = {
				["cmd"] = ".tele UnterstadtRuinenvonLordaeron",
				["ypos"] = 0.07293391972780228,
				["xpos"] = 0.6615375876426697,
			},
			["Schurkenviertel"] = {
				["cmd"] = ".tele UnterstadtSchurkenviertel",
				["ypos"] = 0.6630886793136597,
				["xpos"] = 0.804510772228241,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 24,
			},
		},
		["Verw�stete Lande"] = {
			["Altar der St\195\188rme"] = {
				["cmd"] = ".tele VerwuesteteLandeAltarderStuerme",
				["ypos"] = 0.3398095369338989,
				["xpos"] = 0.391557514667511,
			},
			["Anh\195\182he des Entweihers"] = {
				["cmd"] = ".tele VerwuesteteLandeAnhoehedesEntweihers",
				["ypos"] = 0.2998853623867035,
				["xpos"] = 0.4780159592628479,
			},
			["Burg Nethergarde"] = {
				["cmd"] = ".tele VerwuesteteLandeBurgNethergarde",
				["ypos"] = 0.1934926807880402,
				["xpos"] = 0.6450965404510498,
			},
			["Das Dunkle Portal"] = {
				["cmd"] = ".tele VerwuesteteLandeDasDunklePortal",
				["ypos"] = 0.5946866273880005,
				["xpos"] = 0.5865234136581421,
			},
			["Die faulende Narbe"] = {
				["cmd"] = ".tele VerwuesteteLandeDiefaulendeNarbe",
				["ypos"] = 0.5921338200569153,
				["xpos"] = 0.4201950132846832,
			},
			["Feste Schreckensfels"] = {
				["cmd"] = ".tele VerwuesteteLandeFesteSchreckensfels",
				["ypos"] = 0.1308957785367966,
				["xpos"] = 0.42439204454422,
			},
			["Garnisonswaffenkammer"] = {
				["cmd"] = ".tele VerwuesteteLandeGarnisonswaffenkammer",
				["ypos"] = 0.1516252756118774,
				["xpos"] = 0.5786912441253662,
			},
			["Schlangenschlinge"] = {
				["cmd"] = ".tele VerwuesteteLandeSchlangenschlinge",
				["ypos"] = 0.3337079286575317,
				["xpos"] = 0.6446047425270081,
			},
			["Schreckensfelsposten"] = {
				["cmd"] = ".tele VerwuesteteLandeSchreckensfelsposten",
				["ypos"] = 0.4305397570133209,
				["xpos"] = 0.4841982424259186,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 25,
			},
		},
		["Vorgebirge des H�gellands"] = {
			["Burg Durnholde"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsBurgDurnholde",
				["ypos"] = 0.4165419638156891,
				["xpos"] = 0.7778913974761963,
			},
			["Darroh\195\188gel"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsDarrohuegel",
				["ypos"] = 0.3357344567775726,
				["xpos"] = 0.4757159948348999,
			},
			["Der Azurschacht"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsDerAzurschacht",
				["ypos"] = 0.5955942273139954,
				["xpos"] = 0.2604889571666718,
			},
			["Die Felder des H\195\188gellands"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsDieFelderdesHuegellands",
				["ypos"] = 0.4275538921356201,
				["xpos"] = 0.3301834762096405,
			},
			["Dun Garok"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsDunGarok",
				["ypos"] = 0.7810078263282776,
				["xpos"] = 0.7080051898956299,
			},
			["Fegefeuerinsel"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsFegefeuerinsel",
				["ypos"] = 0.8016097545623779,
				["xpos"] = 0.1561184823513031,
			},
			["H\195\188gellandhof"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsHuegellandhof",
				["ypos"] = 0.4219777286052704,
				["xpos"] = 0.3056535720825195,
			},
			["Nethandersiedlung"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsNethandersiedlung",
				["ypos"] = 0.6085622310638428,
				["xpos"] = 0.6596864461898804,
			},
			["Oststrand"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsOststrand",
				["ypos"] = 0.7663640975952148,
				["xpos"] = 0.6280848979949951,
			},
			["S\195\188derstade"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsSuederstade",
				["ypos"] = 0.5726268887519836,
				["xpos"] = 0.5035377144813538,
			},
			["S\195\188dwacht"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsSuedwacht",
				["ypos"] = 0.5121345520019531,
				["xpos"] = 0.205356553196907,
			},
			["Tarrens M\195\188hle"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsTarrensMuehle",
				["ypos"] = 0.2006945759057999,
				["xpos"] = 0.6143468022346497,
			},
			["Weststrand"] = {
				["cmd"] = ".tele VorgebirgedesHuegellandsWeststrand",
				["ypos"] = 0.66547030210495,
				["xpos"] = 0.445658951997757,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 26,
			},
		},
		["Wald von Elwynn"] = {
			["Brackbrunns K\195\188rbisbeet"] = {
				["cmd"] = ".tele WaldvonElwynnBrackbrunnsKuerbisbeet",
				["ypos"] = 0.7886350750923157,
				["xpos"] = 0.6833298206329346,
			},
			["Der Steinh\195\188gelsee"] = {
				["cmd"] = ".tele WaldvonElwynnDerSteinhuegelsee",
				["ypos"] = 0.5987026691436768,
				["xpos"] = 0.7417056560516357,
			},
			["Donnerf\195\164lle"] = {
				["cmd"] = ".tele WaldvonElwynnDonnerfaelle",
				["ypos"] = 0.588692307472229,
				["xpos"] = 0.2379133701324463,
			},
			["Echokammmine"] = {
				["cmd"] = ".tele WaldvonElwynnEchokammmine",
				["ypos"] = 0.3222646117210388,
				["xpos"] = 0.476034551858902,
			},
			["Goldhain"] = {
				["cmd"] = ".tele WaldvonElwynnGoldhain",
				["ypos"] = 0.649735689163208,
				["xpos"] = 0.42512047290802,
			},
			["Heldenwache"] = {
				["cmd"] = ".tele WaldvonElwynnHeldenwache",
				["ypos"] = 0.5140454173088074,
				["xpos"] = 0.7414058446884155,
			},
			["Hof der Steinfelds"] = {
				["cmd"] = ".tele WaldvonElwynnHofderSteinfelds",
				["ypos"] = 0.874946653842926,
				["xpos"] = 0.32957723736763,
			},
			["Holzf\195\164llerlager des Osttals"] = {
				["cmd"] = ".tele WaldvonElwynnHolzfaellerlagerdesOsttals",
				["ypos"] = 0.6552965641021729,
				["xpos"] = 0.8174678087234497,
			},
			["Jaspismine"] = {
				["cmd"] = ".tele WaldvonElwynnJaspismine",
				["ypos"] = 0.5457107424736023,
				["xpos"] = 0.6187871694564819,
			},
			["Jerods Anlegestelle"] = {
				["cmd"] = ".tele WaldvonElwynnJerodsAnlegestelle",
				["ypos"] = 0.8758981227874756,
				["xpos"] = 0.4757240116596222,
			},
			["Kammwacht"] = {
				["cmd"] = ".tele WaldvonElwynnKammwacht",
				["ypos"] = 0.7888135313987732,
				["xpos"] = 0.8391635417938232,
			},
			["Kristallsee"] = {
				["cmd"] = ".tele WaldvonElwynnKristallsee",
				["ypos"] = 0.6581778526306152,
				["xpos"] = 0.488853394985199,
			},
			["Nordhaintal"] = {
				["cmd"] = ".tele WaldvonElwynnNordhaintal",
				["ypos"] = 0.4271528124809265,
				["xpos"] = 0.476737380027771,
			},
			["Obsthain am Spiegelsee"] = {
				["cmd"] = ".tele WaldvonElwynnObsthainamSpiegelsee",
				["ypos"] = 0.6641749739646912,
				["xpos"] = 0.3084790110588074,
			},
			["Tiefenschachtmine"] = {
				["cmd"] = ".tele WaldvonElwynnTiefenschachtmine",
				["ypos"] = 0.8348514437675476,
				["xpos"] = 0.3810798823833466,
			},
			["Turm von Azora"] = {
				["cmd"] = ".tele WaldvonElwynnTurmvonAzora",
				["ypos"] = 0.6860383152961731,
				["xpos"] = 0.6400423645973206,
			},
			["Weinberge der Maclures"] = {
				["cmd"] = ".tele WaldvonElwynnWeinbergederMaclures",
				["ypos"] = 0.8389491438865662,
				["xpos"] = 0.4167643189430237,
			},
			["Weinberge von Nordhain"] = {
				["cmd"] = ".tele WaldvonElwynnWeinbergevonNordhain",
				["ypos"] = 0.4908205568790436,
				["xpos"] = 0.5414270162582398,
			},
			["Weststromgarnison"] = {
				["cmd"] = ".tele WaldvonElwynnWeststromgarnison",
				["ypos"] = 0.7374446988105774,
				["xpos"] = 0.2465769946575165,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 27,
			},
		},
		["Westfall"] = {
			["Alexstons Bauernhof"] = {
				["cmd"] = ".tele WestfallAlexstonsBauernhof",
				["ypos"] = 0.5334857106208801,
				["xpos"] = 0.381533294916153,
			},
			["Brauenwirbels K\195\188rbishof"] = {
				["cmd"] = ".tele WestfallBrauenwirbelsKuerbishof",
				["ypos"] = 0.2157987207174301,
				["xpos"] = 0.5061161518096924,
			},
			["Demonts Heim"] = {
				["cmd"] = ".tele WestfallDemontsHeim",
				["ypos"] = 0.7384529709815979,
				["xpos"] = 0.3453109264373779,
			},
			["Der Goldk\195\188stensteinbruch"] = {
				["cmd"] = ".tele WestfallDerGoldkuestensteinbruch",
				["ypos"] = 0.4367490708827972,
				["xpos"] = 0.3177789151668549,
			},
			["Der Jangoschacht"] = {
				["cmd"] = ".tele WestfallDerJangoschacht",
				["ypos"] = 0.2594251334667206,
				["xpos"] = 0.4451436400413513,
			},
			["Der Leuchtturm von Westfall"] = {
				["cmd"] = ".tele WestfallDerLeuchtturmvonWestfall",
				["ypos"] = 0.8568001985549927,
				["xpos"] = 0.3053761720657349,
			},
			["Der Todesacker"] = {
				["cmd"] = ".tele WestfallDerTodesacker",
				["ypos"] = 0.5897934436798096,
				["xpos"] = 0.6099413633346558,
			},
			["Die Dolchh\195\188gel"] = {
				["cmd"] = ".tele WestfallDieDolchhuegel",
				["ypos"] = 0.8038008809089661,
				["xpos"] = 0.448132187128067,
			},
			["Die endlose K\195\188ste"] = {
				["cmd"] = ".tele WestfallDieendloseKueste",
				["ypos"] = 0.477385938167572,
				["xpos"] = 0.2689818739891052,
			},
			["Die Staubebenen"] = {
				["cmd"] = ".tele WestfallDieStaubebenen",
				["ypos"] = 0.7345656752586365,
				["xpos"] = 0.6825910210609436,
			},
			["Die Todesminen"] = {
				["cmd"] = ".tele WestfallDieTodesminen",
				["ypos"] = 0.8245280981063843,
				["xpos"] = 0.4051398932933807,
			},
			["Jansens Siedlung"] = {
				["cmd"] = ".tele WestfallJansensSiedlung",
				["ypos"] = 0.1833775341510773,
				["xpos"] = 0.5777830481529236,
			},
			["Molsens Hof"] = {
				["cmd"] = ".tele WestfallMolsensHof",
				["ypos"] = 0.3651002049446106,
				["xpos"] = 0.4507540464401245,
			},
			["Mondbruch"] = {
				["cmd"] = ".tele WestfallMondbruch",
				["ypos"] = 0.7210560441017151,
				["xpos"] = 0.4183775186538696,
			},
			["Saldeans Farm"] = {
				["cmd"] = ".tele WestfallSaldeansFarm",
				["ypos"] = 0.3307713866233826,
				["xpos"] = 0.5203590393066406,
			},
			["Sp\195\164herkuppe"] = {
				["cmd"] = ".tele WestfallSpaeherkuppe",
				["ypos"] = 0.521664023399353,
				["xpos"] = 0.5559783577919006,
			},
			["Sp\195\164herturm"] = {
				["cmd"] = ".tele WestfallSpaeherturm",
				["ypos"] = 0.4757143557071686,
				["xpos"] = 0.5627933144569397,
			},
			["Stendels T\195\188mpel"] = {
				["cmd"] = ".tele WestfallStendelsTuempel",
				["ypos"] = 0.6017089486122131,
				["xpos"] = 0.4690896570682526,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 28,
			},
		},
		["Westliche Pestl�nder"] = {
			["Burg Mardenholde"] = {
				["cmd"] = ".tele WestlichePestlaenderBurgMardenholde",
				["ypos"] = 0.4232615530490875,
				["xpos"] = 0.1504830718040466,
			},
			["Dalsons Tr\195\164nenfeld"] = {
				["cmd"] = ".tele WestlichePestlaenderDalsonsTraenenfeld",
				["ypos"] = 0.5417082905769348,
				["xpos"] = 0.4480693340301514,
			},
			["Darromersee"] = {
				["cmd"] = ".tele WestlichePestlaenderDarromersee",
				["ypos"] = 0.6903522610664368,
				["xpos"] = 0.5862730145454407,
			},
			["Darrowehr"] = {
				["cmd"] = ".tele WestlichePestlaenderDarrowehr",
				["ypos"] = 0.7452653646469116,
				["xpos"] = 0.701336681842804,
			},
			["Das trostlose Feld"] = {
				["cmd"] = ".tele WestlichePestlaenderDastrostloseFeld",
				["ypos"] = 0.6615179181098938,
				["xpos"] = 0.5208195447921753,
			},
			["Die Ruinen von Andorhal"] = {
				["cmd"] = ".tele WestlichePestlaenderDieRuinenvonAndorhal",
				["ypos"] = 0.6891745924949646,
				["xpos"] = 0.4441235661506653,
			},
			["Die weinende H\195\182hle"] = {
				["cmd"] = ".tele WestlichePestlaenderDieweinendeHoehle",
				["ypos"] = 0.4281803071498871,
				["xpos"] = 0.663141667842865,
			},
			["Gahrrons Trauerfeld"] = {
				["cmd"] = ".tele WestlichePestlaenderGahrronsTrauerfeld",
				["ypos"] = 0.5822074413299561,
				["xpos"] = 0.6113069653511047,
			},
			["Herdweiler"] = {
				["cmd"] = ".tele WestlichePestlaenderHerdweiler",
				["ypos"] = 0.2147176563739777,
				["xpos"] = 0.4806096255779266,
			},
			["S\195\164gewerk des Nordkamms"] = {
				["cmd"] = ".tele WestlichePestlaenderSaegewerkdesNordkamms",
				["ypos"] = 0.3151048421859741,
				["xpos"] = 0.4759118258953095,
			},
			["Teufelssteinfeld"] = {
				["cmd"] = ".tele WestlichePestlaenderTeufelssteinfeld",
				["ypos"] = 0.5776491761207581,
				["xpos"] = 0.3731372952461243,
			},
			["Thondroril"] = {
				["cmd"] = ".tele WestlichePestlaenderThondroril",
				["ypos"] = 0.5022284984588623,
				["xpos"] = 0.698634684085846,
			},
			["Trauerh\195\188gel"] = {
				["cmd"] = ".tele WestlichePestlaenderTrauerhuegel",
				["ypos"] = 0.7437352538108826,
				["xpos"] = 0.4974708259105682,
			},
			["Uthers Grabmal"] = {
				["cmd"] = ".tele WestlichePestlaenderUthersGrabmal",
				["ypos"] = 0.8314204216003418,
				["xpos"] = 0.5205886960029602,
			},
			["Westliche Pestl\195\164nder"] = {
				["cmd"] = ".tele WestlichePestlaenderWestlichePestlaender",
				["ypos"] = 0.5597267150878906,
				["xpos"] = 0.5506148338317871,
			},
			["Zugwindlager"] = {
				["cmd"] = ".tele WestlichePestlaenderZugwindlager",
				["ypos"] = 0.8411296010017395,
				["xpos"] = 0.4293088018894196,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 29,
			},
		},
		["Winterquell"] = {
			["Der versteckte Hain"] = {
				["cmd"] = ".tele WinterquellDerversteckteHain",
				["ypos"] = 0.188356414437294,
				["xpos"] = 0.6505779623985291,
			},
			["Die fl\195\188sternde Schlucht"] = {
				["cmd"] = ".tele WinterquellDiefluesterndeSchlucht",
				["ypos"] = 0.7424837350845337,
				["xpos"] = 0.5982075333595276,
			},
			["Die Frostfeuerquellen"] = {
				["cmd"] = ".tele WinterquellDieFrostfeuerquellen",
				["ypos"] = 0.3594452142715454,
				["xpos"] = 0.306797206401825,
			},
			["Die Ruinen von Kel'Theril"] = {
				["cmd"] = ".tele WinterquellDieRuinenvonKelTheril",
				["ypos"] = 0.4346053302288055,
				["xpos"] = 0.5548171997070313,
			},
			["Dun Mandarr"] = {
				["cmd"] = ".tele WinterquellDunMandarr",
				["ypos"] = 0.5986224412918091,
				["xpos"] = 0.5914463996887207,
			},
			["Eisdistelberge"] = {
				["cmd"] = ".tele WinterquellEisdistelberge",
				["ypos"] = 0.5019885301589966,
				["xpos"] = 0.666946291923523,
			},
			["Eulenfl\195\188geldickicht"] = {
				["cmd"] = ".tele WinterquellEulenfluegeldickicht",
				["ypos"] = 0.6045896410942078,
				["xpos"] = 0.6545066833496094,
			},
			["Ewige Warte"] = {
				["cmd"] = ".tele WinterquellEwigeWarte",
				["ypos"] = 0.3827938139438629,
				["xpos"] = 0.6116088628768921,
			},
			["Frosthauchschlucht"] = {
				["cmd"] = ".tele WinterquellFrosthauchschlucht",
				["ypos"] = 0.6885603666305542,
				["xpos"] = 0.6190899610519409,
			},
			["Frosts\195\164blerfelsen"] = {
				["cmd"] = ".tele WinterquellFrostsaeblerfelsen",
				["ypos"] = 0.09784950315952301,
				["xpos"] = 0.4989987015724182,
			},
			["Holzschlundposten"] = {
				["cmd"] = ".tele WinterquellHolzschlundposten",
				["ypos"] = 0.4327270090579987,
				["xpos"] = 0.4002464115619659,
			},
			["Lager der Winterfelle"] = {
				["cmd"] = ".tele WinterquellLagerderWinterfelle",
				["ypos"] = 0.3455846011638641,
				["xpos"] = 0.6676773428916931,
			},
			["Mazthoril"] = {
				["cmd"] = ".tele WinterquellMazthoril",
				["ypos"] = 0.5024195313453674,
				["xpos"] = 0.5814481377601624,
			},
			["Sternfall"] = {
				["cmd"] = ".tele WinterquellSternfall",
				["ypos"] = 0.2888377904891968,
				["xpos"] = 0.5169302225112915,
			},
			["coord"] = {
				["continent"] = 1,
				["zone"] = 24,
			},
		},
		["W�lder von Terokkar"] = {
			["Aash\195\188gel"] = {
				["cmd"] = ".tele WaeldervonTerokkarAashuegel",
				["ypos"] = 0.5059666633605957,
				["xpos"] = 0.4344117343425751,
			},
			["Allerias Feste"] = {
				["cmd"] = ".tele WaeldervonTerokkarAlleriasFeste",
				["ypos"] = 0.5397500395774841,
				["xpos"] = 0.5761357545852661,
			},
			["Allerias Posten"] = {
				["cmd"] = ".tele WaeldervonTerokkarAlleriasPosten",
				["ypos"] = 0.4391500055789948,
				["xpos"] = 0.6948431730270386,
			},
			["Auchenaikrypta"] = {
				["cmd"] = ".tele WaeldervonTerokkarAuchenaikrypta",
				["ypos"] = 0.6561077833175659,
				["xpos"] = 0.3448636531829834,
			},
			["Cenariusdickicht"] = {
				["cmd"] = ".tele WaeldervonTerokkarCenariusdickicht",
				["ypos"] = 0.2351583242416382,
				["xpos"] = 0.4429820477962494,
			},
			["Der gequ\195\164lte H\195\188gel"] = {
				["cmd"] = ".tele WaeldervonTerokkarDergequaelteHuegel",
				["ypos"] = 0.6756722331047058,
				["xpos"] = 0.4946950376033783,
			},
			["Die herrenlose Karawane"] = {
				["cmd"] = ".tele WaeldervonTerokkarDieherrenloseKarawane",
				["ypos"] = 0.7478722333908081,
				["xpos"] = 0.4290765225887299,
			},
			["Die Knochenw\195\188ste"] = {
				["cmd"] = ".tele WaeldervonTerokkarDieKnochenwueste",
				["ypos"] = 0.5158166289329529,
				["xpos"] = 0.4043117165565491,
			},
			["Fl\195\188chtlingskarawane"] = {
				["cmd"] = ".tele WaeldervonTerokkarFluechtlingskarawane",
				["ypos"] = 0.5079758167266846,
				["xpos"] = 0.3677741885185242,
			},
			["Grab des Lichts"] = {
				["cmd"] = ".tele WaeldervonTerokkarGrabdesLichts",
				["ypos"] = 0.5550583004951477,
				["xpos"] = 0.4700950682163239,
			},
			["Grangol'var"] = {
				["cmd"] = ".tele WaeldervonTerokkarGrangolvar",
				["ypos"] = 0.4052777886390686,
				["xpos"] = 0.3848024308681488,
			},
			["Jorunesee"] = {
				["cmd"] = ".tele WaeldervonTerokkarJorunesee",
				["ypos"] = 0.4003500044345856,
				["xpos"] = 0.4528154134750366,
			},
			["Lithicversteck"] = {
				["cmd"] = ".tele WaeldervonTerokkarLithicversteck",
				["ypos"] = 0.7221277356147766,
				["xpos"] = 0.2383153438568115,
			},
			["Managruft"] = {
				["cmd"] = ".tele WaeldervonTerokkarManagruft",
				["ypos"] = 0.5799088478088379,
				["xpos"] = 0.3962572515010834,
			},
			["Messerdornbank"] = {
				["cmd"] = ".tele WaeldervonTerokkarMesserdornbank",
				["ypos"] = 0.2002166956663132,
				["xpos"] = 0.5564506053924561,
			},
			["Netherweberkamm"] = {
				["cmd"] = ".tele WaeldervonTerokkarNetherweberkamm",
				["ypos"] = 0.8176000118255615,
				["xpos"] = 0.5371710062026978,
			},
			["Posten der Feuerschwingen"] = {
				["cmd"] = ".tele WaeldervonTerokkarPostenderFeuerschwingen",
				["ypos"] = 0.3741194903850555,
				["xpos"] = 0.7047005891799927,
			},
			["Raastokgrund"] = {
				["cmd"] = ".tele WaeldervonTerokkarRaastokgrund",
				["ypos"] = 0.4227027893066406,
				["xpos"] = 0.5934098362922669,
			},
			["Reskkversteck"] = {
				["cmd"] = ".tele WaeldervonTerokkarReskkversteck",
				["ypos"] = 0.1550416946411133,
				["xpos"] = 0.4958950281143189,
			},
			["Rhazeversteck"] = {
				["cmd"] = ".tele WaeldervonTerokkarRhazeversteck",
				["ypos"] = 0.5829055309295654,
				["xpos"] = 0.2682227492332459,
			},
			["Ring der Beobachtung"] = {
				["cmd"] = ".tele WaeldervonTerokkarRingderBeobachtung",
				["ypos"] = 0.6463889479637146,
				["xpos"] = 0.3991218209266663,
			},
			["Ruinen der Knochenmalmer"] = {
				["cmd"] = ".tele WaeldervonTerokkarRuinenderKnochenmalmer",
				["ypos"] = 0.5446277856826782,
				["xpos"] = 0.6554653644561768,
			},
			["Ruinen des Blutenden Auges"] = {
				["cmd"] = ".tele WaeldervonTerokkarRuinendesBlutendenAuges",
				["ypos"] = 0.6314083337783814,
				["xpos"] = 0.2044801712036133,
			},
			["Schattengrab"] = {
				["cmd"] = ".tele WaeldervonTerokkarSchattengrab",
				["ypos"] = 0.5266472101211548,
				["xpos"] = 0.3133932054042816,
			},
			["Schattenlabyrinth"] = {
				["cmd"] = ".tele WaeldervonTerokkarSchattenlabyrinth",
				["ypos"] = 0.7339802980422974,
				["xpos"] = 0.3962570726871491,
			},
			["Schattenwindlager"] = {
				["cmd"] = ".tele WaeldervonTerokkarSchattenwindlager",
				["ypos"] = 0.6536917090415955,
				["xpos"] = 0.6360338926315308,
			},
			["Schattenwindsee"] = {
				["cmd"] = ".tele WaeldervonTerokkarSchattenwindsee",
				["ypos"] = 0.8054027557373047,
				["xpos"] = 0.6402987241744995,
			},
			["See von Ere'Noru"] = {
				["cmd"] = ".tele WaeldervonTerokkarSeevonEreNoru",
				["ypos"] = 0.6121000051498413,
				["xpos"] = 0.5866580009460449,
			},
			["Sethekkhallen"] = {
				["cmd"] = ".tele WaeldervonTerokkarSethekkhallen",
				["ypos"] = 0.6561606526374817,
				["xpos"] = 0.4477391839027405,
			},
			["Shalasversteck"] = {
				["cmd"] = ".tele WaeldervonTerokkarShalasversteck",
				["ypos"] = 0.6724639534950256,
				["xpos"] = 0.5669023990631104,
			},
			["Shienorversteck"] = {
				["cmd"] = ".tele WaeldervonTerokkarShienorversteck",
				["ypos"] = 0.2509972155094147,
				["xpos"] = 0.588556170463562,
			},
			["Silmyrsee"] = {
				["cmd"] = ".tele WaeldervonTerokkarSilmyrsee",
				["ypos"] = 0.1054972484707832,
				["xpos"] = 0.4160931408405304,
			},
			["Skettis"] = {
				["cmd"] = ".tele WaeldervonTerokkarSkettis",
				["ypos"] = 0.716188907623291,
				["xpos"] = 0.6588524580001831,
			},
			["Skithversteck"] = {
				["cmd"] = ".tele WaeldervonTerokkarSkithversteck",
				["ypos"] = 0.4301472306251526,
				["xpos"] = 0.3095727562904358,
			},
			["Steinbrecherfeste"] = {
				["cmd"] = ".tele WaeldervonTerokkarSteinbrecherfeste",
				["ypos"] = 0.4502361416816711,
				["xpos"] = 0.4982653558254242,
			},
			["Steinbrecherlager"] = {
				["cmd"] = ".tele WaeldervonTerokkarSteinbrecherlager",
				["ypos"] = 0.4253832995891571,
				["xpos"] = 0.631087601184845,
			},
			["Tuurem"] = {
				["cmd"] = ".tele WaeldervonTerokkarTuurem",
				["ypos"] = 0.3193944692611694,
				["xpos"] = 0.5345376133918762,
			},
			["Waynes Zuflucht"] = {
				["cmd"] = ".tele WaeldervonTerokkarWaynesZuflucht",
				["ypos"] = 0.3863138854503632,
				["xpos"] = 0.7741931676864624,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 7,
			},
		},
		["Zangarmarschen"] = {
			["Blutschuppengrund"] = {
				["cmd"] = ".tele ZangarmarschenBlutschuppengrund",
				["ypos"] = 0.3981442451477051,
				["xpos"] = 0.6273677349090576,
			},
			["Das Pilzgeflecht"] = {
				["cmd"] = ".tele ZangarmarschenDasPilzgeflecht",
				["ypos"] = 0.6067031621932983,
				["xpos"] = 0.1489709913730621,
			},
			["Das Todesmoor"] = {
				["cmd"] = ".tele ZangarmarschenDasTodesmoor",
				["ypos"] = 0.4510743021965027,
				["xpos"] = 0.8153434991836548,
			},
			["Der Echsenkessel"] = {
				["cmd"] = ".tele ZangarmarschenDerEchsenkessel",
				["ypos"] = 0.3585142493247986,
				["xpos"] = 0.5189728736877441,
			},
			["Die Lagune"] = {
				["cmd"] = ".tele ZangarmarschenDieLagune",
				["ypos"] = 0.6120488047599793,
				["xpos"] = 0.593716025352478,
			},
			["Dolchfenn"] = {
				["cmd"] = ".tele ZangarmarschenDolchfenn",
				["ypos"] = 0.234969288110733,
				["xpos"] = 0.2397513389587402,
			},
			["Enklave der Blutschuppen"] = {
				["cmd"] = ".tele ZangarmarschenEnklavederBlutschuppen",
				["ypos"] = 0.4265796840190888,
				["xpos"] = 0.2670335471630096,
			},
			["Enklave der Dunkelk\195\164mme"] = {
				["cmd"] = ".tele ZangarmarschenEnklavederDunkelkaemme",
				["ypos"] = 0.6880114674568176,
				["xpos"] = 0.6333931088447571,
			},
			["Festung der Ango'rosh"] = {
				["cmd"] = ".tele ZangarmarschenFestungderAngorosh",
				["ypos"] = 0.09161069244146347,
				["xpos"] = 0.185809537768364,
			},
			["Funggorh\195\182hle"] = {
				["cmd"] = ".tele ZangarmarschenFunggorhoehle",
				["ypos"] = 0.9123808741569519,
				["xpos"] = 0.7488358020782471,
			},
			["Grund der Ango'rosh"] = {
				["cmd"] = ".tele ZangarmarschenGrundderAngorosh",
				["ypos"] = 0.2356763035058975,
				["xpos"] = 0.1881328970193863,
			},
			["Oreborzuflucht"] = {
				["cmd"] = ".tele ZangarmarschenOreborzuflucht",
				["ypos"] = 0.3019407689571381,
				["xpos"] = 0.4161279797554016,
			},
			["Portalsicherung"] = {
				["cmd"] = ".tele ZangarmarschenPortalsicherung",
				["ypos"] = 0.4069173038005829,
				["xpos"] = 0.1621913760900497,
			},
			["Pr\195\188gelsumpf"] = {
				["cmd"] = ".tele ZangarmarschenPruegelsumpf",
				["ypos"] = 0.3149124085903168,
				["xpos"] = 0.344999223947525,
			},
			["Quaggkamm"] = {
				["cmd"] = ".tele ZangarmarschenQuaggkamm",
				["ypos"] = 0.6284615993499756,
				["xpos"] = 0.2950079739093781,
			},
			["Ruinen der Zwillingsspitze"] = {
				["cmd"] = ".tele ZangarmarschenRuinenderZwillingsspitze",
				["ypos"] = 0.5102565884590149,
				["xpos"] = 0.5015811324119568,
			},
			["Ruinen von Boha'mu"] = {
				["cmd"] = ".tele ZangarmarschenRuinenvonBohamu",
				["ypos"] = 0.6804322600364685,
				["xpos"] = 0.4411544501781464,
			},
			["Schlangensee"] = {
				["cmd"] = ".tele ZangarmarschenSchlangensee",
				["ypos"] = 0.4553671479225159,
				["xpos"] = 0.4687568843364716,
			},
			["Sporeggar"] = {
				["cmd"] = ".tele ZangarmarschenSporeggar",
				["ypos"] = 0.5071612000465393,
				["xpos"] = 0.1917612850666046,
			},
			["Sporenwindsee"] = {
				["cmd"] = ".tele ZangarmarschenSporenwindsee",
				["ypos"] = 0.5148146748542786,
				["xpos"] = 0.1394367069005966,
			},
			["Sumpflichtsee"] = {
				["cmd"] = ".tele ZangarmarschenSumpflichtsee",
				["ypos"] = 0.4154149889945984,
				["xpos"] = 0.2126182317733765,
			},
			["Sumpfrattenposten"] = {
				["cmd"] = ".tele ZangarmarschenSumpfrattenposten",
				["ypos"] = 0.5472927093505859,
				["xpos"] = 0.8484780788421631,
			},
			["Telredor"] = {
				["cmd"] = ".tele ZangarmarschenTelredor",
				["ypos"] = 0.4937325417995453,
				["xpos"] = 0.6829386949539185,
			},
			["Umbrafenn"] = {
				["cmd"] = ".tele ZangarmarschenUmbrafenn",
				["ypos"] = 0.8325663208961487,
				["xpos"] = 0.8459059596061707,
			},
			["Umbrafennsee"] = {
				["cmd"] = ".tele ZangarmarschenUmbrafennsee",
				["ypos"] = 0.6432676315307617,
				["xpos"] = 0.7327131628990173,
			},
			["Wachposten des Cenarius"] = {
				["cmd"] = ".tele ZangarmarschenWachpostendesCenarius",
				["ypos"] = 0.6588140726089478,
				["xpos"] = 0.2306467443704605,
			},
			["Wildfenn"] = {
				["cmd"] = ".tele ZangarmarschenWildfenn",
				["ypos"] = 0.5986163020133972,
				["xpos"] = 0.4599665105342865,
			},
			["Zabra'jin"] = {
				["cmd"] = ".tele ZangarmarschenZabrajin",
				["ypos"] = 0.4993965029716492,
				["xpos"] = 0.3213036358356476,
			},
			["Zangarmarschen"] = {
				["cmd"] = ".tele ZangarmarschenZangarmarschen",
				["ypos"] = 0.8461402654647827,
				["xpos"] = 0.7281736731529236,
			},
			["Zuflucht des Cenarius"] = {
				["cmd"] = ".tele ZangarmarschenZufluchtdesCenarius",
				["ypos"] = 0.6408082842826843,
				["xpos"] = 0.7926822304725647,
			},
			["coord"] = {
				["continent"] = 3,
				["zone"] = 8,
			},
		},
		["Zul'Drak"] = {
			["Altar von Har'koa"] = {
				["cmd"] = ".tele ZulDrakAltarvonHarkoa",
				["ypos"] = 0.6906712055206299,
				["xpos"] = 0.6284515857696533,
			},
			["Altar von Mam'toth"] = {
				["cmd"] = ".tele ZulDrakAltarvonMamtoth",
				["ypos"] = 0.4070175886154175,
				["xpos"] = 0.7272049784660339,
			},
			["Altar von Quetz'lun"] = {
				["cmd"] = ".tele ZulDrakAltarvonQuetzlun",
				["ypos"] = 0.5866091251373291,
				["xpos"] = 0.7425762414932251,
			},
			["Altar von Rhunok"] = {
				["cmd"] = ".tele ZulDrakAltarvonRhunok",
				["ypos"] = 0.3647668659687042,
				["xpos"] = 0.5349146127700806,
			},
			["Altar von Sseratus"] = {
				["cmd"] = ".tele ZulDrakAltarvonSseratus",
				["ypos"] = 0.4049871265888214,
				["xpos"] = 0.403670608997345,
			},
			["Die Argentumwache"] = {
				["cmd"] = ".tele ZulDrakDieArgentumwache",
				["ypos"] = 0.6665992140769959,
				["xpos"] = 0.3965416848659515,
			},
			["Die Lichtbresche"] = {
				["cmd"] = ".tele ZulDrakDieLichtbresche",
				["ypos"] = 0.75444096326828,
				["xpos"] = 0.3107303977012634,
			},
			["Die Schwarze Wacht"] = {
				["cmd"] = ".tele ZulDrakDieSchwarzeWacht",
				["ypos"] = 0.7338712811470032,
				["xpos"] = 0.1445306688547134,
			},
			["Feste Drak'Tharon"] = {
				["cmd"] = ".tele ZulDrakFesteDrakTharon",
				["ypos"] = 0.8689981698989868,
				["xpos"] = 0.2875894904136658,
			},
			["Festung Zol'Maz"] = {
				["cmd"] = ".tele ZulDrakFestungZolMaz",
				["ypos"] = 0.3554581701755524,
				["xpos"] = 0.661038339138031,
			},
			["Gundrak"] = {
				["cmd"] = ".tele ZulDrakGundrak",
				["ypos"] = 0.2243413329124451,
				["xpos"] = 0.803974986076355,
			},
			["Kolramas"] = {
				["cmd"] = ".tele ZulDrakKolramas",
				["ypos"] = 0.7766656875610352,
				["xpos"] = 0.6171835064888001,
			},
			["Thryms Ende"] = {
				["cmd"] = ".tele ZulDrakThrymsEnde",
				["ypos"] = 0.5866692662239075,
				["xpos"] = 0.1750488132238388,
			},
			["Zeramas"] = {
				["cmd"] = ".tele ZulDrakZeramas",
				["ypos"] = 0.7540895938873291,
				["xpos"] = 0.2149566859006882,
			},
			["Zim'Torga"] = {
				["cmd"] = ".tele ZulDrakZimTorga",
				["ypos"] = 0.5723083019256592,
				["xpos"] = 0.5904360413551331,
			},
			["Zul'Drak"] = {
				["cmd"] = ".tele ZulDrak",
				["ypos"] = 0.6312779188156128,
				["xpos"] = 0.5227834582328796,
			},
			["coord"] = {
				["continent"] = 4,
				["zone"] = 12,
			},
		},
		["�dland"] = {
			["Agmondkuppe"] = {
				["cmd"] = ".tele OedlandAgmondkuppe",
				["ypos"] = 0.6863679885864258,
				["xpos"] = 0.5028918981552124,
			},
			["Apocryphans Ruheplatz"] = {
				["cmd"] = ".tele OedlandApocryphansRuheplatz",
				["ypos"] = 0.6058534383773804,
				["xpos"] = 0.1554386168718338,
			},
			["Camp Boff"] = {
				["cmd"] = ".tele OedlandCampBoff",
				["ypos"] = 0.6900644302368164,
				["xpos"] = 0.6394867897033691,
			},
			["Camp Cagg"] = {
				["cmd"] = ".tele OedlandCampCagg",
				["ypos"] = 0.7586452960968018,
				["xpos"] = 0.1413883864879608,
			},
			["Camp Kosh"] = {
				["cmd"] = ".tele OedlandCampKosh",
				["ypos"] = 0.2159679979085922,
				["xpos"] = 0.6823853850364685,
			},
			["Camp Wurg"] = {
				["cmd"] = ".tele OedlandCampWurg",
				["ypos"] = 0.5739463567733765,
				["xpos"] = 0.3063756227493286,
			},
			["Das Staubbecken"] = {
				["cmd"] = ".tele OedlandDasStaubbecken",
				["ypos"] = 0.4377453327178955,
				["xpos"] = 0.2193671464920044,
			},
			["Die Lethlorklamm"] = {
				["cmd"] = ".tele OedlandDieLethlorklamm",
				["ypos"] = 0.6309206485748291,
				["xpos"] = 0.8092034459114075,
			},
			["Fangzahntal"] = {
				["cmd"] = ".tele OedlandFangzahntal",
				["ypos"] = 0.5331957340240479,
				["xpos"] = 0.433160811662674,
			},
			["Festung Angor"] = {
				["cmd"] = ".tele OedlandFestungAngor",
				["ypos"] = 0.2961931526660919,
				["xpos"] = 0.4264214634895325,
			},
			["Hammerzehs Grabungsst\195\164tte"] = {
				["cmd"] = ".tele OedlandHammerzehsGrabungsstaette",
				["ypos"] = 0.3147720694541931,
				["xpos"] = 0.5349481701850891,
			},
			["Illusionenebene"] = {
				["cmd"] = ".tele OedlandIllusionenebene",
				["ypos"] = 0.6608888506889343,
				["xpos"] = 0.3129008412361145,
			},
			["Kargath"] = {
				["cmd"] = ".tele OedlandKargath",
				["ypos"] = 0.474197119474411,
				["xpos"] = 0.04386875778436661,
			},
			["Terrasse des Sch\195\182pfers"] = {
				["cmd"] = ".tele OedlandTerrassedesSchoepfers",
				["ypos"] = 0.1299520879983902,
				["xpos"] = 0.4883194267749786,
			},
			["Uldaman"] = {
				["cmd"] = ".tele OedlandUldaman",
				["ypos"] = 0.3531,
				["xpos"] = 0.1164,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 13,
			},
		},
		["�stliche Pestl�nder"] = {
			["Braumanns M\195\188hle"] = {
				["cmd"] = ".tele OestlichePestlaenderBraumannsMuehle",
				["ypos"] = 0.4600328207015991,
				["xpos"] = 0.7058310508728027,
			},
			["Corins Kreuzung"] = {
				["cmd"] = ".tele OestlichePestlaenderCorinsKreuzung",
				["ypos"] = 0.6193262934684753,
				["xpos"] = 0.551720917224884,
			},
			["Darroheim"] = {
				["cmd"] = ".tele OestlichePestlaenderDarroheim",
				["ypos"] = 0.840678870677948,
				["xpos"] = 0.3496854305267334,
			},
			["Das Fungustal"] = {
				["cmd"] = ".tele OestlichePestlaenderDasFungustal",
				["ypos"] = 0.467316597700119,
				["xpos"] = 0.3513639271259308,
			},
			["Das giftige Tal"] = {
				["cmd"] = ".tele OestlichePestlaenderDasgiftigeTal",
				["ypos"] = 0.3683146834373474,
				["xpos"] = 0.7858562469482422,
			},
			["Das Tiefgew\195\182lbe"] = {
				["cmd"] = ".tele OestlichePestlaenderDasTiefgewoelbe",
				["ypos"] = 0.7672100067138672,
				["xpos"] = 0.239076554775238,
			},
			["Der Pestwald"] = {
				["cmd"] = ".tele OestlichePestlaenderDerPestwald",
				["ypos"] = 0.2135798633098602,
				["xpos"] = 0.2764058113098145,
			},
			["Faulholzsee"] = {
				["cmd"] = ".tele OestlichePestlaenderFaulholzsee",
				["ypos"] = 0.4421668946743012,
				["xpos"] = 0.4872834384441376,
			},
			["Jagdh\195\188tte von Quel'Lithien"] = {
				["cmd"] = ".tele OestlichePestlaenderJagdhuettevonQuelLithien",
				["ypos"] = 0.1245754063129425,
				["xpos"] = 0.4833736717700958,
			},
			["Kapelle des hoffnungsvollen Lichts"] = {
				["cmd"] = ".tele OestlichePestlaenderKapelledeshoffnungsvollenLicht",
				["ypos"] = 0.530531108379364,
				["xpos"] = 0.7500544786453247,
			},
			["Marris' Siedlung"] = {
				["cmd"] = ".tele OestlichePestlaenderMarrisSiedlung",
				["ypos"] = 0.6828675866127014,
				["xpos"] = 0.2321587353944778,
			},
			["Mazra'Alor"] = {
				["cmd"] = ".tele OestlichePestlaenderMazraAlor",
				["ypos"] = 0.09352053701877594,
				["xpos"] = 0.6710349917411804,
			},
			["Mereldarsee"] = {
				["cmd"] = ".tele OestlichePestlaenderMereldarsee",
				["ypos"] = 0.7394245266914368,
				["xpos"] = 0.5699395537376404,
			},
			["Nordpassturm"] = {
				["cmd"] = ".tele OestlichePestlaenderNordpassturm",
				["ypos"] = 0.1943764686584473,
				["xpos"] = 0.5070120096206665,
			},
			["Nordtal"] = {
				["cmd"] = ".tele OestlichePestlaenderNordtal",
				["ypos"] = 0.2577409148216248,
				["xpos"] = 0.6583414673805237,
			},
			["Ostwalltor"] = {
				["cmd"] = ".tele OestlichePestlaenderOstwalltor",
				["ypos"] = 0.1948505789041519,
				["xpos"] = 0.4345954358577728,
			},
			["Ostwallturm"] = {
				["cmd"] = ".tele OestlichePestlaenderOstwallturm",
				["ypos"] = 0.4312298595905304,
				["xpos"] = 0.6167560815811157,
			},
			["Pestwaldturm"] = {
				["cmd"] = ".tele OestlichePestlaenderPestwaldturm",
				["ypos"] = 0.2643425762653351,
				["xpos"] = 0.1881666034460068,
			},
			["Schreckenstal"] = {
				["cmd"] = ".tele OestlichePestlaenderSchreckenstal",
				["ypos"] = 0.2881140112876892,
				["xpos"] = 0.1437134742736816,
			},
			["Schreckenstunnel"] = {
				["cmd"] = ".tele OestlichePestlaenderSchreckenstunnel",
				["ypos"] = 0.3581699728965759,
				["xpos"] = 0.04570397362112999,
			},
			["Stratholme"] = {
				["cmd"] = ".tele OestlichePestlaenderStratholme",
				["ypos"] = 0.1089672613143921,
				["xpos"] = 0.2709174053668976,
			},
			["Turm der Kronenwache"] = {
				["cmd"] = ".tele OestlichePestlaenderTurmderKronenwache",
				["ypos"] = 0.6829783320426941,
				["xpos"] = 0.3451696932315826,
			},
			["Tyrs Hand"] = {
				["cmd"] = ".tele OestlichePestlaenderTyrsHand",
				["ypos"] = 0.7782461643218994,
				["xpos"] = 0.8030759692192078,
			},
			["Zul'Mashar"] = {
				["cmd"] = ".tele OestlichePestlaenderZulMashar",
				["ypos"] = 0.1180675029754639,
				["xpos"] = 0.6558643579483032,
			},
			["\195\150stliche Pestl\195\164nder"] = {
				["cmd"] = ".tele OestlichePestlaenderOestlichePestlaender",
				["ypos"] = 0.2793457508087158,
				["xpos"] = 0.4280514717102051,
			},
			["coord"] = {
				["continent"] = 2,
				["zone"] = 14,
			},
		},
	};
end