
local brez = CreateFrame("Frame", "bRez", UIParent)
brez:SetPoint("CENTER", UIParent, "CENTER")
brez:SetWidth(100)
brez:SetHeight(30)
brez:EnableMouse(true)
brez:RegisterForDrag("LeftButton")
brez:SetClampedToScreen(true)
brez:SetMovable(true)
brez:RegisterEvent("PLAYER_LOGIN")
brez:SetScript("OnEvent", function(frame, event, ...) frame[event](frame, ...) end)
brez:SetScript("OnDragStart", function(frame) if IsAltKeyDown() then frame:StartMoving() end end)
brez:SetScript("OnDragStop", function(frame) frame:StopMovingOrSizing() end)

brez.cooldown = brez:CreateFontString("bRezCooldownText", "OVERLAY")
brez.cooldown:SetHeight(20)
brez.cooldown:SetPoint("TOPLEFT", brez, "TOPLEFT")
brez.cooldown:SetFontObject(TextStatusBarText)
brez.cooldown:SetJustifyH("LEFT")

brez.ready = brez:CreateFontString("bRezReadyText", "OVERLAY")
brez.ready:SetHeight(20)
brez.ready:SetPoint("BOTTOMLEFT", brez.cooldown, "BOTTOMLEFT", 0 , -10)
brez.ready:SetFontObject(TextStatusBarText)
brez.ready:SetJustifyH("LEFT")

function brez:ZONE_CHANGED_NEW_AREA()
	local inside, what = IsInInstance()
	if inside and what == "raid" then
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		self:Show()
	else
		self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		self:Hide()
	end
end

function brez:PLAYER_LOGIN()
	if not bRezDB then bRezDB = {} end
	self:RegisterEvent("ZONE_CHANGED_NEW_AREA")
	self:RegisterEvent("RAID_ROSTER_UPDATE")
	self:ZONE_CHANGED_NEW_AREA()
end

local lastCheck = 0
function brez:COMBAT_LOG_EVENT_UNFILTERED(time, event, _, name, ...)
	if event == "SPELL_RESURRECT" then
		local spell = select(6, ...)
		if spell == GetSpellInfo(48477) then
			bRezDB[name] = time
		end
	end
	if time - lastCheck < 3 then return end

	lastCheck = time
	local cdnames = "|cFFFF0000Cooldown|r: "
	local readynames = "|cFF00FF7FReady|r: "
	for k, v in pairs(bRezDB) do
		if v > 0 then
			local timeleft = 600 - (time - v)
			local theRealTime
			if timeleft > 60 then
				theRealTime = "(".. ceil(timeleft / 60) .."m) "
			elseif timeleft < 0 then
				bRezDB[k] = 0
				lastCheck = 0
				theRealTime = ""
			else
				theRealTime = "(<1m) "
			end
			cdnames = cdnames .. k ..theRealTime
		else
			readynames = readynames .. (UnitHealth(k)<2 and "|cFFFF0000"..k or "|cFFFFFFFF"..k) .. ". |r"
		end
	end
	self.cooldown:SetText(cdnames)
	self.ready:SetText(readynames)
end

function brez:RAID_ROSTER_UPDATE()
	for k in pairs(bRezDB) do
		if not UnitInRaid(k) then
			bRezDB[k] = nil
		end
	end
	for i = 1, GetNumRaidMembers() do
		local player = GetRaidRosterInfo(i)
		local _, realn = UnitClass(player)
		if realn == "DRUID" and not bRezDB[player] then
			bRezDB[player] = 0
		end
	end
end

