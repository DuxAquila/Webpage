﻿--[[
	callBacks.lua
		Initializes the Bagnon callback handler
--]]

local Bagnon = LibStub('AceAddon-3.0'):GetAddon('Bagnon')
Bagnon.Callbacks = Bagnon.Ears:New()